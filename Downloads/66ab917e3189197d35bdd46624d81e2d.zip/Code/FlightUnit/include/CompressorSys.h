/*******************************************************************************
 *
 * File: CompressorSys.h
 *
 * This class is to control a compressor using a relay and pressure switch
 * without using the logic built into the PCM. Concerns about drawing too
 * much current through the PCM and fuse shared with the radio lead to
 * the creation of this class.
 *
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Chami
 *
 ******************************************************************************/
#pragma once

#include "gsu/tinyxml2.h"

#include "RobonautsLIbrary/PeriodicControl.h"
#include "RobonautsLibrary/XmlRobotUtil.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIController.h"

/*******************************************************************************
 * 
 * This class controls ...
 *
 * XML Example:
 *   <compressor period = "0.05" priority = "0">
 *  	...
 *   </compressor>
 *
 ******************************************************************************/
class CompressorSys: public PeriodicControl
{
	public:
		CompressorSys(PowerDistributionPanel* pdp, tinyxml2::XMLElement *xml = NULL, double period = 0.05);
		~CompressorSys();

		void publish(void);

	protected:
		void controlInit();
		void updateConfig();

		void disabledInit();
		void autonomousInit();
		void teleopInit();
		void testInit();

		void doPeriodic();
	
	private:
		Relay *compressor_relay;
		DigitalInput *compressor_switch;

		bool compressor_switch_invert;
		bool compressor_on;

		uint8_t compressor_fuse;
		float compressor_current;

		PowerDistributionPanel* power_panel;
};
