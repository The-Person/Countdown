/*******************************************************************************
 *
 * File: DriveSystem.h
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "WPILib.h"
#include <stdio.h>

#include "AnalogInput.h"
#include "SpeedController.h"

#include "gsu/tinyxml2.h"

#include "RobonautsLibrary/PeriodicControl.h"
#include "RobonautsLibrary/Parameter.h"
#include "RobonautsLibrary/RGyro.h"
#include "RobonautsLibrary/DataLogger.h"
#include "RobonautsLibrary/SimplePID.h"
#include "RobonautsLibrary/MacroStep.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroStepFactory.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/RobotUtil.h"
#include "RobonautsLibrary/XMLRobotUtil.h"
#include "RobonautsLibrary/OIController.h"

//#include "DashboardDefs.h"

#define MODEL_SIZE 2
#define MODEL_DIM 2

/*******************************************************************************
 *
 * <drive_system period="0.01" priority="0">
 * 		<motor name="left_a" type="Talon" module="1" port="6"  invert="false" />
 * 		<motor name="right_a" type="Talon" module="1" port="7"  invert="false" />
 * 		<motor name="left_b" type="Talon" module="1" port="8"  invert="false" />
 * 		<motor name="right_b" type="Talon" module="1" port="9"  invert="false" />
 * 
 *  	<encoder name="left" module="1" port_a="1" port_b="2" invert="false" />
 *  	<encoder name="right" module="1" port_a="3" port_b="4" invert="false" />
 *
 *		<pid name="left" />
 *		<pid name="right" />
 *		
 *  	<solenoid name="swag_front" module="1" port="8"	 invert="false" />
 *  	<solenoid name="swag_back" module="1" port="8"	 invert="false" />
 * 
 * 		<servo	name="left_brake" module="1" port="5" on_pos="0.9" off_pos="0.1" />
 * 		<servo	name="right_brake" module="1" port="5" on_pos="0.1" off_pos="0.9"  />
 * 		
 * 		<analog name="current_sensor" module="1" port="5" />
 * 		
 * 		<gyro module="1" port="1" sensitivity="0.007" />
 * 		
 *	  	<oi name = "open_loop"		device = "cypress" chan = "7" invert="false"/>
 *
 *	  	<oi name = "brake_on"		device = "pilot" chan = "9" invert="false"/>
 *	  	<oi name = "brake_off"		device = "pilot" chan = "10" invert="false"/>
 *	  	<oi name = "brake_toggle"	device = "pilot" chan = "10" invert="false"/>
 *	  	<oi name = "brake_state"	device = "pilot" chan = "10" invert="false"/>
 *	  	
 *	  	<oi name = "swag_front_down"	device = "pilot" chan = "9" invert="false"/>
 *	  	<oi name = "swag_front_up"		device = "pilot" chan = "10" invert="false"/>
 *	  	<oi name = "swag_front_toggle"	device = "pilot" chan = "10" invert="false"/>
 *	  	<oi name = "swag_front_state"	device = "pilot" chan = "10" invert="false"/>
 *	  	
 *	  	<oi name = "swag_back_down"		device = "pilot" chan = "9" invert="false"/>
 *	  	<oi name = "swag_back_up"		device = "pilot" chan = "10" invert="false"/>
 *	  	<oi name = "swag_back_toggle"	device = "pilot" chan = "10" invert="false"/>
 *	  	<oi name = "swag_back_state"	device = "pilot" chan = "10" invert="false"/>
 *	  	
 * </drive_system>
 * 
 ******************************************************************************/
class DriveSystem : public PeriodicControl, public OIObserver
{
	public:
		enum CmdIds
		{
			CMD_OPEN_LOOP_STATE = 0, CMD_FORWARD, CMD_TURN, 
			CMD_BRAKE_ON, CMD_BRAKE_OFF, CMD_BRAKE_TOGGLE, CMD_BRAKE_STATE,
			CMD_SWAG_FRONT_DOWN, CMD_SWAG_FRONT_UP, CMD_SWAG_FRONT_TOGGLE, CMD_SWAG_FRONT_STATE,
			CMD_SWAG_BACK_DOWN, CMD_SWAG_BACK_IT_UP, CMD_SWAG_BACK_TOGGLE, CMD_SWAG_BACK_STATE,
			CMD_TEST_FWD, CMD_TEST_REV
		};
		
		enum DriveMode
		{
			MODE_POWER = 0,
			MODE_VELOCITY,
			MODE_DISTANCE,
			MODE_ROTATE,
			MODE_MOTOR
		};

		DriveSystem(tinyxml2::XMLElement *xml = NULL, double period=0.02);
		~DriveSystem(void);

		void drivePower(float fwd, float trn, bool mut=true);
		void driveMotor(float m1, float m2);
		void driveVelocity(float fwd, float trn);
		void driveRotate(float angl, float trn, float fwd);
		void driveDistance(float dist, float fwd, float trn);

		float getLeftDistance();
		float getRightDistance();
		float getHeading();

		float getDistanceToGo();
		float getRotateToGo();	
		
		void setAnalog(int id, float val);
		void setDigital(int id, bool val);
		void setHeading(float val);  // note if we need external access, add block
		void setDriveDistance(float val);

		void setDriveRotateMode();
		void setDriveDistanceMode();

		void setVelMax(float val);

		void publish(void);
		
	protected:
		void controlInit(void);
		void updateConfig(void);

		void disabledInit(void);
		void autonomousInit(void);
		void teleopInit(void);
		void testInit(void);

		void doPeriodic(void);
		
		void doTestMode(bool fwd, bool rev);

		float ffMotorModel(float desCmd, int idx);


	private:
		void initLogFile(std::string phase);
		float distanceToVelocity(float to_go, float max_vel);
		float rotationToVelocity(float to_go, float max_vel);

		DataLogger *drive_log;

		RGyro *drive_gyro;

		SpeedController *drive_motor_l_a;
		SpeedController *drive_motor_r_a;
		SpeedController *drive_motor_l_b;
		SpeedController *drive_motor_r_b;

		Encoder *encoder_l;
		Encoder *encoder_r;

		float drive_invert_l_a;
		float drive_invert_r_a;
		float drive_invert_l_b;
		float drive_invert_r_b;

		uint8_t drive_mode;

		float drive_cmd_fwd; // for power percent, for others inches / second
		float drive_cmd_trn; // for power percent, for others degree / second
		float drive_cmd_distance; // inches

		float motor_left;
		float motor_right;
		float vel_cmd;

		double previous_time; // seconds
		float previous_distance; // inches
		float previous_distance_l; // inches
		float previous_distance_r; // inches
		float previous_velocity_l; // inches
		float previous_velocity_r; // inches

	   	float gyro_desired;
		float previous_heading; // degrees

		// half the width of the robot -- from wheel center to wheel center
		float drive_max_speed;
		float drive_max_turn;
		static double start_time;
		
		bool drive_ready;
		
		bool drive_rate_limit_on;
		float drive_rate_limit_per_step;
		float power_left_last; 
		float power_right_last; 

		float drive_dist_kgyro;
		float drive_dist_kp;
		float drive_vel_kv;
		float drive_rot_kp;

		float test_fwd;
		float test_rev;
		float test_incr;
		bool test_last_fwd;
		bool test_last_rev;

		float system_period;

		// motor model
		float motor_model_slope[MODEL_DIM][MODEL_SIZE];
		float motor_model_intercept[MODEL_DIM][MODEL_SIZE];

		// driving velocity mode variables
		float v_desired_left;
		float v_desired_right;
		float v_desired_left_sat;
		float v_desired_right_sat;
		float v_desired_max;

};

/*******************************************************************************
 *
 ******************************************************************************/
class MSDrivePower : public MacroStepSequence
{
	public:
		MSDrivePower(std::string type, tinyxml2::XMLElement *xml, void *control);

		void init(void);
		MacroStep * update(void);

	private:
		double forward;
		double turn;
		DriveSystem *drive;
};

/*******************************************************************************
 *
 ******************************************************************************/
class MSDriveDistance : public MacroStepSequence
{
	public:
		MSDriveDistance(std::string type, tinyxml2::XMLElement *xml, void *control);

		void init(void);
		MacroStep * update(void);

	private:
		double distance;
		double forward;
		double tolerance;
		double duration;
		double expire_time;
		double init_time;
		double desired_head;

		DriveSystem *drive;
		TrapezoidalProfile *trap;
};

/*******************************************************************************
 *
 ******************************************************************************/
class MSDriveRotate : public MacroStepSequence
{
	public:
		MSDriveRotate(std::string type, tinyxml2::XMLElement *xml, void *control);

		void init(void);
		MacroStep * update(void);

	private:
		double rotate;
		double turn;
		double tolerance;
		double duration;
		double expire_time;
		double init_time;

		bool first_time;

		DriveSystem *drive;
		TrapezoidalProfile *trap;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSDriveVelocity : public MacroStepSequence
{
	public:
		MSDriveVelocity(std::string type, tinyxml2::XMLElement *xml, void *control);

		void init(void);
		MacroStep * update(void);

	private:
		double forward;
		double turn;
		DriveSystem *drive;
};
