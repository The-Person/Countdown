/*******************************************************************************
 *
 * File: IntakeSystem.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "gsu/tinyxml2.h"

#include "RobonautsLIbrary/PeriodicControl.h"
#include "RobonautsLibrary/Parameter.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroStep.h"
#include "RobonautsLibrary/MacroStepFactory.h"
#include "RobonautsLibrary/XmlRobotUtil.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIController.h"
#include "RobonautsLibrary/DataLogger.h"

#include "DashboardDefs.h"
#include "SpeedController.h"
#include "PowerDistributionPanel.h"
#include "RobonautsLibrary/RPot.h"

/*******************************************************************************
 * 
 * This class controls ...
 *
 * XML Example:
 *   <intake_system period = "0.05" priority = "0">
 *  	...
 *   </intake_system>
 *
 ******************************************************************************/
class IntakeSystem: public PeriodicControl, public OIObserver
{
	public:
		enum IntakeCommand
		{
			CMD_ROLLER_LEFT_FORWARD = 0, CMD_ROLLER_RIGHT_FORWARD,
			CMD_ROLLER_LEFT_REVERSE, CMD_ROLLER_RIGHT_REVERSE,
			CMD_ROLLER_LEFT_FORWARD_STATE, CMD_ROLLER_RIGHT_FORWARD_STATE,
			CMD_ROLLER_LEFT_REVERSE_STATE, CMD_ROLLER_RIGHT_REVERSE_STATE,
			CMD_ROLLER_STOP, CMD_PTO_TOGGLE, CMD_PTO_STATE, CMD_SET_OPENLOOP
		};

		IntakeSystem(PowerDistributionPanel* pb, tinyxml2::XMLElement *xml = NULL, double period = 0.05);
		~IntakeSystem();

		void setAnalog(int id, float val);
		void setDigital(int id, bool val);
		void setInt(int id, int val);
		
		bool getIntakeClosed(void);
		void setIntakePose(uint16_t pose);

		void intakePower(float left, float right);

		void publish(void);

		void openIntakeJaws();
		void releaseIntakeJaws();
		bool areIntakeJawsOpen();

	protected:
		void controlInit();
		void updateConfig();

		void disabledInit();
		void autonomousInit();
		void teleopInit();
		void testInit();

		void doPeriodic();
	
	private:
		void initLogFile(std::string phase);
		void writeLogMessage(void);

		DataLogger data_log;

		// Hardware
		SpeedController* intake_motor_left;
		SpeedController* intake_motor_right;

		Solenoid *pto_sol_l;
		Solenoid *pto_sol_r;

		RPot* pot_left;
		RPot* pot_right;

		SimplePID *pid_left;
		SimplePID *pid_right;

		PowerDistributionPanel* power_board;

		// Read From XML
		//
		float intake_motor_left_invert;
		float intake_motor_right_invert;
		float intake_motor_left_forward;
		float intake_motor_right_forward;
		float intake_motor_left_reverse;
		float intake_motor_right_reverse;

		float intake_jaw_motor_left_forward;
		float intake_jaw_motor_right_forward;
		float intake_jaw_motor_left_reverse;
		float intake_jaw_motor_right_reverse;


		bool pto_sol_invert_l;
		bool pto_sol_invert_r;

		uint8_t left_port;
		uint8_t right_port;

		// Parameters
		float intake_max_power_delta;

		float stall_time;
		float stall_recover_time;
		float stall_current;
		float beach_stall_current;

		// Read from Hardware
		float intake_motor_current_left;
		float intake_motor_current_right;

		bool pot_left_ready;
		float pot_left_raw;
		float pot_left_position;

		bool intake_left_jaw_open;

		bool pot_right_ready;
		float pot_right_raw;
		float pot_right_position;

		bool intake_right_jaw_open;


		float intake_motor_left_target;
		float intake_motor_right_target;
		float intake_motor_left_saved_target;
		float intake_motor_right_saved_target;

		float intake_motor_left_cmd;
		float intake_motor_right_cmd;

		bool pto_active_cmd;
		bool intake_jaw_desired_open;
		double pto_engage_delay;
		double pto_engage_timeout;	// computed from current time and delay

		float stall_time_accum_left;
		float stall_time_accum_right;

		bool stall_out_left;
		bool stall_out_right;

		double thread_period;

		bool open_loop;
		bool intake_ready;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSIntakePower : public MacroStepSequence
{
	public:
		MSIntakePower(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		double left_pwr;
		double right_pwr;
		IntakeSystem *intake;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSIntakeSetJawOpen : public MacroStepSequence
{
	public:
		MSIntakeSetJawOpen(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		IntakeSystem *intake;
		bool state;
		double duration;
		double expire_time;
};

///******************************************************************************
// *
// ******************************************************************************/
//class MSIntakePose : public MacroStepSequence
//{
//	public:
//		MSIntakePose(std::string type, tinyxml2::XMLElement *xml, void *control);
//		void init(void);
//		MacroStep * update(void);
//
//	private:
//		double state;
//		IntakeSystem *intake;
//};
