/*******************************************************************************
 *
 * File: CanLift.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Devin
 *
 ******************************************************************************/
#pragma once

#include "gsu/tinyxml2.h"

#include "RobonautsLIbrary/PeriodicControl.h"
#include "RobonautsLibrary/Parameter.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroStep.h"
#include "RobonautsLibrary/MacroStepFactory.h"
#include "RobonautsLibrary/XmlRobotUtil.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIController.h"
#include "RobonautsLibrary/DataLogger.h"

#include "DashboardDefs.h"

/*******************************************************************************
 * 
 * This class controls ...
 *
 * XML Example:
 *   <can_lift period = "0.05" priority = "0">
 *  	...
 *   </can_lift>
 *
 ******************************************************************************/
class CanLift: public PeriodicControl, public OIObserver
{
public:
	enum IntakeCommand
	{
		//Digital
		CMD_TOTE_HOLDER_OPEN,
		CMD_TOTE_HOLDER_CLOSED,
		CMD_TOTE_HOLDER_TOGGLE,
		CMD_TOTE_HOLDER_STATE,

		CMD_CAN_HOLDER_OPEN,
		CMD_CAN_HOLDER_CLOSED,
		CMD_CAN_HOLDER_TOGGLE,
		CMD_CAN_HOLDER_STATE,

		CMD_CAN_PIKE_DOWN,
		CMD_CAN_PIKE_UP,
		CMD_CAN_PIKE_TOGGLE,
		CMD_CAN_PIKE_STATE
	};

	CanLift(tinyxml2::XMLElement *xml = NULL, double period = 0.05);
	~CanLift();

	void setAnalog(int id, float val);
	void setDigital(int id, bool val);
	void setInt(int id, int val);

	void publish(void);

	// Can Holder
	bool is007Open(void);
	void set007Open(bool openA);
	bool isPincherOpen(void);
	void setPincherOpen(bool openA);

protected:
	void controlInit();
	void updateConfig();

	void disabledInit();
	void autonomousInit();
	void teleopInit();
	void testInit();

	void doPeriodic();


private:
	DataLogger data_log;

	//Robot states
	bool can_lift_subsystem_ready;

	Solenoid *tote_holder_sol;
	Solenoid *tote_holder_sol_b;

	Solenoid *can_holder_sol;

	Solenoid *can_pike_sol;

	bool tote_holder_sol_invert;
	bool can_holder_sol_invert;
	bool can_pike_sol_invert;

	// Input from driver
	bool tote_holder_open_trg;
	bool can_holder_open_trg;
	bool can_pike_open_trg;

	void writeLogMessage(void);

	//Misc.
	void initLogFile(std::string phase);
};

/******************************************************************************
 *
 ******************************************************************************/
class MSOpen007 : public MacroStepSequence
{
	public:
		MSOpen007(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		bool open_007;
		CanLift *canlift;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSOpenPincher : public MacroStepSequence
{
	public:
	MSOpenPincher(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		bool open_pincher;
		CanLift *canlift;
};
