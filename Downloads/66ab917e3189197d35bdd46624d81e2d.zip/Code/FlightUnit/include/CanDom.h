/*******************************************************************************
 *
 * File: CanDom.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Erica
 *
 ******************************************************************************/
#pragma once

#include "gsu/tinyxml2.h"

#include "RobonautsLIbrary/PeriodicControl.h"
#include "RobonautsLibrary/Parameter.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroStep.h"
#include "RobonautsLibrary/MacroStepFactory.h"
#include "RobonautsLibrary/XmlRobotUtil.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIController.h"
#include "RobonautsLibrary/DataLogger.h"

//#include "DashboardDefs.h"

/*******************************************************************************
 * 
 * This class controls ...
 *
 * XML Example:
 *   <can_dom period = "0.05" priority = "0">
 *  	...
 *   </can_dom>
 *
 ******************************************************************************/
class CanDom: public PeriodicControl, public OIObserver
{
	public:
		enum CanDomCommand
		{
			CMD_CLOSED_LOOP, CMD_LEFT_STATE, CMD_RIGHT_STATE, CMD_LEFT_TOGGLE, CMD_RIGHT_TOGGLE, CMD_POSITION, CMD_SOL_LEFT_STATE, CMD_SOL_RIGHT_STATE, CMD_SOL_RACE_STATE,
		};

		enum CanDomPosition
		{
			StowPosition=0, Release=90, GrabPosition=180, ReadyPosition=270, LatchPosition=360
		};

		CanDom(tinyxml2::XMLElement *xml = NULL, double period = 0.05);
		~CanDom();

		void setAnalog(int id, float val);
		void setDigital(int id, bool val);
		void setInt(int id, int val);
		
		void setLatchOpen(bool left, bool right, bool race);
		void setWinchPower(float pwr);
		void setArmPosition(CanDomPosition arg);
		bool isArmPosition(CanDomPosition pos, float tolerance);

		bool getIntakeClosed(void);
		void setIntakePose(uint16_t pose);

		void publish(void);
		bool getSolenoidState(void);
		float getArmAngle(void);

	protected:
		void controlInit();
		void updateConfig();

		void disabledInit();
		void autonomousInit();
		void testInit();
		void teleopInit();

		void doPeriodic();

	
	private:
		void initLogFile(std::string phase);
		void writeLogMessage(void);

		DataLogger data_log;

		SpeedController *winch_motor;
		RPot *arm_angle_pot;
		Solenoid *left_latch_sol;
		Solenoid *right_latch_sol;
		Solenoid *race_sol;
		DigitalInput *right_top_limit_sw;
		DigitalInput *right_bottom_limit_sw;
		DigitalInput *left_bottom_limit_sw;
		DigitalInput *left_top_limit_sw;
		SimplePID *arm_angle_pid;

		bool left_latch_invert;
		bool right_latch_invert;
		bool race_invert;
		bool left_top_limit_invert;
		bool left_bottom_limit_invert;
		bool right_top_limit_invert;
		bool right_bottom_limit_invert;
		bool can_dom_subsystem_ready;

		float winch_motor_invert;
			
		bool arm_angle_pot_ready;
		float arm_angle_pot_raw;
		float arm_angle_pot_position;

		bool right_top_limit_pressed;
//		bool right_bottom_limit_pressed;
		bool left_top_limit_pressed;
//		bool left_bottom_limit_pressed;
		float winch_command_power;

		bool closed_loop;
		bool left_active;
		bool right_active;

		float winch_motor_target;
		float position_target;
		float position_stow;
		float position_ready;
		float position_grab;
		float arm_position_min_latch;
		float winch_up_power;
		float winch_down_power;

		bool left_sol_cmd;
		bool right_sol_cmd;
		bool race_sol_cmd;
		bool right_sol_state;
		bool left_sol_state;
		bool race_sol_state;

		float winch_max_power_delta;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSCanOpenLatch : public MacroStepSequence
{
	public:
		MSCanOpenLatch(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		bool left_fire;
		bool right_fire;
		bool race_fire;
		CanDom *candom;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSCanDomSetWinchPower : public MacroStepSequence
{
	public:
		MSCanDomSetWinchPower(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		float winch_pwr;
		CanDom *candom;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSCanDomSetPosition : public MacroStepSequence
{
	public:
		MSCanDomSetPosition(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		CanDom *candom;
		CanDom::CanDomPosition position;
		float tolerance;
};
