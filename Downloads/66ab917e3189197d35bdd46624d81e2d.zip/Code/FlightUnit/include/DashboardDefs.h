/*******************************************************************************
 *
 * File: DashboardDefs.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#define NO_DASHBOARD		0
#define LABVIEW_DASHBOARD 	1
#define SMART_DASHBOARD 	2
#define UDP_DASHBOARD 		3

#define DASHBOARD_TYPE SMART_DASHBOARD


/*******************************************************************************
 *
 ******************************************************************************/
#if (DASHBOARD_TYPE == LABVIEW_DASHBOARD)

#elif (DASHBOARD_TYPE == SMART_DASHBOARD)
#include "SmartDashboard/SmartDashboard.h"

#elif (DASHBOARD_TYPE == UDP_DASHBOARD)


#endif
