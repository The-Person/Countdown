/*******************************************************************************
 *
 * File: RobotMain.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "IterativeRobot.h"

#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroController.h"
#include "RobonautsLibrary/PeriodicControl.h"

#include "DriverStation.h"
#include "DashboardDefs.h"

#include "PowerDistributionPanel.h"

#include "CanDom.h"

/*******************************************************************************
 *
 * The main class for this robot
 * 
 ******************************************************************************/
class RobotMain : public IterativeRobot, public OIObserver
{
	public:
		RobotMain(void);
		~RobotMain();

		void RobotInit(void);
		void UpdateConfig(void);
		void UpdateAutonConfig(void);
		
		void DisabledInit(void);
		void DisabledPeriodic(void);

		void TestInit(void);
		void TestPeriodic(void);

		void AutonomousInit(void);
		void AutonomousPeriodic(void);

		void TeleopInit(void);
		void TeleopPeriodic(void);

		void LoadRobot(std::string file);
		
		void setAnalog(int id, float val);
		void setDigital(int id, bool val);
		void setInt(int id, int val);
		
		void publish(void);

		// Operator Interface Input Commands
		enum
		{
			CMD_CONFIG_ARM = 0, CMD_CONFIG_LOAD,
			CMD_AUTON_SELECT_POV, CMD_AUTON_ENABLED, CMD_AUTON_SELECT_B0, CMD_AUTON_SELECT_B1, CMD_AUTON_SELECT_B2,
			CMD_AUTON_CAN_RACE_STATE, CMD_AUTON_CAN_RACE_ON, CMD_AUTON_CAN_RACE_OFF,
			CMD_AUTON_DELAY_ENABLED, CMD_AUTON_DELAY_VALUE,
			CMD_A2DC = 100, CMD_A2DC_HIGH, CMD_A2DC_LOW, CMD_A3DC, CMD_A3DC_HIGH, CMD_A3DC_LOW,
			CMD_START_MACRO = 200, CMD_START_MACRO_MAX = 299
		};
		
	private:
		MacroController *macro_controller;
		std::vector<std::string> macro_name_list;
		std::vector<std::string> macro_file_list;
//		DriverStation 	*driver_station;
		CanDom 			*can_dom;
		
		std::vector<PeriodicControl *> robot_controls;
		
		bool 		config_arm;
		bool 		config_load;
		bool 		config_loaded;
		uint16_t 	config_updates;
		
		int   		auton_select;
		int 		auton_select_loaded;
		int			auton_select_mismatch;
		bool  		auton_enabled;
		float 		auton_delay;
		bool  		auton_delay_enabled;
		double		auton_start_time;
		bool 		auton_started;
		bool		auton_oi_configured;
		std::string auton_description;
		
		bool is_a2dc_triggered_low;
		bool is_a2dc_triggered_high;
		bool is_a3dc_triggered_low;
		bool is_a3dc_triggered_high;

		uint16_t 	publish_count;

		PowerDistributionPanel* power_board;

		enum Phase
		{
			INIT, DISABLED, AUTON, TELEOP, TEST
		};

		Phase robot_phase;


};

