/*******************************************************************************
 *
 * File: TestControl.h
 *
 * This class is to run some automated tests on the rest of the software.
 *
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "gsu/tinyxml2.h"

#include "RobonautsLIbrary/PeriodicControl.h"
#include "RobonautsLibrary/XmlRobotUtil.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIController.h"

/*******************************************************************************
 * 
 * This class controls ...
 *
 * XML Example:
 *   <test period = "0.05" priority = "0">
 *  	...
 *   </test>
 *
 ******************************************************************************/
class TestControl: public PeriodicControl
{
	public:
		TestControl(tinyxml2::XMLElement *xml = NULL, double period = 0.05);
		~TestControl();

		void publish(void);

		void setMacroController(MacroController *mc);

	protected:
		void controlInit();
		void updateConfig();

		void disabledInit();
		void autonomousInit();
		void teleopInit();
		void testInit();

		void doPeriodic();
	
	private:
		bool test_ready;

		MacroController *macro_control;
};
