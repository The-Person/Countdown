/*******************************************************************************
 *
 * File: ToteLift.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Devinda
 *
 ******************************************************************************/
#pragma once

#include <stdint.h>

#include <WPILib.h>

#include "gsu/tinyxml2.h"

#include "RobonautsLIbrary/PeriodicControl.h"
#include "RobonautsLibrary/Parameter.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroStep.h"
#include "RobonautsLibrary/MacroStepFactory.h"
#include "RobonautsLibrary/XmlRobotUtil.h"
#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIController.h"
#include "RobonautsLibrary/DataLogger.h"

#include "DashboardDefs.h"

#include "IntakeSystem.h"

/*******************************************************************************
 * 
 * This class controls ...
 *
 * XML Example:
 *   <tote_lift period = "0.05" priority = "0">
 *  	...
 *   </tote_lift>
 *
 ******************************************************************************/
class ToteLift: public PeriodicControl, public OIObserver
{
	public:
		enum ToteLiftCommand
		{
			CMD_CLOSED_LOOP, CMD_LIFT_POWER, CMD_STEP_UP, CMD_STEP_DOWN, CMD_STOP,
			CMD_MOMENTARY_UP, CMD_MOMENTARY_DOWN, CMD_LIFT_POSITION, CMD_LIFT_UP,
			CMD_LIFT_DOWN, CMD_EJECT_SOLINOID, CMD_LANDFILL_MODE, CMD_HP_MODE
		};

		enum Position
		{
			LIFT_LVL_BOT_LIMIT, LIFT_LVL_PICKUP1, LIFT_LVL_LOW_DRIVE,
			LIFT_LVL_STEP0_DEPLOY, LIFT_LVL_PICKUP2, LIFT_LVL_INTAKE1,
			LIFT_LVL_STEP1_DEPLOY, LIFT_LVL_5STACK007, LIFT_LVL_INTAKE2, LIFT_LVL_HPINTAKE,
			LIFT_LVL_INTAKE3, LIFT_LVL_NUM_POSITIONS
		};

//		static const char * PositionNames[LIFT_LVL_NUM_POSITIONS];

		ToteLift(tinyxml2::XMLElement *xml = NULL, double period = 0.05);
		~ToteLift();

		void setAnalog(int id, float val);
		void setDigital(int id, bool val);
		void setInt(int id, int val);
		
		bool getIntakeClosed(void);
		void setIntakePose(uint16_t pose);

		bool getHpMode();
		bool getLandfillMode();

		void toteLiftPower(float pwr);

		void publish(void);

		float getLiftHeight(void);

		void setPowerBoard(PowerDistributionPanel* pb);
		void setIntakeSystem(IntakeSystem *intake_sys);

		void setPosition(Position pos);
		bool isPosition(Position pos, float tolerance);
		void setPosition(float pos);
		bool isPosition(float pos, float tolerance);

		void setStop(void);

		bool isToteDetected(int slot);
		Position getPostitionFromName(const char *name);

	protected:
		void controlInit();
		void updateConfig();

		void disabledInit();
		void autonomousInit();
		void teleopInit();
		void testInit();

		void doPeriodic();

	private:
		void initLogFile(std::string phase);
		void writeLogMessage(void);

		DataLogger lift_data_log;
		bool lift_initialized;

		SpeedController *lift_motor_a;
		SpeedController *lift_motor_b;

		Solenoid *lift_eject_sol;
		RPot *lift_pos_pot;
		DigitalInput *lift_top_limit_sw;
		DigitalInput *lift_bot_limit_sw;
		DigitalInput *lift_tote_pos1_sw;
		DigitalInput *lift_tote_pos2_sw;

		PowerDistributionPanel* lift_power_board;
		IntakeSystem *lift_intake_system;

		SimplePID *lift_pid;

		// Config Variables
		bool lift_closed_loop;

		float lift_motor_a_invert;
		float lift_motor_b_invert;

		float lift_stall_time;
		float lift_stall_recover_time;
		float lift_stall_current;

		bool landfill_mode;
		bool hp_mode;

		bool lift_eject_invert;
		bool lift_top_limit_invert;
		bool lift_bot_limit_invert;
		bool lift_tote_pos1_invert;
		bool lift_tote_pos2_invert;

		int lift_pb_a_port;
		int lift_pb_b_port;

		float lift_increment_step;
		float lift_decrement_step;
		float lift_up_power;
		float lift_down_power;

		float lift_max_power_delta;
		float lift_pos_adjust_scale;

		float lift_tote_positions [LIFT_LVL_NUM_POSITIONS];

		// Sensor Inputs
		bool lift_top_limit_pressed;
		bool lift_bot_limit_pressed;
		bool lift_tote_pos1_pressed;
		bool lift_tote_pos2_pressed;

		bool lift_pos_pot_ready;
		float lift_pos_pot_raw;
		float lift_pos_pot_position;

		// Control Inputs
		float lift_target_power;
		float lift_target_position;
		int lift_position_index;

		bool lift_motor_stall;
		float lift_motor_current;
		double lift_motor_stall_time;

		// Output Variables
		float lift_command_power;

		bool lift_eject_cmd; //to place totes on step
};

/******************************************************************************
 *
 ******************************************************************************/
class MSToteLiftPower : public MacroStepSequence
{
	public:
		MSToteLiftPower(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		double lift_pwr;
		ToteLift *totelift;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSToteLiftSetPosition : public MacroStepSequence
{
	public:
		MSToteLiftSetPosition(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		ToteLift *totelift;

		ToteLift::Position position;
		float tolerance;
		double duration;
		double expire_time;
};

/******************************************************************************
 *
 ******************************************************************************/
class MSToteLiftSetPotPosition : public MacroStepSequence
{
	public:
	MSToteLiftSetPotPosition(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		ToteLift *totelift;

		float position;
		float tolerance;
		double duration;
		double expire_time;
};

/******************************************************************************
 *
 * wait for a tote, if one is found in time exit with true else after time
 * exit with false
 *
 ******************************************************************************/
class MSToteLiftWaitForTote : public MacroStepCondition
{
	public:
		MSToteLiftWaitForTote(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		ToteLift *totelift;

		int tote_slot;
		double duration;
		double expire_time;
};

/******************************************************************************
 *
 * wait for a tote, if one is found in time exit with true else after time
 * exit with false
 *
 ******************************************************************************/
class MSToteLiftEject : public MacroStepSequence
{
	public:
		MSToteLiftEject(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		ToteLift *totelift;

		double duration;
		double expire_time;
};
/******************************************************************************
 *
 * wait for a tote, if one is found in time exit with true else after time
 * exit with false
 *
 ******************************************************************************/
class MSToteLiftCheckMode : public MacroStepCondition
{
	public:
	MSToteLiftCheckMode(std::string type, tinyxml2::XMLElement *xml, void *control);
		void init(void);
		MacroStep * update(void);

	private:
		ToteLift *totelift;

		bool mode;
};

