/*******************************************************************************
 *
 * File: IntakeSystem.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <math.h>
#include <limits.h>
#include <gsi/Time.h>
#include "RobonautsLibrary/RobotUtil.h"

#include "IntakeSystem.h"

using namespace tinyxml2;
using namespace gsi;

/******************************************************************************
 * @param period	 Updated period in seconds. 	Constructor
 * 
 * 1 motor					done
 * 2 solenoids				done
 * 1 beam-break counter		done
 * 
 * Catching
 * 1 solenoid/relay			done
 * 1 sensor					
 ******************************************************************************/
IntakeSystem::IntakeSystem(PowerDistributionPanel* pb, tinyxml2::XMLElement *xml, double period) :
	PeriodicControl("Intake", period),
	data_log("intake","csv")
{
	printf("========================= Creating Intake System =========================\n");

	new MacroStepProxy<MSIntakePower>("intake", "IntakePower", this);
	new MacroStepProxy<MSIntakeSetJawOpen>("intake", "SetJawOpen", this);

	intake_ready = false;

	intake_motor_left = nullptr;
	intake_motor_right = nullptr;
	pot_left = nullptr;
	pot_right = nullptr;
	pid_left = nullptr;
	pid_right = nullptr;

	pto_sol_l = nullptr;
	pto_sol_r = nullptr;

	XMLElement *element = nullptr;
	const char *name = nullptr;

	power_board = pb;

	intake_motor_left_invert = 1.0;
	intake_motor_right_invert = 1.0;
	intake_motor_left_forward = 1.0;
	intake_motor_right_forward = 1.0;
	intake_motor_left_reverse = -1.0;
	intake_motor_right_reverse = -1.0;

	intake_jaw_motor_left_forward = 0.2;
	intake_jaw_motor_right_forward = 0.2;
	intake_jaw_motor_left_reverse = -0.2;
	intake_jaw_motor_right_reverse = -0.2;

	intake_motor_current_left = 0.0;
	intake_motor_current_right = 0.0;

	intake_motor_left_target = 0.0;
	intake_motor_right_target = 0.0;
	intake_motor_left_saved_target = 0.0;
	intake_motor_right_saved_target = 0.0;

	intake_motor_left_cmd = 0.0;
	intake_motor_right_cmd = 0.0;
	intake_max_power_delta = 0.2;

	pto_sol_invert_l = false;
	pto_sol_invert_r = false;
	pto_active_cmd = false;
	intake_jaw_desired_open = false;
	pto_engage_timeout = 0.0;
	pto_engage_delay = 0.1;

	intake_left_jaw_open = false;
	intake_right_jaw_open = false;

	stall_time_accum_left = 0.0;
	stall_time_accum_right = 0.0;

	stall_time = 0.5;
	stall_recover_time = 2.0;
	stall_current = 3.0;
	beach_stall_current = 20.0;

	left_port = 0;
	right_port = 0;

	thread_period = period;
	stall_out_left = false;
	stall_out_right = false;

	pot_left = nullptr;
	pot_right = nullptr;

	pot_left_ready = false;
	pot_left_raw = 0.0;
	pot_left_position = -999.99;

	pot_right_ready = false;
	pot_right_raw = 0.0;
	pot_right_position = -999.99;



	open_loop = true;

	element = xml->FirstChildElement("motor");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "intake_left") == 0)
			{
				printf("  creating speed_controller for %s\n", name);
				intake_motor_left = XmlRobotUtil::createSpeedController(element);
				left_port = element->IntAttribute("pb_port");
				intake_motor_left_invert = element->BoolAttribute("invert") ? -1.0 : 1.0;
			}
			else if(strcmp(name, "intake_right") == 0)
			{
				printf("  creating speed_controller for %s\n", name);
				intake_motor_right = XmlRobotUtil::createSpeedController(element);
				right_port = element->IntAttribute("pb_port");
				intake_motor_right_invert = element->BoolAttribute("invert") ? -1.0 : 1.0;
			}
		}
		element = element->NextSiblingElement("motor");
	}

	element = xml->FirstChildElement("solenoid");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "power_takeoff_l") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				pto_sol_l = XmlRobotUtil::createSolenoid(element);
				element->QueryBoolAttribute("invert", &pto_sol_invert_l);
			}
			if (strcmp(name, "power_takeoff_r") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				pto_sol_r = XmlRobotUtil::createSolenoid(element);
				element->QueryBoolAttribute("invert", &pto_sol_invert_r);
			}
		}

		element = element->NextSiblingElement("solenoid");
	}

	element = xml->FirstChildElement("pot");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "pot_left") == 0)
			{
				printf("  creating pot for %s\n", name);
				pot_left = XmlRobotUtil::createPot(element);
			}
			else if (strcmp(name, "pot_right") == 0)
			{
				printf("  creating pot for %s\n", name);
				pot_right = XmlRobotUtil::createPot(element);
			}
		}

		element = element->NextSiblingElement("pot");
	}

	// pid is for control of the rollers when they are being used to open
	// the intake jaw
	element = xml->FirstChildElement("pid");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "pid_left") == 0)
			{
				printf("  creating PID for %s\n", name);
				pid_left = XmlRobotUtil::createPID(element);
				pid_left->setParamPrefix("INTAKE_PID_LEFT");
			}
			else if (strcmp(name, "pid_right") == 0)
			{
				printf("  creating PID for %s\n", name);
				pid_right = XmlRobotUtil::createPID(element);
				pid_right->setParamPrefix("INTAKE_PID_RIGHT");
			}
		}

		element = element->NextSiblingElement("pid");
	}

	element = xml->FirstChildElement("oi");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if(strcmp(name,"roller_left_forward") == 0)
			{
				element->QueryFloatAttribute("speed", &intake_motor_left_forward);
				OIController::subscribeDigital(element, this, CMD_ROLLER_LEFT_FORWARD);
			}
			else if(strcmp(name,"roller_right_forward") == 0)
			{
				printf("  connecting intake forward right channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_right_forward);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_right_forward);
				OIController::subscribeDigital(element, this, CMD_ROLLER_RIGHT_FORWARD);
			}
			else if(strcmp(name,"roller_left_reverse") == 0)
			{
				printf("  connecting intake reverse left channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_left_reverse);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_left_reverse);
				OIController::subscribeDigital(element, this, CMD_ROLLER_LEFT_REVERSE);
			}
			else if(strcmp(name,"roller_right_reverse") == 0)
			{
				printf("  connecting intake reverse right channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_right_reverse);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_right_reverse);
				OIController::subscribeDigital(element, this, CMD_ROLLER_RIGHT_REVERSE);
			}
			else if(strcmp(name,"roller_left_forward_state") == 0)
			{
				printf("  connecting intake forward left state channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_left_forward);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_left_forward);
				OIController::subscribeDigital(element, this, CMD_ROLLER_LEFT_FORWARD_STATE);
			}
			else if(strcmp(name,"roller_right_forward_state") == 0)
			{
				printf("  connecting intake forward right state channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_right_forward);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_right_forward);
				OIController::subscribeDigital(element, this, CMD_ROLLER_RIGHT_FORWARD_STATE);
			}
			else if(strcmp(name,"roller_left_reverse_state") == 0)
			{
				printf("  connecting intake reverse left state channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_left_reverse);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_left_reverse);
				OIController::subscribeDigital(element, this, CMD_ROLLER_LEFT_REVERSE_STATE);
			}
			else if(strcmp(name,"roller_right_reverse_state") == 0)
			{
				printf("  connecting intake reverse right state channel\n");
				element->QueryFloatAttribute("speed", &intake_motor_right_reverse);
				element->QueryFloatAttribute("jawSpeed", &intake_jaw_motor_right_reverse);
				OIController::subscribeDigital(element, this, CMD_ROLLER_RIGHT_REVERSE_STATE);
			}
			else if(strcmp(name,"roller_left_stop") == 0)
			{
				printf("  connecting intake stop left channel\n");
				OIController::subscribeDigital(element, this, CMD_ROLLER_STOP);
			}
			else if(strcmp(name,"roller_right_stop") == 0)
			{
				printf("  connecting intake stop right channel\n");
				OIController::subscribeDigital(element, this, CMD_ROLLER_STOP);
			}
			else if(strcmp(name,"pto_toggle") == 0)
			{
				printf("  connecting intake pto toggle channel\n");
				OIController::subscribeDigital(element, this, CMD_PTO_TOGGLE);
				element->QueryDoubleAttribute("engage_delay", &pto_engage_delay);
			}
			else if(strcmp(name,"pto_state") == 0)
			{
				printf("  connecting intake pto state channel\n");
				OIController::subscribeDigital(element, this, CMD_PTO_STATE);
				element->QueryDoubleAttribute("engage_delay", &pto_engage_delay);
			}

			else
			{
				printf("  WARNING: found oi with unsupported name of \"%s\"\n", name);
			}
			element = element->NextSiblingElement("oi");
		}
		else
		{
			printf("  WARNING: found oi element that does not have a name\n");
		}
	}

}

/******************************************************************************
 * Destructor
 ******************************************************************************/
IntakeSystem::~IntakeSystem()
{
	printf("IntakeSystem::~IntakeSystem\n");
	if(intake_motor_left != nullptr)
	{
		delete intake_motor_left;
		intake_motor_left = nullptr;
	}

	if(intake_motor_right != nullptr)
	{
		delete intake_motor_right;
		intake_motor_right = nullptr;
	}

	if(pot_left != nullptr)
	{
		delete pot_left;
		pot_left = nullptr;
	}

	if(pot_right != nullptr)
	{
		delete pot_right;
		pot_right = nullptr;
	}

	if(pid_left != nullptr)
	{
		delete pid_left;
		pid_left = nullptr;
	}

	if(pid_right != nullptr)
	{
		delete pid_right;
		pid_right = nullptr;
	}

	if(pto_sol_l != nullptr)
	{
		delete pto_sol_l;
		pto_sol_l = nullptr;
	}

	if(pto_sol_r != nullptr)
	{
		delete pto_sol_r;
		pto_sol_r = nullptr;
	}

}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::controlInit()
{

	intake_ready = true;
	if (intake_motor_left == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Left Intake Motor\n");
		intake_ready = false;
	}

	if (intake_motor_right == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Right Intake Motor\n");
		intake_ready = false;
	}

	if (pot_left == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Left Intake Pot\n");
		intake_ready = false;
	}

	if (pot_right == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Right Intake Pot\n");
		intake_ready = false;
	}

	if (pid_left == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Left Intake PID\n");
		intake_ready = false;
	}

	if (pid_right == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Right Intake PID\n");
		intake_ready = false;
	}

	if (pto_sol_l == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Left Intake Power Take-off Solenoid\n");
		intake_ready = false;
	}

	if (pto_sol_r == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- did not create Right Intake Power Take-off Solenoid\n");
		intake_ready = false;
	}

	if (power_board == nullptr)
	{
		printf("WARNING: Intake Subsystem is not ready -- received NULL Power Board\n");
		intake_ready = false;
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::updateConfig()
{

	open_loop = Parameter::getAsBool("INTAKE_OPEN_LOOP", open_loop);

	stall_time = Parameter::getAsFloat("INTAKE_STALL_TIME", stall_time);
	stall_recover_time = Parameter::getAsFloat("INTAKE_STALL_RECOVER_TIME", stall_recover_time);
	stall_current = Parameter::getAsFloat("INTAKE_STALL_CURRENT", stall_current);
	beach_stall_current = Parameter::getAsFloat("INTAKE_BEACH_STALL_CURRENT", beach_stall_current);
	intake_max_power_delta = Parameter::getAsFloat("INTAKE_MAX_POWER_DELTA", intake_max_power_delta);
	pto_engage_delay = Parameter::getAsFloat("INTAKE_PTO_ENGAGE_DELAY",pto_engage_delay );
	intake_jaw_motor_left_forward = Parameter::getAsFloat("INTAKE_JAW_MOTOR_LEFT_FORWARD",
														intake_jaw_motor_left_forward );
	intake_jaw_motor_left_reverse = Parameter::getAsFloat("INTAKE_JAW_MOTOR_LEFT_REVERSE",
														intake_jaw_motor_left_reverse );
	intake_jaw_motor_right_forward = Parameter::getAsFloat("INTAKE_JAW_MOTOR_RIGHT_FORWARD",
														intake_jaw_motor_right_forward );
	intake_jaw_motor_right_reverse = Parameter::getAsFloat("INTAKE_JAW_MOTOR_RIGHT_REVERSE",
														intake_jaw_motor_right_reverse );

	pid_left->updateConfig();
	pid_right->updateConfig();

}



/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::disabledInit()
{
	data_log.close();
	intake_motor_left_target = 0.0;
	intake_motor_right_target = 0.0;
	pto_active_cmd = false;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::autonomousInit()
{
	initLogFile("Auton");
	intake_motor_left_target = 0.0;
	intake_motor_right_target = 0.0;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::teleopInit()
{
	initLogFile("Teleop");
	intake_motor_left_target = 0.0;
	intake_motor_right_target = 0.0;
}

/**********************************************************************
 *
 *
 **********************************************************************/
void IntakeSystem::testInit(void)
{
}


/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void IntakeSystem::setAnalog(int id, float val)
{
//	MutexScopeLock block(getLock());
	printf("IntakeSystem::setAnalog(%d, %f)\n", id, val);
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void IntakeSystem::setDigital(int id, bool val)
{
//	MutexScopeLock block(getLock());
	printf("IntakeSystem::setDigital(%d, %s)\n", id, val?"true":"false");
	switch(id)
	{
		case CMD_ROLLER_LEFT_FORWARD:
		{
			if(val && !intake_jaw_desired_open)
			{
				printf("intake_motor_left_forward : %f\n",intake_motor_left_forward);
				intake_motor_left_target = intake_motor_left_forward;
			}
		} break;

		case CMD_ROLLER_RIGHT_FORWARD:
		{
			if(val && !intake_jaw_desired_open)
			{
				printf("intake_motor_right_forward : %f\n",intake_motor_right_forward);
				intake_motor_right_target = intake_motor_right_forward;
			}
		} break;

		case CMD_ROLLER_LEFT_REVERSE:
		{
			if(val && !intake_jaw_desired_open)
			{
				printf("cmd_roller_left_reverse\n");
				intake_motor_left_target = intake_motor_left_reverse;
			}
		} break;

		case CMD_ROLLER_RIGHT_REVERSE:
		{
			if(val && !intake_jaw_desired_open)
			{
				intake_motor_right_target = intake_motor_right_reverse;
			}
		} break;

		case CMD_ROLLER_LEFT_FORWARD_STATE:
		{
			if(val && !intake_jaw_desired_open)
			{
				printf("CMD_ROLLER_LEFT_FORWARD_STATE\n");
				intake_motor_left_saved_target = intake_motor_left_target;
				intake_motor_left_target = intake_motor_left_forward;
			}
			else
			{printf("CMD_ROLLER_LEFT_FORWARD_STATE\n");
				intake_motor_left_target = intake_motor_left_saved_target;
			}
		} break;

		case CMD_ROLLER_RIGHT_FORWARD_STATE:
		{
			if(!intake_jaw_desired_open)
			{
				if(val)
				{
					intake_motor_right_saved_target = intake_motor_right_target;
					intake_motor_right_target = intake_motor_right_forward;
				}
				else
				{
					intake_motor_right_target = intake_motor_right_saved_target;
				}
			}
		} break;

		case CMD_ROLLER_LEFT_REVERSE_STATE:
		{
			if(!intake_jaw_desired_open)
			{
				if(val)
				{
					intake_motor_left_saved_target = intake_motor_left_target;
					intake_motor_left_target = intake_motor_left_reverse;
				}
				else
				{
					intake_motor_left_target = intake_motor_left_saved_target;
				}
			}
		} break;

		case CMD_ROLLER_RIGHT_REVERSE_STATE:
		{
			if(!intake_jaw_desired_open)
			{
				if(val)
				{
					intake_motor_right_saved_target = intake_motor_right_target;
					intake_motor_right_target = intake_motor_right_reverse;
				}
				else
				{
					intake_motor_right_target = intake_motor_right_saved_target;
				}
			}
		} break;

		case CMD_ROLLER_STOP:
		{
			if(val)
			{
				intake_motor_left_target = 0.0;
				intake_motor_right_target = 0.0;
			}
		} break;

		case CMD_PTO_TOGGLE:
		{
			if (val)
			{
				// if the pto is active, we can de-activate immediately
				if(pto_active_cmd)
				{
					releaseIntakeJaws();
				}
				else
				{
					openIntakeJaws();
				}

			}
		} break;
		case CMD_PTO_STATE:
		{
			if(val)
			{
				openIntakeJaws();
			}
			else
			{
				releaseIntakeJaws();
			}
		} break;
		case CMD_SET_OPENLOOP:
		{
			if(val)
			{
				open_loop = true;
			}
		}
	}
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void IntakeSystem::setInt(int id, int val)
{
//	MutexScopeLock block(getLock());
	printf("IntakeSystem::setInt(%d, %d)\n", id, val);
}
/******************************************************************************
 *
 * Implements method required by OIObserver
 *
 ******************************************************************************/
void IntakeSystem::intakePower(float left, float right)
{
//	MutexScopeLock block(getLock());
	printf("IntakeSystem::intakePower(%.3f, %.3f)\n", left, right);
	intake_motor_left_target = left;
	intake_motor_right_target = right;
}

/*****************************************************************************
 * openIntakeJaws
 * sets up the targets for opening the jaws
 *****************************************************************************/
void IntakeSystem::openIntakeJaws()
{
	// we don't want to activate while the motors are running
	// full speed, so we will set a desired command
	// set the motor speeds to 0.0 and start a timer
	// when the timer expires, then the desired command will become the actual

	intake_motor_left_target = 0.0;
	intake_motor_right_target = 0.0;
	intake_jaw_desired_open = true;
	pto_engage_timeout = gsi::Time::getTime() + pto_engage_delay;
}


/*****************************************************************************
 * releaseIntakeJaws
 * sets up the targets for releasing the intakeJaws
 *****************************************************************************/
void IntakeSystem::releaseIntakeJaws()
{
	// we don't want to activate while the motors are running
	// full speed, so we will set a desired command
	// set the motor speeds to 0.0 and start a timer
	// when the timer expires, then the desired command will become the actual

	pto_active_cmd = false;
	intake_jaw_desired_open = false;

	// stop the intake rollers from spinning
	// (they spin in the opposite direction for intake)
	intake_motor_left_target = 0.0;
	intake_motor_right_target = 0.0;
}

bool IntakeSystem::areIntakeJawsOpen()
{
	bool val = true;
	if(open_loop)
	{
		val = pto_active_cmd;
	}
	else
	{
		val = true;
//		if(fabs(pot_left_position - intake_left_position_target) < jaw_position_tolerance)
//			&& (fabs(pot_right_position - intake_right_position_target) < jaw_position_tolerance))
//		{
//			val = true;
//		}
//		else
//		{
//			val = false;
//		}
	}
	return(val);
}

/**********************************************************************
 *
 * This method is used to print a header line to the log
 * 
 * @param	phase	the name of the phase is used to name the log file
 * 
 **********************************************************************/
void IntakeSystem::initLogFile(std::string phase)
{
	data_log.initLog(phase);

	data_log.log("Time, %s,  %s,  %s, %s, %s, %s, %s,",
				"open_loop",
				"intake_motor_left_target","intake_motor_left_cmd","intake_motor_current_left",
				"intake_motor_right_target","intake_motor_right_cmd","intake_motor_current_right");

	data_log.log("%s, %s\n",
				"pto_active_cmd", "jaw_desired_open");

//
//	data_log.log("%s, \n",
//		"current_time");
}

/**********************************************************************
 *
 *
 **********************************************************************/
void IntakeSystem::writeLogMessage(void)
{
	// @TODO: should log stall_time_left and stall_time_right
	// === Logging
//	data_log.log("%8.6f, \n",
//		current_time);
//
	data_log.log("%8.6f,  %d,  %5.2f, %5.2f, %5.2f, %5.2f, %5.2f, %5.2f,",
			      gsi::Time::getTime(),
			      open_loop,
			      intake_motor_left_target,intake_motor_left_cmd,intake_motor_current_left,
				  intake_motor_right_target,intake_motor_right_cmd,intake_motor_current_right);

	data_log.log("%d, %d\n",pto_active_cmd, intake_jaw_desired_open);

}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean("  Intake  ", intake_ready && (getCyclesSincePublish() > 0));
	SmartDashboard::PutNumber("In_Cycles", getCyclesSincePublish());

	SmartDashboard::PutNumber("In_MotorTarget_L", intake_motor_left_target);
	SmartDashboard::PutNumber("In_MotorTarget_R", intake_motor_right_target);

	SmartDashboard::PutNumber("In_MotorCmd_L", intake_motor_left_cmd);
	SmartDashboard::PutNumber("In_MotorCmd_R", intake_motor_right_cmd);

	SmartDashboard::PutNumber("In_MotorCurrent_L", intake_motor_current_left);
	SmartDashboard::PutNumber("In_MotorCurrent_R", intake_motor_current_right);

	SmartDashboard::PutBoolean("In_PtoActiveCmd", pto_active_cmd);
	SmartDashboard::PutBoolean("In_JawDesiredCmd", intake_jaw_desired_open);

	SmartDashboard::PutNumber("Intake_JawPot_L",pot_left_position);
	SmartDashboard::PutNumber("Intake_JawPot_R",pot_right_position);
#endif
}

/******************************************************************************
 *
 * Returns the intake closed state
 *
 ******************************************************************************/
bool IntakeSystem::getIntakeClosed(void)
{
	return !intake_jaw_desired_open;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void IntakeSystem::doPeriodic()
{
	float desired_stall_current = stall_current;

	if (! intake_ready)
	{
		return;
	}

	{
//		MutexScopeLock block(getLock());

		//
		// Get Inputs
		//
		intake_motor_current_left = power_board->GetCurrent(left_port);
		intake_motor_current_right = power_board->GetCurrent(right_port);

		pot_left_ready = pot_left->isReady();
		pot_left_raw = pot_left->getRaw();
		pot_left_position = pot_left_ready ? pot_left->getPosition() : -999.99;

		pot_right_ready = pot_right->isReady();
		pot_right_raw = pot_right->getRaw();
		pot_right_position = pot_right_ready ? pot_right->getPosition() : -999.99;

		// if the desired jaw position is open and the pto is not yet active
		// the set the pto_active_cmd and set the motor_targets to reverse
		// at the "open jaw" speed
		if(intake_jaw_desired_open && (pto_engage_timeout < gsi::Time::getTime()))
		{
			pto_active_cmd = true;

			intake_motor_left_target = intake_jaw_motor_left_reverse;
			intake_motor_right_target = intake_jaw_motor_right_reverse;


		}
		if(intake_jaw_desired_open)
		{
			desired_stall_current = beach_stall_current;
		}

		// targets are all set before we get here, so it is all the same
		// to the control loop whether it is running rollers or opening the jaws
		// closed loop control is only for the intake jaw positioning
		// if the pto is not active, the rollers run open loop regardless of
		// the control type
		if(!pto_active_cmd || open_loop)
		{
			// Ramp the left power changes
			if (intake_motor_left_cmd + intake_max_power_delta < intake_motor_left_target)
			{
				intake_motor_left_cmd += intake_max_power_delta;
			}
			else if (intake_motor_left_cmd - intake_max_power_delta > intake_motor_left_target)
			{
				intake_motor_left_cmd -= intake_max_power_delta;
			}
			else
			{
				intake_motor_left_cmd = intake_motor_left_target;
			}

			// Ramp the right power changes
			if (intake_motor_right_cmd + intake_max_power_delta < intake_motor_right_target)
			{
				intake_motor_right_cmd += intake_max_power_delta;
			}
			else if (intake_motor_right_cmd - intake_max_power_delta > intake_motor_right_target)
			{
				intake_motor_right_cmd -= intake_max_power_delta;
			}
			else
			{
				intake_motor_right_cmd = intake_motor_right_target;
			}
		}
		else	// pto is active and closed loop
		{

			// if running in closed loop mode, the intake rollers have position control
			// when the pto is active
			intake_motor_left_cmd = pid_left->calculateControlValue(intake_motor_left_target,pot_left_position);
			intake_motor_right_cmd = pid_right->calculateControlValue(intake_motor_right_target,pot_right_position);


		}

		//
		// Over-current protection
		//
		if ((intake_motor_current_left > desired_stall_current) && (!stall_out_left))
		{
			if(stall_time_accum_left > stall_time)
			{
				stall_out_left = true;
				stall_time_accum_left = 0.0;
			}
			else
			{
				stall_time_accum_left += thread_period;
			}
		}
		else if(stall_out_left)
		{
			if(stall_time_accum_left > stall_recover_time)
			{
				stall_out_left = false;
			}
			else
			{
				intake_motor_left_cmd = 0.0;
				stall_time_accum_left += thread_period;
			}
		}
		else
		{
			stall_time_accum_left = 0.0;
		}

		if ((intake_motor_current_right > desired_stall_current) && (!stall_out_right))
		{
			if(stall_time_accum_right > stall_time)
			{
				stall_out_right = true;
				stall_time_accum_right = 0.0;
			}
			else
			{
				stall_time_accum_right += thread_period;
			}
		}
		else if(stall_out_right)
		{
			if(stall_time_accum_right > stall_recover_time)
			{
				stall_out_right = false;
			}
			else
			{
				intake_motor_right_cmd = 0.0;
				stall_time_accum_right += thread_period;
			}
		}
		else
		{
			stall_time_accum_right = 0.0;
		}

		//
		// Set Outputs
		//
		intake_motor_left->Set(intake_motor_left_cmd * intake_motor_left_invert);
		intake_motor_right->Set(intake_motor_right_cmd * intake_motor_right_invert);
		//printf("%f, pot: %f Target: %f\n",intake_motor_right_cmd,pot_left_position,pid_left->calculateControlValue(2.0,pot_left_position));

		if(pto_sol_invert_l)
		{
			pto_sol_l->Set(!pto_active_cmd);
		}
		else
		{
			pto_sol_l->Set(pto_active_cmd);
		}

		if(pto_sol_invert_r)
		{
			pto_sol_r->Set(!pto_active_cmd);
		}
		else
		{
			pto_sol_r->Set(pto_active_cmd);
		}

	} // end locked section

	writeLogMessage();
}

// =============================================================================
// === MSIntakePower Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSIntakePower::MSIntakePower(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	intake = (IntakeSystem *)control;
	left_pwr = xml->FloatAttribute("left_pwr");
	right_pwr = xml->FloatAttribute("right_pwr");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSIntakePower::init()
{
	intake->intakePower(left_pwr, right_pwr);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSIntakePower::update()
{
	return next_step;
}

// =============================================================================
// === MSIntakeSetJawOpen Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSIntakeSetJawOpen::MSIntakeSetJawOpen(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	intake = (IntakeSystem *)control;
	state = false;
	duration = 2.0;
	expire_time = 0.0;

	xml->QueryBoolAttribute("state", &state);
	xml->QueryDoubleAttribute("duration", &duration);
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSIntakeSetJawOpen::init(void)
{
	if (state)
	{
		printf("MSIntakeSetJawOpen::init openIntakeJaw\n");
		intake->openIntakeJaws();
	}
	else
	{
		printf("MSIntakeSetJawOpen::init releaseIntakeJaw\n");
		intake->releaseIntakeJaws();
	}

	expire_time = gsi::Time::getTime() + duration;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSIntakeSetJawOpen::update(void)
{
	if (state)
	{
		if (intake->areIntakeJawsOpen())
		{
			printf("MSIntakeSetJawOpen::update jaws are open\n");
			return next_step;
		}
	}
	else
	{
		if (! intake->areIntakeJawsOpen())
		{
			printf("MSIntakeSetJawOpen::update jaws are closed\n");
			return next_step;
		}
	}

	if (gsi::Time::getTime() > expire_time)
	{
		parent_macro->abort();
		return nullptr;
	}

	return this;
}

// =============================================================================
// === MSIntakePose Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
//MSIntakePose::MSIntakePose(std::string type, tinyxml2::XMLElement *xml, void *control) :
//	MacroStepSequence(type, xml, control)
//{
//	intake = (IntakeSystem *)control;
//	state = xml->BoolAttribute("state");
//}
//
///*******************************************************************************
// *
// ******************************************************************************/
//void MSIntakePose::init()
//{
//	intake->intakePower(left_pwr, right_pwr);
//}
//
///*******************************************************************************
// *
// ******************************************************************************/
//MacroStep *MSIntakePose::update()
//{
//	return next_step;
//}

