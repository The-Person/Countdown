/*******************************************************************************
 *
 * File: RobotMain.cpp
 *
 * Written by: 
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <cstring>
#include <math.h>
#include <string>
#include <cstdint>

#include "WPILib.h"

#include "gsu/tinyxml2.h"

#include "RobonautsLibrary/Parameter.h"
#include "RobonautsLibrary/Macro.h"
#include "RobonautsLibrary/MacroController.h"
#include "RobonautsLibrary/DataLogger.h"
#include "RobonautsLibrary/OIController.h"
#include "RobonautsLibrary/RPot.h"

#include "DriveSystem.h"
#include "IntakeSystem.h"
#include "CanDom.h"
#include "CanLift.h"
#include "ToteLift.h"
//#include "Lights.h"
#include "CompressorSys.h"
//#ifdef I_HAVE_OPENCV
//#include "CameraSys.h"
//#endif
#include "TestControl.h"

#include "RobotMain.h"

using namespace tinyxml2;

/*******************************************************************************
 *
 ******************************************************************************/
RobotMain::RobotMain(void)
{
	macro_controller	= nullptr;

	can_dom 			= nullptr;

	config_arm 		= false;
	config_load 	= false;
	config_loaded 	= false;
	config_updates 	= 0;
	
	auton_select			= 0;
	auton_select_mismatch	= -1;
	auton_select_loaded 	= -1;
	auton_enabled 			= true;
	auton_delay 			= 0.0;
	auton_delay_enabled 	= false;
	auton_start_time 		= 0.0;
	auton_started 			= false;
	auton_oi_configured 	= false;
	auton_description 		= "";

	is_a2dc_triggered_low = false;
	is_a2dc_triggered_high = false;
	is_a3dc_triggered_low = false;
	is_a3dc_triggered_high = false;

	publish_count = 0;

	power_board = nullptr;

	robot_phase = INIT;
}

/*******************************************************************************
 *
 ******************************************************************************/
RobotMain::~RobotMain()
{
	try
	{
		printf("RobotMain::~RobotMain\n");

		for(PeriodicControl *control : robot_controls)
		{
			delete control;
		}
		robot_controls.clear();

		if (macro_controller != nullptr)
		{
			delete macro_controller;
			macro_controller = nullptr;
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::~RobotMain\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::RobotInit(void)
{
	try
	{
		printf("RobotMain::RobotInit()\n");

		Parameter::setFilename("/config/RobotParameters.txt");
		Parameter::load();
		
		macro_controller = new MacroController();

		power_board = new PowerDistributionPanel();

		LoadRobot("/config/RobotControl.xml");

		for(PeriodicControl *control : robot_controls)
		{
			control->doControlInit();
		}

		for(PeriodicControl *control : robot_controls)
		{
			control->start();
		}

		UpdateConfig();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::RobotInit\n");
	}
}

/******************************************************************************
 * Loads the robot
 ******************************************************************************/
void RobotMain::LoadRobot(std::string file)
{
	XMLDocument doc;
	XMLElement *comp;
	const char *name;
	
	doc.LoadFile(file.c_str());
	XMLElement *robot = doc.FirstChildElement("robot");
	printf("############################## Loading Robot ##############################\n");
	
	if (robot == NULL)
	{
		printf("ERROR: could not read config file %s, no \"robot\" element\n",
			file.c_str());
	}
	else
	{
		XMLElement *oi_xml = robot->FirstChildElement("interface");
		if (oi_xml == NULL)
		{
			printf("ERROR: could not initialize OIController, no xml element named \"interface\"");
		}
		else
		{
			OIController::configure(oi_xml);
		}
		
		comp = robot->FirstChildElement("oi");
		while (comp != NULL)
		{
			name = comp->Attribute("name");
			if (name != NULL)
			{
				if (strcmp(name, "config_arm") == 0)
				{
					printf("  connecting to config_arm channel\n");
					OIController::subscribeDigital(comp, this, CMD_CONFIG_ARM);
				}	
				else if (strcmp(name, "config_load") == 0)
				{
					printf("  connecting to config_load channel\n");
					OIController::subscribeDigital(comp, this, CMD_CONFIG_LOAD);
				}	
				else if (strcmp(name, "auton_enable") == 0)
				{
					printf("  connecting to auton_enable channel\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_ENABLED);
				}	
				else if (strcmp(name, "auton_select_b0") == 0)
				{
					printf("  connecting to auton_select_b0 channel\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_SELECT_B0);
				}	
				else if (strcmp(name, "auton_select_b1") == 0)
				{
					printf("  connecting to auton_select_b1 channel\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_SELECT_B1);
				}	
				else if (strcmp(name, "auton_select_b2") == 0)
				{
					printf("  connecting to auton_select_b2 channel\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_SELECT_B2);
				}
				else if (strcmp(name, "auton_select_pov") == 0)
				{
					printf("  connecting to auton_select_pov channel\n");
					OIController::subscribeInt(comp, this, CMD_AUTON_SELECT_POV);
				}

				else if (strcmp(name, "auton_delay_enable") == 0)
				{
					printf("  connecting to auton_delay_enable channel\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_DELAY_ENABLED);
				}	
				else if (strcmp(name, "auton_delay_value") == 0)
				{
					printf("  connecting to auton_delay_value channel\n");
					OIController::subscribeAnalog(comp, this, CMD_AUTON_DELAY_VALUE);
				}	
				else if (strcmp(name, "auton_can_race_state") == 0)
				{
					printf("  connecting to auton can race state\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_CAN_RACE_STATE);
				}
				else if (strcmp(name, "auton_can_race_on") == 0)
				{
					printf("  connecting to auton can race on\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_CAN_RACE_ON);
				}
				else if (strcmp(name, "auton_can_race_off") == 0)
				{
					printf("  connecting to auton can race off\n");
					OIController::subscribeDigital(comp, this, CMD_AUTON_CAN_RACE_OFF);
				}
			}
			
			comp = comp->NextSiblingElement("oi");
		}

		DriveSystem 	*drive_system = nullptr;
		IntakeSystem 	*intake_system = nullptr;
						 can_dom = nullptr;  // defined in class
		CanLift 		*can_lift = nullptr;
		ToteLift 		*tote_lift = nullptr;
//		Lights 			*lights = nullptr;
		CompressorSys 	*compressor = nullptr;
//#ifdef I_HAVE_OPENCV
//		CameraSys		*camera_sys = nullptr;
//#endif
		TestControl     *test_control;

		try
		{
			comp = robot->FirstChildElement("drive_system");
			if (comp != nullptr)
			{
				drive_system = new DriveSystem(comp, XmlRobotUtil::getPeriod(comp));
				robot_controls.push_back(drive_system);
			}
		}
		catch (...) 
		{
			printf("ERROR: failed to create drive_system\n");
		}

		try
		{
			comp = robot->FirstChildElement("intake_system");
			if (comp != nullptr)
			{
				intake_system = new IntakeSystem(power_board, comp, XmlRobotUtil::getPeriod(comp));
				robot_controls.push_back(intake_system);
			}
		}
		catch (...) 
		{
			printf("ERROR: failed to create intake_system\n");
		}
		
		try
		{
			comp = robot->FirstChildElement("tote_lift");
			if (comp != nullptr)
			{
				tote_lift = new ToteLift(comp, XmlRobotUtil::getPeriod(comp));
				robot_controls.push_back(tote_lift);
			}
		}
		catch (...)
		{
			printf("ERROR: failed to create tote_lift\n");
		}

		try
		{
			comp = robot->FirstChildElement("can_dom");
			if (comp != nullptr)
			{
				can_dom = new CanDom(comp, XmlRobotUtil::getPeriod(comp));
				robot_controls.push_back(can_dom);
			}
		}
		catch (...) 
		{
			printf("ERROR: failed to create can_dom\n");
		}

		try
		{		
			comp = robot->FirstChildElement("can_lift");
			if (comp != nullptr)
			{
				can_lift = new CanLift(comp, XmlRobotUtil::getPeriod(comp));
				robot_controls.push_back(can_lift);
			}
		}
		catch (...) 
		{
			printf("ERROR: failed to create can_lift\n");
		}
		
//		try
//		{
//			comp = robot->FirstChildElement("lights");
//			if (comp != nullptr)
//			{
//				lights = new Lights(comp, XmlRobotUtil::getPeriod(comp));
//				robot_controls.push_back(lights);
//			}
//		}
//		catch (...)
//		{
//			printf("ERROR: failed to create lights\n");
//		}
//
		try
		{
			comp = robot->FirstChildElement("compressor");
			if (comp != nullptr)
			{
				compressor = new CompressorSys(power_board, comp, XmlRobotUtil::getPeriod(comp));
				robot_controls.push_back(compressor);
			}
		}
		catch (...)
		{
			printf("ERROR: failed to create compressor\n");
		}
//#ifdef I_HAVE_OPENCV
//		try
//		{
//			comp = robot->FirstChildElement("camera");
//			if (comp != nullptr)
//			{
//				camera_sys = new CameraSys(comp, XmlRobotUtil::getPeriod(comp));
//				robot_controls.push_back(camera_sys);
//			}
//		}
//		catch (...)
//		{
//			printf("ERROR: failed to create compressor\n");
//		}
//#endif
		try
		{
			comp = robot->FirstChildElement("test_control");
			if (comp != nullptr)
			{
				test_control = new TestControl(comp, XmlRobotUtil::getPeriod(comp));
				test_control->setMacroController(macro_controller);

				robot_controls.push_back(test_control);
			}
		}
		catch (...)
		{
			printf("ERROR: failed to create test_control\n");
		}


		printf("========================= Loading Macros =========================\n");
		comp = robot->FirstChildElement("macro");
		while (comp != NULL)
		{
			const char *macro_name = comp->Attribute("name");
			const char *macro_file = comp->Attribute("file");

			if ((macro_name != nullptr) && (macro_file != nullptr))
			{
				macro_controller->loadMacro(macro_name, macro_file, this);

				XMLElement *oi_xml = comp->FirstChildElement("oi");
				while (oi_xml != nullptr)
				{
					name = comp->Attribute("name");
					if (name != NULL)
					{
						if (strcmp(name, "a2dc_low") == 0)
						{
							printf("  connecting  macro %s to oi a2dc_low\n", macro_name);
							OIController::subscribeDigital(comp, this, CMD_CONFIG_ARM);
						}
						else
						{
							printf("  connecting macro %s to oi button\n", macro_name);
							OIController::subscribeDigital(oi_xml, this, CMD_START_MACRO + macro_name_list.size());
							oi_xml = oi_xml->NextSiblingElement("oi");
						}
					}
				}

				macro_name_list.push_back(macro_name);
				macro_file_list.push_back(macro_file);
			}
			else
			{
				printf("ERROR: could not load macro file\n");
			}
			comp = comp->NextSiblingElement("macro");
		}

		printf("========================= Connecting Subsystems =========================\n");
		//
		// Connect subsystems as needed
		//
		//if (intake != nullptr)
		//{
		//	intake->setPowerBoard(power_board);
		//}
		//
		if (tote_lift != nullptr)
		{
			tote_lift->setPowerBoard(power_board);
			tote_lift->setIntakeSystem(intake_system);
		}

//		if(lights != nullptr)
//		{
//			lights->setToteLift(tote_lift);
//			lights->setIntake(intake_system);
//			lights->setCanDom(can_dom);
//			lights->setMacroController(macro_controller);
//		}
	}

	printf("############################## Robot Loaded ##############################\n");
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::UpdateConfig(void)
{
	try
	{
		printf("RobotMain::UpdateConfig()\n");

		Parameter::load();
		
		UpdateAutonConfig();

		int macro_index = 0;
		for (std::string file : macro_file_list)
		{
			macro_controller->loadMacro(macro_name_list[macro_index], file, this);
			macro_index++;
		}

		for(PeriodicControl *control : robot_controls)
		{
			control->doUpdateConfig();
		}
		
		config_updates++;
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::UpdateConfig\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::UpdateAutonConfig(void)
{
	try
	{
		printf("RobotMain::UpdateAutonConfig()\n");

		if (! auton_oi_configured)
		{
			auton_select = Parameter::getAsInt("AUTON_SELECT", auton_select);
			auton_enabled = Parameter::getAsBool("AUTON_ENABLED", auton_enabled);
			auton_delay = Parameter::getAsFloat("AUTON_DELAY", auton_delay);
			auton_delay_enabled = Parameter::getAsBool("AUTON_DELAY_ENABLED", auton_delay_enabled);

			printf("RobotMain::UpdateAutonConfig -- PARAM enabled=%s, select=%d, delay_enabled=%s, delay=%5.3f\n",
					auton_enabled?"true":"false", auton_select, auton_delay_enabled?"true":"false", auton_delay);
		}
		else
		{
			printf("RobotMain::UpdateAutonConfig -- OI enabled=%s, select=%d, delay_enabled=%s, delay=%5.3f\n",
					auton_enabled?"true":"false", auton_select, auton_delay_enabled?"true":"false", auton_delay);
		}
		
		if (auton_enabled)
		{
			switch (auton_select)
			{
				case 7: 	macro_controller->loadMacro("auton", "/config/macros/Auton7.xml", this); break;
				case 6: 	macro_controller->loadMacro("auton", "/config/macros/Auton6.xml", this); break;
				case 5: 	macro_controller->loadMacro("auton", "/config/macros/Auton5.xml", this); break;
				case 4: 	macro_controller->loadMacro("auton", "/config/macros/Auton4.xml", this); break;
				case 3: 	macro_controller->loadMacro("auton", "/config/macros/Auton3.xml", this); break;
				case 2: 	macro_controller->loadMacro("auton", "/config/macros/Auton2.xml", this); break;
				case 1: 	macro_controller->loadMacro("auton", "/config/macros/Auton1.xml", this); break;

				case 0: 
				default:
				{
					auton_select = 0;
					macro_controller->loadMacro("auton", "/config/macros/Auton0.xml", this);
				} break;
			}
			
			auton_select_loaded = auton_select;
			auton_select_mismatch = 0;
			auton_description = macro_controller->getMacro("auton")->getDescription();
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::UpdateAutonConfig\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::DisabledInit(void)
{
	robot_phase = DISABLED;
	printf("RobotMain::DisabledInit()\n");

	try
	{
		macro_controller->abortAll();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::DisabledInit\n");
	}

	for(PeriodicControl *control : robot_controls)
	{
		control->doDisabledInit();
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::AutonomousInit(void)
{
	robot_phase = AUTON;
	printf("RobotMain::AutonomousInit()\n");

	try
	{
		macro_controller->abortAll();

		auton_started = false;
		if (auton_enabled)
		{
			auton_start_time = GetTime();

			if (auton_delay_enabled)
			{
				auton_start_time += auton_delay;
			}
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::AutonomousInit\n");
	}

	for(PeriodicControl *control : robot_controls)
	{
		control->doAutonomousInit();
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::TeleopInit(void)
{
	robot_phase = TELEOP;
	printf("RobotMain::TeleopInit()\n");

	try
	{
		macro_controller->abortAll();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::TeleopInit\n");
	}

	for(PeriodicControl *control : robot_controls)
	{
		control->doTeleopInit();
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::TestInit(void)
{
	robot_phase = TEST;
	printf("RobotMain::TestInit()\n");

	try
	{
		macro_controller->abortAll();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::TestInit\n");
	}

	for(PeriodicControl *control : robot_controls)
	{
		control->doTestInit();
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::DisabledPeriodic(void)
{
	try
	{
		OIController::update();
	
		if(config_arm && config_load)
		{
			if (! config_loaded)
			{
				UpdateConfig();
				config_loaded = true;
			}
		}
		else
		{
			config_loaded = false;
		}
	
		if ((auton_enabled) && (auton_select_loaded != auton_select))
		{
			// 60 cycles should be about 3 seconds, that should be enough
			// time for the user to finish adjusting the rotary switch
			if(auton_select_mismatch++ > 60)
			{
				UpdateAutonConfig();
			}
		}
	
		publish();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::DisabledPeriodic\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::AutonomousPeriodic(void)
{
	try
	{
		OIController::update();

		if ((auton_enabled) && (GetTime() >= auton_start_time) && (! auton_started))
		{
			macro_controller->startMacro("auton");
			auton_started = true;
		}
		
		macro_controller->update();
		publish();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::AutonomousPeriodic\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
static int cycles = 0;
void RobotMain::TeleopPeriodic(void)
{
	cycles++;

	try
	{
		OIController::update();

		macro_controller->update();
		publish();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::TeleopPeriodic\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::TestPeriodic(void)
{
	try
	{
		OIController::update();
		macro_controller->update();
		publish();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::TestPeriodic\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::publish(void)
{
	try
	{
		if (publish_count++ >= 20)
		{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
			//
			// Publish Main Values
			//
			SmartDashboard::PutBoolean("Auton Enabled", auton_enabled);
			SmartDashboard::PutNumber("Auton Selected", auton_select);
			SmartDashboard::PutNumber("Auton Delay", auton_delay_enabled ? auton_delay : 0.0);
			SmartDashboard::PutString("Auton Description", auton_description);

			SmartDashboard::PutNumber("Config Loads", config_updates);

			SmartDashboard::PutNumber("Macro Starts:", this->macro_controller->getMacroStarts());
			SmartDashboard::PutNumber("Macro Completes:", this->macro_controller->getMacroCompletes());
			SmartDashboard::PutNumber("Macro Aborts:", this->macro_controller->getMacroAborts());
			SmartDashboard::PutNumber("Macros Running:", this->macro_controller->getMacrosRunning());
#endif
			for(PeriodicControl *control : robot_controls)
			{
				control->doPublish();
			}

			publish_count = 0;
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::publish\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::setAnalog(int id, float val)
{
	try
	{
//		printf("RobotMain::setAnalog(%d, %f)\n", id, val);

		switch (id)
		{
			case CMD_AUTON_DELAY_VALUE: 
			{
				auton_delay = val;
			} break;

			case CMD_A2DC:
			{
				if (is_a2dc_triggered_high)
				{
					if (val < 0.4)
					{
						is_a2dc_triggered_high = false;
						setDigital(CMD_A2DC_HIGH, false);
					}
				}
				else if (is_a2dc_triggered_low)
				{
					if (val > -0.4)
					{
						is_a2dc_triggered_low = false;
						setDigital(CMD_A2DC_LOW, false);
					}
				}
				else
				{
					if (val > 0.6)
					{
						is_a2dc_triggered_high = true;
						setDigital(CMD_A2DC_HIGH, true);
					}
					else if (val < -0.6)
					{
						is_a2dc_triggered_low = true;
						setDigital(CMD_A2DC_LOW, true);
					}
				}
			} break;

			case CMD_A3DC:
			{
				if (is_a3dc_triggered_high)
				{
					if (val < 0.4)
					{
						is_a3dc_triggered_high = false;
						setDigital(CMD_A3DC_HIGH, false);
					}
				}
				else if (is_a3dc_triggered_low)
				{
					if (val > -0.4)
					{
						is_a3dc_triggered_low = false;
						setDigital(CMD_A3DC_LOW, false);
					}
				}
				else
				{
					if (val > 0.6)
					{
						is_a3dc_triggered_high = true;
						setDigital(CMD_A3DC_HIGH, true);
					}
					else if (val < -0.6)
					{
						is_a3dc_triggered_low = true;
						setDigital(CMD_A3DC_LOW, true);
					}
				}
			} break;
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::setAnalog\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::setDigital(int id, bool val)
{
	try
	{
		printf("RobotMain::setDigital(%d, %d)\n", id, val);

		switch(id)
		{
			case CMD_CONFIG_ARM:
			{
				config_arm = val;
				printf("RobotMain::setDigital config arm: %d\n", val);
			} break;
			
			case CMD_CONFIG_LOAD:
			{
				config_load = val;
				printf("RobotMain::setDigital config load: %d\n", val);
			} break;
			
			case CMD_AUTON_ENABLED:
			{
				auton_enabled = val;
				auton_oi_configured = true;
			} break;
			
			case CMD_AUTON_SELECT_B0:
			{
				if (val) auton_select |= (0x01); else auton_select &= (0x06);
				auton_oi_configured = true;
			} break;
	
			case CMD_AUTON_SELECT_B1:
			{
				if (val) auton_select |= (0x02); else auton_select &= (0x05);
				auton_oi_configured = true;
			} break;
	
			case CMD_AUTON_SELECT_B2:
			{
				if (val) auton_select |= (0x04); else auton_select &= (0x03);
				auton_oi_configured = true;
			} break;
				
			case CMD_AUTON_DELAY_ENABLED:
			{
				auton_delay_enabled = val;
				auton_oi_configured = true;
			} break;

			case CMD_AUTON_CAN_RACE_STATE:
			{
				if ((can_dom != NULL) && (auton_select == 2))
				{
					can_dom->setLatchOpen(val, val, val);
				}
			} break;

			case CMD_AUTON_CAN_RACE_ON:
			{
				if ((can_dom != NULL) && (val) && (auton_select == 2))
				{
					can_dom->setLatchOpen(true, true, true);
				}
			} break;

			case CMD_AUTON_CAN_RACE_OFF:
			{
				if ((can_dom != NULL) && (val) && (auton_select == 2))
				{
					can_dom->setLatchOpen(false, false, false);
				}
			} break;

			case CMD_A2DC_LOW:
			{

			} break;

			case CMD_A2DC_HIGH:
			{

			} break;

			case CMD_A3DC_LOW:
			{

			} break;

			case CMD_A3DC_HIGH:
			{

			} break;

			default:
			{
				if ((id >= CMD_START_MACRO) && (id < CMD_START_MACRO_MAX) &&
					(robot_phase != INIT) && (robot_phase != DISABLED))
				{
					if (val)
					{
						macro_controller->startMacro(macro_name_list[id - CMD_START_MACRO]);
					}
				}
			} break;
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::setDigital\n");
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void RobotMain::setInt(int id, int val)
{
	try
	{
		printf("RobotMain::setInt(%d, %d)\n", id, val);
		switch (id)
		{
			case CMD_AUTON_SELECT_POV:
			{
				auton_oi_configured = true;
				if ((val >= 0) && (val <= 360))
				{
					auton_select = val/45;
					auton_enabled = true;
				}
				else
				{
					auton_enabled = false;
				}

			} break;
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::setInt\n");
	}
}


START_ROBOT_CLASS(RobotMain)
