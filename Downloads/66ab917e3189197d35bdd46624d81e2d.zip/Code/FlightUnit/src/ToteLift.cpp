/*******************************************************************************
 *
 * File: ToteLift.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <math.h>

#include "gsi/Time.h"

#include "RobonautsLibrary/RobotUtil.h"
#include "RobotMain.h"

#include "ToteLift.h"

using namespace tinyxml2;
using namespace gsi;
//
//const char * ToteLift::PositionNames[] =
//{
//	"BotLimit", "Pickup1", "LowDrive",
//	"Step0Deploy", "Pickup2", "Intake1", "Step1Deploy",
//	"5Stack007", "Intake2", "HPIntake", "Intake3"
//};


/******************************************************************************
 *
 * Create an instance of the Tote Lift
 *
 ******************************************************************************/
ToteLift::ToteLift(tinyxml2::XMLElement *xml, double period)
	: PeriodicControl("ToteLift", period)
	, lift_data_log("tote_lift", "csv")
{
	printf("========================= Creating Tote Lift =========================\n");

	new MacroStepProxy<MSToteLiftPower>("totelift", "ToteLiftPwr", this);
	new MacroStepProxy<MSToteLiftSetPosition>("totelift", "SetLiftPosition", this);
	new MacroStepProxy<MSToteLiftSetPotPosition>("totelift", "SetLiftPotPosition", this);
	new MacroStepProxy<MSToteLiftWaitForTote>("totelift", "WaitForTote", this);
	new MacroStepProxy<MSToteLiftEject>("totelift", "Eject", this);
	new MacroStepProxy<MSToteLiftCheckMode>("totelift", "MSToteLiftCheckMode", this);

	XMLElement *element;
	const char *name;
	lift_initialized = false;

	lift_power_board = nullptr;
	lift_intake_system = nullptr;

	lift_motor_a	= nullptr;
	lift_motor_b	= nullptr;
	lift_eject_sol	= nullptr;
	lift_pos_pot	= nullptr;
	lift_top_limit_sw = nullptr;
	lift_bot_limit_sw = nullptr;
	lift_tote_pos1_sw = nullptr;
	lift_tote_pos2_sw = nullptr;

	lift_pid = nullptr;

	lift_motor_a_invert = 1.0;   // -1.0 to invert, 1.0 to not invert
	lift_motor_b_invert = 1.0;   // -1.0 to invert, 1.0 to not invert
	lift_initialized = false;

	lift_eject_invert = false;
	lift_top_limit_invert = true;
	lift_bot_limit_invert = true;
	lift_tote_pos1_invert = true;
	lift_tote_pos2_invert = true;

	landfill_mode = false;
	hp_mode = false;

	lift_top_limit_pressed = false;
	lift_bot_limit_pressed = false;
	lift_tote_pos1_pressed = false;
	lift_tote_pos2_pressed = false;

	lift_pos_pot_ready = false;
	lift_pos_pot_raw = -9.99;
	lift_pos_pot_position = -999.99;

	lift_target_power = 0.0;
	lift_command_power = 0.0;
	lift_max_power_delta = 0.1;

	lift_motor_current = 0.0;
	lift_motor_stall = false;
	lift_motor_stall_time = 0.0;
	lift_pb_a_port = 0;
	lift_pb_b_port = 0;

	lift_increment_step = 0.05;
	lift_decrement_step = 0.05;
	lift_up_power = 0.2;
	lift_down_power = 0.15;
	lift_target_position = 0.0;

	lift_pos_adjust_scale = 0.5; // inches per cycle at max joystick

	lift_closed_loop = false;

	lift_stall_time = 0.7;
	lift_stall_recover_time = 0.5;
	lift_stall_current = 10.0;

	lift_tote_positions[LIFT_LVL_BOT_LIMIT]		= 8.5;
	lift_tote_positions[LIFT_LVL_PICKUP1] 		= 9.0;
	lift_tote_positions[LIFT_LVL_LOW_DRIVE] 	= 12.5;
	lift_tote_positions[LIFT_LVL_STEP0_DEPLOY] 	= 18.0;
	lift_tote_positions[LIFT_LVL_PICKUP2] 		= 21.0;
	lift_tote_positions[LIFT_LVL_INTAKE1] 		= 24.0;
	lift_tote_positions[LIFT_LVL_STEP1_DEPLOY] 	= 25.0;
	lift_tote_positions[LIFT_LVL_5STACK007]		= 35.4;
	lift_tote_positions[LIFT_LVL_INTAKE2] 		= 37.0;
	lift_tote_positions[LIFT_LVL_HPINTAKE]		= 41.0;
	lift_tote_positions[LIFT_LVL_INTAKE3] 		= 44.0;

	lift_position_index = LIFT_LVL_INTAKE1;

	lift_eject_cmd = false;

	//
	// Parse the XML
	//
	element = xml->FirstChildElement("motor");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "lift_a") == 0)
			{
				printf("  creating speed_controller for %s\n", name);
				lift_motor_a = XmlRobotUtil::createSpeedController(element);
				lift_motor_a_invert = element->BoolAttribute("invert") ? -1.0 : 1.0;
				element->QueryIntAttribute("pb_port", &lift_pb_a_port);

				printf("ToteLift PB a port: %d\n", lift_pb_a_port);
			}
			else if (strcmp(name, "lift_b") == 0)
			{
				printf("  creating speed_controller for %s\n", name);
				lift_motor_b = XmlRobotUtil::createSpeedController(element);
				lift_motor_b_invert = element->BoolAttribute("invert") ? -1.0 : 1.0;
				element->QueryIntAttribute("pb_port", &lift_pb_b_port);

				printf("ToteLift PB b port: %d\n", lift_pb_b_port);
			}
		}

		element = element->NextSiblingElement("motor");
	}

	element = xml->FirstChildElement("solenoid");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "eject_sol") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				lift_eject_sol = XmlRobotUtil::createSolenoid(element);
				element->QueryBoolAttribute("invert", &lift_eject_invert);
			}
		}

		element = element->NextSiblingElement("solenoid");
	}

	element = xml->FirstChildElement("pot");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "lift_pos") == 0)
			{
				printf("  creating pot for %s\n", name);
				lift_pos_pot = XmlRobotUtil::createPot(element);
			}
		}

		element = element->NextSiblingElement("pot");
	}

	element = xml->FirstChildElement("pid");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "lift_pid") == 0)
			{
				printf("  creating PID for %s\n", name);
				lift_pid = XmlRobotUtil::createPID(element);
				lift_pid->setParamPrefix("TOTE_LIFT_PID");
			}
		}

		element = element->NextSiblingElement("pid");
	}

	element = xml->FirstChildElement("digital_input");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "top_limit") == 0)
			{
				printf("  creating digital input for %s\n", name);
				lift_top_limit_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &lift_top_limit_invert);
			}
			else if (strcmp(name, "bottom_limit") == 0)
			{
				printf("  creating digital input for %s\n", name);
				lift_bot_limit_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &lift_bot_limit_invert);
			}
			if (strcmp(name, "tote_one") == 0)
			{
				printf("  creating digital input for %s\n", name);
				lift_tote_pos1_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &lift_tote_pos1_invert);
			}
			else if (strcmp(name, "tote_two") == 0)
			{
				printf("  creating digital input for %s\n", name);
				lift_tote_pos2_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &lift_tote_pos2_invert);
			}
		}
		element = element->NextSiblingElement("digital_input");
	}

	element = xml-> FirstChildElement("oi");
	while (element != NULL)
	{
		name = element->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "lift_power") == 0)
			{
				printf("  connecting to lift power channel\n");
				OIController::subscribeAnalog(element, this, CMD_LIFT_POWER);
			}
			else if (strcmp(name, "increment") == 0)
			{
				printf("  connecting to increment channel\n");
				OIController::subscribeDigital(element, this, CMD_STEP_UP);
				element->QueryFloatAttribute("step", &lift_increment_step);
			}
			else if (strcmp(name, "decrement") == 0)
			{
				printf("  connecting to decrement channel\n");
				OIController::subscribeDigital(element, this, CMD_STEP_DOWN);
				element->QueryFloatAttribute("step", &lift_decrement_step);
			}
			else if (strcmp(name, "momentary_up") == 0)
			{
				printf("  connecting to momentary up channel\n");
				OIController::subscribeDigital(element, this, CMD_MOMENTARY_UP);
				lift_up_power = RobotUtil::limit(-1.0, 1.0, element->FloatAttribute("value"));
			}
			else if (strcmp(name, "momentary_down") == 0)
			{
				printf("  connecting to momentary down channel\n");
				OIController::subscribeDigital(element, this, CMD_MOMENTARY_DOWN);
				lift_down_power = RobotUtil::limit(-1.0, 1.0, element->FloatAttribute("value"));
			}
			else if (strcmp(name, "stop") == 0)
			{
				printf("  connecting to stop channel\n");
				OIController::subscribeDigital(element, this, CMD_STOP);
			}
			else if (strcmp(name, "closed_loop") == 0)
			{
				printf("  connecting to closed loop channel\n");
				OIController::subscribeDigital(element, this, CMD_CLOSED_LOOP);
			}
			else if (strcmp(name, "CMD_LIFT_POSITION") == 0)
			{
				printf("  connecting to CMD_LIFT_POSITION channel\n");
				OIController::subscribeInt(element, this, CMD_LIFT_POSITION);
			}
			else if (strcmp(name, "eject") == 0)
			{
				printf("  connecting to eject channel\n");
				OIController::subscribeDigital(element, this, CMD_EJECT_SOLINOID);
			}
			else if (strcmp(name, "landfill_mode") == 0)
			{
				printf("  connecting to landfill_mode channel\n");
				OIController::subscribeDigital(element, this, CMD_LANDFILL_MODE);
			}
			else if (strcmp(name, "hp_mode") == 0)
			{
				printf("  connecting to hp_mode channel\n");
				OIController::subscribeDigital(element, this, CMD_HP_MODE);
			}

		}
		element = element->NextSiblingElement("oi");
	}
}

/******************************************************************************
 *
 * Destructor
 *
 ******************************************************************************/
ToteLift::~ToteLift()
{
	printf("ToteLift::~ToteLift\n");

	if (lift_motor_a != nullptr)
	{
		delete lift_motor_a;
		lift_motor_a = nullptr;
	}

	if (lift_motor_b != nullptr)
	{
		delete lift_motor_b;
		lift_motor_b = nullptr;
	}

	if (lift_eject_sol != nullptr)
	{
		delete lift_eject_sol;
		lift_eject_sol = nullptr;
	}

	if (lift_pos_pot != nullptr)
	{
		delete lift_pos_pot;
		lift_pos_pot = nullptr;
	}

	if (lift_top_limit_sw != nullptr)
	{
		delete lift_top_limit_sw;
		lift_top_limit_sw = nullptr;
	}

	if (lift_bot_limit_sw != nullptr)
	{
		delete lift_bot_limit_sw;
		lift_bot_limit_sw = nullptr;
	}

	if (lift_tote_pos1_sw != nullptr)
	{
		delete lift_tote_pos1_sw;
		lift_tote_pos1_sw = nullptr;
	}

	if (lift_tote_pos2_sw != nullptr)
	{
		delete lift_tote_pos2_sw;
		lift_tote_pos2_sw = nullptr;
	}

	if (lift_pid != nullptr)
	{
		delete lift_pid;
		lift_pid = nullptr;
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void ToteLift::controlInit()
{
	lift_initialized = true;

	if (lift_motor_a == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Lift Motor A\n");
		lift_initialized = false;
	}

	if (lift_motor_b == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Lift Motor B\n");
		lift_initialized = false;
	}

	if (lift_eject_sol == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Solenoid\n");
		lift_initialized = false;
	}

	if (lift_pos_pot == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Position pot sensor\n");
		lift_initialized = false;
	}

	if (lift_top_limit_sw == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Top limit switch\n");
		lift_initialized = false;
	}

	if (lift_bot_limit_sw == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Bot limit Switch\n");
		lift_initialized = false;
	}

	if (lift_tote_pos1_sw == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Tote pos 1 Switch\n");
		lift_initialized = false;
	}

	if (lift_tote_pos2_sw == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create Tote pos 2 Switch\n");
		lift_initialized = false;
	}

	if (lift_pid == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, did not create pid\n");
		lift_initialized = false;
	}

	if (lift_power_board == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, power board not set correctly\n");
		lift_initialized = false;
	}

	if (lift_intake_system == nullptr)
	{
		printf("WARNING: Tote Lift not initialized, intake system not set correctly\n");
		lift_initialized = false;
	}
}

/******************************************************************************
 *
 ******************************************************************************/
ToteLift::Position ToteLift::getPostitionFromName(const char *name)
{
//	for(int i = 0; i < LIFT_LVL_NUM_POSITIONS; i++)
//	{
//		if (strcmp(name, PositionNames[i]) == 0)
//		{
//			return ((Position)i);
//		}
//	}

		if (strcmp(name, "BotLimit") == 0) return LIFT_LVL_BOT_LIMIT;
		else if (strcmp(name, "Pickup1") == 0) return LIFT_LVL_PICKUP1;
		else if (strcmp(name, "LowDrive") == 0) return LIFT_LVL_LOW_DRIVE;
		else if (strcmp(name, "Step0Deploy") == 0) return LIFT_LVL_STEP0_DEPLOY;
		else if (strcmp(name, "Pickup2") == 0) return LIFT_LVL_PICKUP2;
		else if (strcmp(name, "Intake1") == 0) return LIFT_LVL_INTAKE1;
		else if (strcmp(name, "Step1Deploy") == 0) return LIFT_LVL_STEP1_DEPLOY;
		else if (strcmp(name, "5Stack007") == 0) return LIFT_LVL_5STACK007;
		else if (strcmp(name, "Intake2") == 0) return LIFT_LVL_INTAKE2;
		else if (strcmp(name, "HPIntake") == 0) return LIFT_LVL_HPINTAKE;
		else if (strcmp(name, "Intake3") == 0) return LIFT_LVL_INTAKE3;
		else

	return LIFT_LVL_NUM_POSITIONS;
}

/******************************************************************************
 *
 ******************************************************************************/
void ToteLift::setPowerBoard(PowerDistributionPanel* pb)
{
	lift_power_board = pb;
}

/******************************************************************************
 *
 ******************************************************************************/
void ToteLift::setIntakeSystem(IntakeSystem *intake_sys)
{
	lift_intake_system = intake_sys;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void ToteLift::updateConfig()
{
	lift_closed_loop = Parameter::getAsBool("TOTE_LIFT_CLOSED_LOOP", lift_closed_loop);

	lift_stall_time = Parameter::getAsFloat("TOTE_LIFT_STALL_TIME", lift_stall_time);
	lift_stall_recover_time = Parameter::getAsFloat("TOTE_LIFT_STALL_RECOVER_TIME", lift_stall_recover_time);
	lift_stall_current = Parameter::getAsFloat("TOTE_LIFT_STALL_CURRENT", lift_stall_current);

	lift_max_power_delta = Parameter::getAsFloat("TOTE_LIFT_MAX_POWER_DELTA", lift_max_power_delta);

	lift_tote_positions[LIFT_LVL_BOT_LIMIT] = Parameter::getAsFloat("TOTE_LIFT_LVL_BOT_LIMIT", lift_tote_positions[LIFT_LVL_BOT_LIMIT]);
	lift_tote_positions[LIFT_LVL_PICKUP1] = Parameter::getAsFloat("TOTE_LIFT_LVL_PICKUP1", lift_tote_positions[LIFT_LVL_PICKUP1]);
	lift_tote_positions[LIFT_LVL_LOW_DRIVE] = Parameter::getAsFloat("TOTE_LIFT_LVL_LOW_DRIVE", lift_tote_positions[LIFT_LVL_LOW_DRIVE]);
	lift_tote_positions[LIFT_LVL_STEP0_DEPLOY] = Parameter::getAsFloat("TOTE_LIFT_LVL_STEP0_DEPLOY", lift_tote_positions[LIFT_LVL_STEP0_DEPLOY]);
	lift_tote_positions[LIFT_LVL_PICKUP2] = Parameter::getAsFloat("TOTE_LIFT_LVL_PICKUP2", lift_tote_positions[LIFT_LVL_PICKUP2]);
	lift_tote_positions[LIFT_LVL_INTAKE1] = Parameter::getAsFloat("TOTE_LIFT_LVL_INTAKE1", lift_tote_positions[LIFT_LVL_INTAKE1]);
	lift_tote_positions[LIFT_LVL_STEP1_DEPLOY]  = Parameter::getAsFloat("TOTE_LIFT_LVL_STEP1_DEPLOY", lift_tote_positions[LIFT_LVL_STEP1_DEPLOY]);
	lift_tote_positions[LIFT_LVL_5STACK007]  = Parameter::getAsFloat("TOTE_LIFT_LVL_5STACK007", lift_tote_positions[LIFT_LVL_5STACK007]);
	lift_tote_positions[LIFT_LVL_INTAKE2]  = Parameter::getAsFloat("TOTE_LIFT_LVL_INTAKE2", lift_tote_positions[LIFT_LVL_INTAKE2]);
	lift_tote_positions[LIFT_LVL_HPINTAKE]  = Parameter::getAsFloat("TOTE_LIFT_LVL_HPINTAKE", lift_tote_positions[LIFT_LVL_HPINTAKE]);
	lift_tote_positions[LIFT_LVL_INTAKE3]  = Parameter::getAsFloat("TOTE_LIFT_LVL_INTAKE3", lift_tote_positions[LIFT_LVL_INTAKE3]);

	float ips = lift_pos_adjust_scale / getPeriod();
	ips = Parameter::getAsFloat("TOTE_LIFT_POS_ADJUST_IPS", ips);
	lift_pos_adjust_scale = ips * getPeriod();

	if (lift_pid != nullptr)
	{
		lift_pid->updateConfig();
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void ToteLift::disabledInit()
{
	lift_data_log.close();
	lift_target_power = 0.0;
	lift_command_power = 0.0;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void ToteLift::autonomousInit()
{
	initLogFile("Auton");
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void ToteLift::teleopInit()
{
	initLogFile("Teleop");
}

/**********************************************************************
 *
 **********************************************************************/
void ToteLift::testInit(void)
{
	initLogFile("Test");
}

/**********************************************************************
 *
 **********************************************************************/
void ToteLift::toteLiftPower(float pwr)
{
	lift_command_power = pwr;
}

/******************************************************************************
 *
 ******************************************************************************/
void ToteLift::setPosition(Position pos)
{
	if ((pos >= LIFT_LVL_BOT_LIMIT) && (pos < LIFT_LVL_NUM_POSITIONS))
	{
		setPosition(lift_tote_positions[pos]);
		lift_position_index = pos;
	}
}

/******************************************************************************
 *
 ******************************************************************************/
void ToteLift::setStop(void)
{
	setPosition(lift_pos_pot_position);
	lift_command_power = 0.0;
}

/******************************************************************************
 *
 ******************************************************************************/
bool ToteLift::isPosition(Position pos, float tolerance)
{
	if ((pos >= LIFT_LVL_BOT_LIMIT) && (pos < LIFT_LVL_NUM_POSITIONS))
	{
		return isPosition(lift_tote_positions[pos], tolerance);
	}
	return false;
}

/******************************************************************************
 *
 ******************************************************************************/
void ToteLift::setPosition(float pos)
{
	lift_target_position = pos;
}

/******************************************************************************
 *
 ******************************************************************************/
bool ToteLift::isPosition(float pos, float tolerance)
{
	return (fabs(lift_target_position - lift_pos_pot_position) < tolerance);
}

/******************************************************************************
 *
 ******************************************************************************/
bool ToteLift::isToteDetected(int slot)
{
	if (slot == 1)
	{
		return lift_tote_pos1_pressed;
	}
	else if (slot == 2)
	{
		return lift_tote_pos2_pressed;
	}
	else
	{
		return false;
	}
}

float ToteLift::getLiftHeight(void)
{
	return lift_pos_pot_position;
}


bool ToteLift::getHpMode()
{
	return(landfill_mode);
}

bool ToteLift::getLandfillMode()
{
	return(hp_mode);
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void ToteLift::setAnalog(int id, float val)
{
//	MutexScopeLock block(getLock());
	printf("ToteLift::setAnalog(%d, %f)\n", id, val);
	switch(id)
	{
		case CMD_LIFT_POWER:
		{
			lift_target_power = val;
			if (val > 0.05)
			{
				lift_target_position += val * lift_pos_adjust_scale;
				if ((lift_target_position > lift_tote_positions[lift_position_index]) &&
						(lift_position_index < LIFT_LVL_NUM_POSITIONS-1))
				{
					lift_position_index++;
				}
			}
			else if (val < -0.05)
			{
				lift_target_position += val * lift_pos_adjust_scale;
				if ((lift_target_position > lift_tote_positions[lift_position_index]) &&
						(lift_position_index > 0))
				{
					lift_position_index--;
				}
			}
			// else deadband

		}	break;
	}
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void ToteLift::setDigital(int id, bool val)
{
//	MutexScopeLock block(getLock());
	printf("ToteLift::setDigital(%d, %s)\n", id, val?"true":"false");

	switch(id)
	{
		case CMD_STEP_UP:
		{
			if (val)
			{
				if (lift_closed_loop)
				{
					lift_position_index++;
					if (lift_position_index >= LIFT_LVL_NUM_POSITIONS)
					{
						lift_position_index = LIFT_LVL_NUM_POSITIONS - 1;
					}
					lift_target_position = lift_tote_positions[lift_position_index];
				}
				else
				{
					lift_target_power = RobotUtil::limit(-1.0, 1.0, lift_target_power + lift_increment_step);
				}
			}
		} break;

		case CMD_STEP_DOWN:
		{
			if (val)
			{
				if (lift_closed_loop)
				{
					lift_position_index--;
					if (lift_position_index < 0)
					{
						lift_position_index = 0;
					}
					lift_target_position = lift_tote_positions[lift_position_index];
				}
				else
				{
					lift_target_power = RobotUtil::limit(-1.0, 1.0, lift_target_power - lift_decrement_step);
				}
			}

		} break;

		case CMD_STOP:
		{
			if (val)
			{
				lift_target_power = 0.0;
			}
		} break;

		case CMD_MOMENTARY_UP:
		{
			if (val)
			{
				lift_target_power = lift_up_power;
			}
			else
			{
				lift_target_power = 0.0;
			}
		} break;

		case CMD_MOMENTARY_DOWN:
		{
			if (val)
			{
				lift_target_power = lift_down_power;
			}
			else
			{
				lift_target_power = 0.0;
			}
		} break;

		case CMD_CLOSED_LOOP:
		{
			lift_closed_loop = val;
		} break;

		case CMD_EJECT_SOLINOID:
		{
			lift_eject_cmd = val;
		} break;

		case CMD_LANDFILL_MODE:
		{
			landfill_mode = val;
		} break;

		case CMD_HP_MODE:
		{
			hp_mode = val;
		} break;

	}
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void ToteLift::setInt(int id, int val)
{
//	MutexScopeLock block(getLock());
	printf("ToteLift::setInt(%d, %d)\n", id, val);

	if (id == CMD_LIFT_POSITION)
	{
		switch(val)
		{
			case 0: //CMD_ARM_POSITION_CAN_SIDEWAYS
			{
				lift_target_position+= 1;
			} break;

			case 180: //ARM_POSITION_CAN_STACK
			{
				lift_target_position-= 1;
			} break;
		}
	}
}

/**********************************************************************
 *
 * This method is used to print a header line to the log
 * 
 * @param	phase	the name of the phase is used to name the log file
 * 
 * NOTE: 	Changes to this method should match changes to the
 * 			writeLogMessage method
 *
 **********************************************************************/
void ToteLift::initLogFile(std::string phase)
{
	lift_data_log.initLog(phase);

	lift_data_log.log("%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s\n",
		"time",
		"initialized",
		"cycle_counts",
		"closed_loop",
		"top_limit_pressed",
		"bot_limit_pressed",
		"tote_pos1_pressed",
		"tote_pos2_pressed",
		"pos_pot_ready",
		"pos_pot_raw",
		"pos_pot_position",
		"target_position",
		"target_power",
		"command_power",
		"position",
		"eject_cmd",
		"motor_stall",
		"motor_current");
}

/******************************************************************************
 *
 * Write a single line to the log file
 *
 * NOTE: 	changes to this method should match changes to the
 * 			initLogFile method
 *
 ******************************************************************************/
void ToteLift::writeLogMessage(void)
{
//	printf("%8.6f, cycles=%3d, CL=%d, TL=%d, BL=%d, P1=%d, P2=%d, RP=%d, pos_raw=%4.3f, pos=%5.3f, targ_pos=%5.3f, targ_pow=%4.3f, pow=%4.3f\n",
	lift_data_log.log("%8.6f, %d, %d, %d, %d, %d, %d, %d, %d, %f, %f, %f, %f, %f, %d, %d, %d, %f\n",
		gsi::Time::getTime(),
		lift_initialized,
		getCyclesSincePublish(),
		lift_closed_loop,
		lift_top_limit_pressed,
		lift_bot_limit_pressed,
		lift_tote_pos1_pressed,
		lift_tote_pos2_pressed,
		lift_pos_pot_ready,
		lift_pos_pot_raw,
		lift_pos_pot_position,
		lift_target_position,
		lift_target_power,
		lift_command_power,
//		PositionNames[lift_position_index],
		lift_position_index,
		lift_eject_cmd,
		lift_motor_stall,
		lift_motor_current);
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void ToteLift::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean("  Tote Lift  ", 	lift_initialized && (getCyclesSincePublish() > 0));

	SmartDashboard::PutNumber( "TL Cycles: ", 	getCyclesSincePublish());
	SmartDashboard::PutBoolean("TL Cl Loop: ", 	lift_closed_loop);

	SmartDashboard::PutBoolean("TL Top Lim: ", 	lift_top_limit_pressed);
	SmartDashboard::PutBoolean("TL Bot Lim: ", 	lift_bot_limit_pressed);

	SmartDashboard::PutBoolean("TL Tote 1: ", 	lift_tote_pos1_pressed);
	SmartDashboard::PutBoolean("TL Tote 2: ", 	lift_tote_pos2_pressed);

	SmartDashboard::PutBoolean("TL Pot Ready: ",lift_pos_pot_ready);
	SmartDashboard::PutNumber( "TL Raw Pos: ", 	lift_pos_pot_raw);
	SmartDashboard::PutNumber( "TL Act Pos: ", 	lift_pos_pot_position);
	SmartDashboard::PutNumber( "TL Trg Pos: ", 	lift_target_position);
//	SmartDashboard::PutString( "TL Trg Name: ",	PositionNames[lift_position_index]);

	SmartDashboard::PutNumber( "TL Trg Pwr: ", 	lift_target_power);
	SmartDashboard::PutNumber( "TL Cmd Pwr: ", 	lift_command_power);

	SmartDashboard::PutBoolean("TL Eject: ", 	lift_eject_cmd);
	SmartDashboard::PutBoolean("TL Stall: ", 	lift_motor_stall);
	SmartDashboard::PutNumber( "TL Current: ", 	lift_motor_current);
#endif
}

/******************************************************************************
 *
 ******************************************************************************/
void ToteLift::doPeriodic()
{
	if ( ! lift_initialized)
	{
		return;
	}

	{
//		MutexScopeLock block(getLock());

		//
		// Get all Sensor input values
		//
		lift_top_limit_pressed 	= lift_top_limit_sw->Get() != lift_top_limit_invert;
		lift_bot_limit_pressed 	= lift_bot_limit_sw->Get() != lift_bot_limit_invert;
		lift_tote_pos1_pressed 	= lift_tote_pos1_sw->Get() != lift_tote_pos1_invert;
		lift_tote_pos2_pressed 	= lift_tote_pos2_sw->Get() != lift_tote_pos2_invert;

		lift_pos_pot_ready 		= lift_pos_pot->isReady();
		lift_pos_pot_raw		= lift_pos_pot->getRaw();
		lift_pos_pot_position	= lift_pos_pot_ready ? lift_pos_pot->getPosition() : -999.99;

		lift_motor_current		= lift_power_board->GetCurrent(lift_pb_a_port) +
								  lift_power_board->GetCurrent(lift_pb_b_port);

		// Make sure the lift doesn't jump when enabled by keeping the
		// target position at the current position while disabled
		if (getPhase() == DISABLED)
		{
			lift_target_position = lift_pos_pot_position;
		}

		//
		// Closed Loop Lift Control
		//
		if (lift_closed_loop)
		{
			if (lift_pos_pot_ready && ! lift_motor_stall)
			{
				lift_command_power = lift_pid->calculateControlValue(
					lift_target_position, lift_pos_pot_position);
			}
			else
			{
				lift_command_power = 0.0;
			}
		}

		//
		// Open Loop Lift Control
		//
		else
		{
			// Ramp the power changes
			if (lift_command_power + lift_max_power_delta < lift_target_power)
			{
				lift_command_power += lift_max_power_delta;
			}
			else if (lift_command_power - lift_max_power_delta > lift_target_power)
			{
				lift_command_power -= lift_max_power_delta;
			}
			else
			{
				lift_command_power = lift_target_power;
			}
		}

		//
		// Over-current protection
		//
		if (lift_motor_current > lift_stall_current)
		{
			if (! lift_motor_stall)
			{
				if( lift_motor_stall_time < lift_stall_time)
				{
					lift_motor_stall_time += getPeriod();
				}
				else
				{
					lift_motor_stall = true;
					lift_motor_stall_time = 0.0;
				}
			}
		}
		else if (lift_motor_stall)
		{
			if (lift_motor_stall_time < lift_stall_recover_time)
			{
				lift_motor_stall_time += getPeriod();
			}
			else
			{
				lift_motor_stall = false;
			}
		}
		else
		{
			lift_motor_stall_time = 0.0;
		}

		if (lift_motor_stall)
		{
			lift_command_power = 0.0;
		}

		//
		// Make sure the lift isn't at a limit switch
		//
		if (lift_top_limit_pressed)
		{
			lift_command_power = RobotUtil::limit(-1.0, 0.0, lift_command_power);
		}

		if (lift_bot_limit_pressed)
		{
			lift_command_power = RobotUtil::limit(0.0, 1.0, lift_command_power);
		}

		//
		// Set all outputs
		//
		lift_motor_a->Set(lift_command_power * lift_motor_a_invert);
		lift_motor_b->Set(lift_command_power * lift_motor_b_invert);

		if (lift_eject_invert)
		{
			lift_eject_sol->Set(!lift_eject_cmd);
		}
		else
		{
			lift_eject_sol->Set(lift_eject_cmd);
		}
	}

	//
	// Log any useful data
	//
	writeLogMessage();
}

// =============================================================================
// === MSToteLiftPowerMethods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSToteLiftPower::MSToteLiftPower(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	totelift = (ToteLift *)control;
	lift_pwr = xml->FloatAttribute("lift_pwr");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSToteLiftPower::init()
{
	if (fabs(lift_pwr) < 0.05)
	{
		printf("MSToteLiftPower::init -- stop!!!!!");
		totelift->setStop();
	}

	totelift->toteLiftPower(lift_pwr);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSToteLiftPower::update()
{
	return next_step;
}

// =============================================================================
// ===
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSToteLiftSetPosition::MSToteLiftSetPosition(std::string type, tinyxml2::XMLElement *xml, void *control)
	: MacroStepSequence(type, xml, control)
{
	totelift = (ToteLift *)(control);

	position = ToteLift::LIFT_LVL_NUM_POSITIONS;
	tolerance = 0.5;
	duration = 2.0;
	expire_time = 0.0;

	const char *pos_str = xml->Attribute("position");
	xml->QueryFloatAttribute("tolerance", &tolerance);
	xml->QueryDoubleAttribute("duration", &duration);

	position = totelift->getPostitionFromName(pos_str);
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSToteLiftSetPosition::init(void)
{
	if ((position >= 0) && (position < ToteLift::LIFT_LVL_NUM_POSITIONS))
	{
		totelift->setPosition(position);
		expire_time = gsi::Time::getTime() + duration;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSToteLiftSetPosition::update(void)
{
	if ((position < 0) || (position >= ToteLift::LIFT_LVL_NUM_POSITIONS))
	{
		printf("MSToteLiftSetPosition aborting - invalid position\n");
		parent_macro->abort();
		return nullptr;
	}

	if (totelift->isPosition(position, tolerance))
	{
		return next_step;
	}

	if (gsi::Time::getTime() > expire_time)
	{
		printf("MSToteLiftSetPosition aborting - time expired\n");
		parent_macro->abort();
		return nullptr;
	}

	return this;
}

// =============================================================================
// ===
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSToteLiftSetPotPosition::MSToteLiftSetPotPosition(std::string type, tinyxml2::XMLElement *xml, void *control)
	: MacroStepSequence(type, xml, control)
{
	totelift = (ToteLift *)(control);

	position = 10.0;
	tolerance = 0.5;
	duration = 2.0;
	expire_time = 0.0;

	xml->QueryFloatAttribute("position", &position);
	xml->QueryFloatAttribute("tolerance", &tolerance);
	xml->QueryDoubleAttribute("duration", &duration);
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSToteLiftSetPotPosition::init(void)
{
	if ((position >= 6.0) && (position <= 48.0))
	{
		totelift->setPosition(position);
		expire_time = gsi::Time::getTime() + duration;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSToteLiftSetPotPosition::update(void)
{
	if ((position <= 6.0) || (position >= 48.0))
	{
		printf("MSToteLiftSetPotPosition aborting - invalid position\n");
		parent_macro->abort();
		return nullptr;
	}

	if (totelift->isPosition(position, tolerance))
	{
		return next_step;
	}

	if (gsi::Time::getTime() > expire_time)
	{
		printf("MSToteLiftSetPosition aborting - time expired\n");
		parent_macro->abort();
		return nullptr;
	}

	return this;
}

// =============================================================================
// === Tote Lift Wait for Tote Macro Step
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSToteLiftWaitForTote::MSToteLiftWaitForTote(std::string type, tinyxml2::XMLElement *xml, void *control)
	: MacroStepCondition(type, xml, control)
{
	totelift = (ToteLift *)(control);

	tote_slot = 1;

	duration = 10.0;
	expire_time = 0.0;

	xml->QueryIntAttribute("tote_slot", &tote_slot);
	xml->QueryDoubleAttribute("duration", &duration);
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSToteLiftWaitForTote::init(void)
{
	expire_time = gsi::Time::getTime() + duration;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSToteLiftWaitForTote::update(void)
{
	if ((tote_slot != 1) && (tote_slot != 2))
	{
		printf("MSToteLiftWaitForTote aborting - invalid tote slot\n");
		parent_macro->abort();
		return nullptr;
	}

	if (totelift->isToteDetected(tote_slot))
	{
		return true_step;
	}

	if (gsi::Time::getTime() > expire_time)
	{
		return false_step;
	}

	return this;
}

// =============================================================================
// === Tote Lift
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSToteLiftEject::MSToteLiftEject(std::string type, tinyxml2::XMLElement *xml, void *control)
	: MacroStepSequence(type, xml, control)
{
	totelift = (ToteLift *)(control);

	duration = 1.0;
	expire_time = 0.0;

	xml->QueryDoubleAttribute("duration", &duration);
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSToteLiftEject::init(void)
{
	expire_time = gsi::Time::getTime() + duration;
	totelift->setDigital(ToteLift::CMD_EJECT_SOLINOID, true);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSToteLiftEject::update(void)
{
	if (gsi::Time::getTime() < expire_time)
	{
		return this;
	}

	totelift->setDigital(ToteLift::CMD_EJECT_SOLINOID, false);
	return next_step;
}
/*******************************************************************************
 *
 ******************************************************************************/
MSToteLiftCheckMode::MSToteLiftCheckMode(std::string type, tinyxml2::XMLElement *xml, void *control)
	: MacroStepCondition(type, xml, control)
{
	totelift = (ToteLift *)(control);

	mode = false;

	xml->QueryBoolAttribute("mode", &mode); // true = landfill, false = hp
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSToteLiftCheckMode::init(void)
{

}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSToteLiftCheckMode::update(void)
{
	bool state;
	if(mode == true)    // landfill;  todo make it a #define or enum
	{
		state = totelift->getLandfillMode();
	}
	else
	{
		state = totelift->getHpMode();
	}

	if(state == true)
	{
		return(true_step);
	}
	// else
	return false_step;
}
