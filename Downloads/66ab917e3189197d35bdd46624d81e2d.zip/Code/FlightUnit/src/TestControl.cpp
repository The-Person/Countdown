/*******************************************************************************
 *
 * File: TestControl.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <math.h>

#include "RobonautsLibrary/RobotUtil.h"
#include "RobotMain.h"

#include "TestControl.h"

using namespace tinyxml2;
using namespace gsi;

/******************************************************************************
 *
 ******************************************************************************/
TestControl::TestControl(tinyxml2::XMLElement *xml, double period) :
	PeriodicControl("TestControl", period)
{
//	XMLElement *element;

	printf("========================= Creating TestControl =========================\n");

	test_ready = false;

	macro_control = nullptr;
}

/******************************************************************************
 * Destructor
 ******************************************************************************/
TestControl::~TestControl()
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);
}

/******************************************************************************
 *
 *
 *
 ******************************************************************************/
void TestControl::setMacroController(MacroController *mc)
{
	macro_control = mc;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::controlInit()
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);

	test_ready = true;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::updateConfig()
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::disabledInit()
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::autonomousInit()
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::teleopInit()
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);
}

/**********************************************************************
 *
 *
 **********************************************************************/
void TestControl::testInit(void)
{
	printf("%s:%d\n", __FUNCTION__, __LINE__);
}


/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean("  Test ", test_ready && (getCyclesSincePublish() > 0));

	SmartDashboard::PutNumber("Test Cycles: ", getCyclesSincePublish());
	SmartDashboard::PutNumber("Test Time: ", getPhaseElapsedTime());
#endif
}


/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void TestControl::doPeriodic()
{
	int step = (int)(getPhaseElapsedTime() / getPeriod()) % 200;

	if (getPhase() == TELEOP )
	{
		switch (step)
		{
			case 1:
			{
				macro_control->startMacro("CoopPrep1");
			} break;

			case 4:
			{
				macro_control->startMacro("Swallow3");
			} break;

			case 12:
			{
				macro_control->startMacro("Swallow1");
			} break;

			case 18:
			{
				macro_control->startMacro("AutoSwallow3");
			} break;
		}
	}

//	while ((getPhase() == ControlPhase::TELEOP) && (getPhaseElapsedTime() > 45.0))
	{
		// force a spin loop at 45 seconds in teleop
	}
}
