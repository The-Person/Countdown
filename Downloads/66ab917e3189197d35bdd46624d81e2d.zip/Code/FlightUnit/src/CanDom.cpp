/*******************************************************************************
 *
 * File: CanDom.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Erica
 *
 ******************************************************************************/
#include <math.h>

#include "gsi/Time.h"

#include "RobonautsLibrary/RobotUtil.h"
#include "RobotMain.h"

#include "CanDom.h"

using namespace tinyxml2;
using namespace gsi;

/******************************************************************************
 *
 ******************************************************************************/
CanDom::CanDom(tinyxml2::XMLElement *xml, double period)
	: PeriodicControl("CanDom", period)
	, data_log("can_dom", "csv")
{
	printf("========================= Creating Can Dom =========================\n");

	// register macro steps
	new MacroStepProxy<MSCanOpenLatch>("candom", "OpenLatch", this);
	new MacroStepProxy<MSCanDomSetWinchPower>("candom", "SetWinchPower", this);
	new MacroStepProxy<MSCanDomSetPosition>("candom", "SetPosition", this);

	winch_motor	= nullptr;
	left_latch_sol	= nullptr;
	right_latch_sol	= nullptr;
	race_sol	= nullptr;

	left_top_limit_sw = nullptr;
	left_bottom_limit_sw = nullptr;
	right_bottom_limit_sw = nullptr;
	right_top_limit_sw = nullptr;
	arm_angle_pot	= nullptr;

	arm_angle_pid = nullptr;

	left_latch_invert = false;
	right_latch_invert = false;
	race_invert = false;
	winch_motor_invert = false;
	left_top_limit_invert = false;
	left_bottom_limit_invert = false;
	right_top_limit_invert = false;
	right_bottom_limit_invert = false;

	arm_position_min_latch = 60.0;

	winch_command_power = 0.0;

	arm_angle_pot_ready = false;
	arm_angle_pot_raw = 0.0;
	arm_angle_pot_position = 0.0;

	right_top_limit_pressed = false;
//	right_bottom_limit_pressed = false;
	left_top_limit_pressed = false;
//	left_bottom_limit_pressed = false;
	winch_max_power_delta = 0.1;
	can_dom_subsystem_ready = false;

	winch_up_power = 0.6;
	winch_down_power = -0.4;

	closed_loop = false;
	left_active = false;
	right_active = false;

	winch_motor_target = 0.0;
	position_target = 0.0;
	position_stow = 0.0;
	position_ready = 0.0;
	position_grab = 0.0;

	left_sol_cmd = false;
	right_sol_cmd = false;
	race_sol_cmd = false;

	right_sol_state = false;
	left_sol_state = false;
	race_sol_state = false;

	XMLElement *element;
	const char *name;

	element = xml->FirstChildElement("motor");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "winch") == 0)
			{
				printf("  creating speed_controller for %s\n", name);
				winch_motor = XmlRobotUtil::createSpeedController(element);
				if (element->Attribute("invert") != nullptr)
				{
					winch_motor_invert = element->BoolAttribute("invert") ? -1.0 : 1.0;
				}
			}
		}

		element = element->NextSiblingElement("motor");
	}

	element = xml->FirstChildElement("solenoid");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "left_latch") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				left_latch_sol = XmlRobotUtil::createSolenoid(element);
				element->QueryBoolAttribute("invert", &left_latch_invert);
			}
			else if (strcmp(name, "right_latch") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				right_latch_sol = XmlRobotUtil::createSolenoid(element);
				element->QueryBoolAttribute("invert", &right_latch_invert);
			}
			else if (strcmp(name, "race_sol") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				race_sol = XmlRobotUtil::createSolenoid(element);
				element->QueryBoolAttribute("invert", &race_invert);
			}
		}
		element = element->NextSiblingElement("solenoid");
	}

	element = xml->FirstChildElement("pot");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "arm_angle") == 0)
			{
				printf("  creating pot for %s\n", name);
				arm_angle_pot = XmlRobotUtil::createPot(element);
			}
		}

		element = element->NextSiblingElement("pot");
	}

	element = xml->FirstChildElement("pid");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "arm_angle") == 0)
			{
				printf("  creating PID for %s\n", name);
				arm_angle_pid = XmlRobotUtil::createPID(element);
				arm_angle_pid->setParamPrefix("ARM_ANGLE");
			}
		}

		element = element->NextSiblingElement("pid");
	}

	element = xml->FirstChildElement("digital_input");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "right_top_limit") == 0)
			{
				printf("  creating digital input for %s\n", name);
				right_top_limit_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &right_top_limit_invert);
			}
			else if (strcmp(name, "right_bottom_limit") == 0)
			{
				printf("  creating digital input for %s\n", name);
				right_bottom_limit_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &right_bottom_limit_invert);
			}
			if (strcmp(name, "left_bottom_limit") == 0)
			{
				printf("  creating digital input for %s\n", name);
				left_bottom_limit_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &left_bottom_limit_invert);
			}
			else if (strcmp(name, "left_top_limit") == 0)
			{
				printf("  creating digital input for %s\n", name);
				left_top_limit_sw = XmlRobotUtil::createDigitalInput(element);
				element->QueryBoolAttribute("invert", &left_top_limit_invert);
			}
		}
		element = element->NextSiblingElement("digital_input");
	}
	element = xml-> FirstChildElement("oi");
	while (element != nullptr)
	{
		name = element->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "position") == 0)
			{
				printf("  connecting to position channel\n");
				OIController::subscribeInt(element, this, CMD_POSITION);
				element->QueryFloatAttribute("stow_value", &position_stow);
				element->QueryFloatAttribute("grab_value", &position_grab);
				element->QueryFloatAttribute("ready_value", &position_ready);
			}
			else if (strcmp(name, "left_active_state") == 0)
			{
				printf("  connecting to left channel\n");
				OIController::subscribeDigital(element, this, CMD_LEFT_STATE);
			}
			else if (strcmp(name, "right_active_state") == 0)
			{
				printf("  connecting to right channel\n");
				OIController::subscribeDigital(element, this, CMD_RIGHT_STATE);
			}
			else if (strcmp(name, "left_active_toggle") == 0)
			{
				printf("  connecting to left channel\n");
				OIController::subscribeDigital(element, this, CMD_LEFT_TOGGLE);
			}
			else if (strcmp(name, "right_active_toggle") == 0)
			{
				printf("  connecting to right channel\n");
				OIController::subscribeDigital(element, this, CMD_RIGHT_TOGGLE);
			}
			else if (strcmp(name, "closed_loop") == 0)
			{
				printf("  connecting to closed loop channel\n");
				OIController::subscribeDigital(element, this, CMD_CLOSED_LOOP);
			}
			else if (strcmp(name, "left_sol_state") == 0)
			{
				printf("  connecting to left sol channel\n");
				OIController::subscribeDigital(element, this, CMD_SOL_LEFT_STATE);
			}
			else if (strcmp(name, "right_sol_state") == 0)
			{
				printf("  connecting to right sol channel\n");
				OIController::subscribeDigital(element, this, CMD_SOL_RIGHT_STATE);
			}
		}
		element = element->NextSiblingElement("oi");
	}
}

/******************************************************************************
 * Destructor
 ******************************************************************************/
CanDom::~CanDom()
{
	printf("CanDom::~CanDom\n");
	if (winch_motor != nullptr)
	{
		delete winch_motor;
		winch_motor = nullptr;
	}

	if (right_latch_sol != nullptr)
	{
		delete right_latch_sol;
		right_latch_sol = nullptr;
	}

	if (left_latch_sol != nullptr)
	{
		delete left_latch_sol;
		left_latch_sol = nullptr;
	}

	if (race_sol != nullptr)
	{
		delete race_sol;
		race_sol = nullptr;
	}

	if (arm_angle_pot != nullptr)
	{
		delete arm_angle_pot;
		arm_angle_pot = nullptr;
	}

	if (right_top_limit_sw != nullptr)
	{
		delete right_top_limit_sw;
		right_top_limit_sw = nullptr;
	}

	if (right_bottom_limit_sw != nullptr)
	{
		delete right_bottom_limit_sw;
		right_bottom_limit_sw = nullptr;
	}

	if (left_bottom_limit_sw != nullptr)
	{
		delete left_bottom_limit_sw;
		left_bottom_limit_sw = nullptr;
	}

	if (left_top_limit_sw != nullptr)
	{
		delete left_top_limit_sw;
		left_top_limit_sw = nullptr;
	}

	if (arm_angle_pid != nullptr)
	{
		delete arm_angle_pid;
		arm_angle_pid = nullptr;
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::controlInit()
{
	printf("CanDom::controlInit\n");
	can_dom_subsystem_ready = true;
	if (winch_motor == nullptr)
	{
		printf("WARNING: Can Dom did not create winch Lift Motor\n");
		can_dom_subsystem_ready = false;
	}

	if (right_latch_sol == nullptr)
	{
		printf("WARNING: Can Dom did not create Right Latch Solenoid\n");
		can_dom_subsystem_ready = false;
	}
	if (left_latch_sol == nullptr)
	{
		printf("WARNING: Can Dom did not create Left Latch Solenoid\n");
		can_dom_subsystem_ready = false;
	}
	if (race_sol == nullptr)
	{
		printf("WARNING: Can Dom did not create Race Solenoid\n");
		can_dom_subsystem_ready = false;
	}
	if (arm_angle_pot == nullptr)
	{
		printf("WARNING: Can Dom did not create Arm Angle Pot\n");
		can_dom_subsystem_ready = false;
	}
	if (right_top_limit_sw == nullptr)
	{
		printf("WARNING: Can Dom did not create Right Top Limit Switch\n");
		can_dom_subsystem_ready = false;
	}
	if (right_bottom_limit_sw == nullptr)
	{
		printf("WARNING: Can Dom did not create Right Bottom Limit Switch\n");
		can_dom_subsystem_ready = false;
	}
	if (left_top_limit_sw == nullptr)
	{
		printf("WARNING: Can Dom did not create Left Top Limit Switch\n");
		can_dom_subsystem_ready = false;
	}
	if (right_bottom_limit_sw == nullptr)
	{
		printf("WARNING: Can Dom did not create Left Bottom Limit Switch\n");
		can_dom_subsystem_ready = false;
	}
	if (arm_angle_pid == nullptr)
	{
		printf("WARNING: Can Dom did not create Arm Angle Pid\n");
		can_dom_subsystem_ready = false;
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::updateConfig()
{
	printf("CanDom::updateConfig\n");

	closed_loop = Parameter::getAsBool("CAN_DOM_CLOSED_LOOP", closed_loop);

	left_active = Parameter::getAsBool("CAN_DOM_LEFT_ACTIVE", left_active);
	right_active = Parameter::getAsBool("CAN_DOM_RIGHT_ACTIVE", right_active);

	winch_max_power_delta = Parameter::getAsFloat("CAN_DOM_MAX_POWER_DELTA", winch_max_power_delta);
	arm_position_min_latch = Parameter::getAsFloat("CAN_DOM_MIN_LATCH_POS", arm_position_min_latch);

	position_stow = Parameter::getAsFloat("CAN_DOM_STOW_POS", position_stow);
	position_grab = Parameter::getAsFloat("CAN_DOM_GRAB_POS", position_grab);
	position_ready = Parameter::getAsFloat("CAN_DOM_READY_POS", position_ready);
	winch_up_power = Parameter::getAsFloat("CAN_DOM_WINCH_UP_POWER", winch_up_power);
	winch_down_power = Parameter::getAsFloat("CAN_DOM_WINCH_DOWN_POWER", winch_down_power);
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::disabledInit()
{
	printf("CanDom::disabledInit\n");
	data_log.close();
	winch_motor_target = 0.0;
	left_sol_state = false;
	right_sol_state = false;
	race_sol_state=false;
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::autonomousInit()
{
	printf("CanDom::autonomousInit\n");
	initLogFile("Auton");
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::teleopInit()
{
	printf("CanDom::teleopInit\n");
	initLogFile("Teleop");
}
/******************************************************************************
 *
 * Implements method required by PeriodicControl
 *
 ******************************************************************************/
void CanDom::testInit()
{
	printf("CanDom::testInit\n");
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void CanDom::setAnalog(int id, float val)
{
//	MutexScopeLock block(getLock());
	printf("CanDom::setAnalog(%d, %f)\n", id, val);
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void CanDom::setDigital(int id, bool val)
{
//	MutexScopeLock block(getLock());
	printf("CanDom::setDigital(%d, %s)\n", id, val?"true":"false");

	switch(id)
	{
		case CMD_CLOSED_LOOP:
		{
			closed_loop = val;
		} break;

		case CMD_RIGHT_STATE:
		{
			right_active = val;
		} break;

		case CMD_LEFT_STATE:
		{
			left_active = val;
		} break;

		case CMD_RIGHT_TOGGLE:
		{
			if (val) right_active = !right_active;
		} break;

		case CMD_LEFT_TOGGLE:
		{
			if (val) left_active = !left_active;
		} break;

		case CMD_SOL_LEFT_STATE:
		{
			left_sol_state = val;
		} break;

		case CMD_SOL_RIGHT_STATE:
		{
			right_sol_state = val;
		} break;

		case CMD_SOL_RACE_STATE:
		{
			race_sol_state = val;
		} break;
	}
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void CanDom::setInt(int id, int val)
{
//	MutexScopeLock block(getLock());
	printf("CanDom::setInt(%d, %d)\n", id, val);

	if (id == CMD_POSITION)
	{
		switch(val)
		{
			case 0:
			{
				position_target = position_stow;
				winch_motor_target = winch_up_power;
			} break;

			case 90:
			{
				left_sol_state = left_active;
				right_sol_state = right_active;
			} break;

			case 180:
			{
				winch_motor_target = winch_down_power;
				position_target = position_grab;
			} break;

			case 270:
			{
				winch_motor_target = 0.0;
				position_target = position_ready;
			} break;

			default:
			{
				winch_motor_target = 0.0;
				left_sol_state = false;
				right_sol_state = false;
			} break;
		}
	}
}

/**********************************************************************
 *
 **********************************************************************/
void CanDom::setArmPosition(CanDomPosition arg)
{
	setInt(CMD_POSITION, (int)arg);
}

bool CanDom::isArmPosition(CanDomPosition pos, float tolerance)
{
	float targ = -999.99;

	switch(pos)
	{
		case StowPosition: 	targ = position_stow; 			break;
		case GrabPosition: 	targ = position_grab; 			break;
		case ReadyPosition:	targ = position_ready; 			break;

		default: targ = -999.99;
	}

	return (fabs(targ - arm_angle_pot_position) <= tolerance);
}
/******************************************************************************
 *
 ******************************************************************************/
void CanDom::setLatchOpen(bool left, bool right, bool race)
{
//	MutexScopeLock block(getLock());
	left_sol_state = left;
	right_sol_state = right;
	race_sol_state = race;
}

/******************************************************************************
 *
 ******************************************************************************/
void CanDom::setWinchPower(float pwr)
{
//  MutexScopeLock block(getLock());
	winch_motor_target = pwr;
}

/**********************************************************************
 *
 * This method is used to print a header line to the log
 * 
 * @param	phase	the name of the phase is used to name the log file
 * 
 **********************************************************************/
void CanDom::initLogFile(std::string phase)
{
	data_log.initLog(phase);

	data_log.log("%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s\n",
		"time",
		"ready",
		"cycles",
		"closed_loop",
		"left_top_limit_pressed",
		"right_top_limit_pressed",
//		"left_bottom_limit_pressed",
//		"right_bottom_limit_pressed",
		"left_active",
		"right_active",
		"left_sol_state",
		"right_sol_state",
		"race_sol_state",
		"left_sol_cmd",
		"right_sol_cmd",
		"race_sol_cmd",
		"arm_angle_pot_ready",
		"arm_angle_pot_raw",
		"arm_angle_pot_position",
		"position_target",
		"winch_motor_target",
		"winch_command_power");
}

/**********************************************************************
 *
 *
 **********************************************************************/
void CanDom::writeLogMessage(void)
{
//	printf("%15.6f, %d, %d, cl=%d, lim=%d:%d:%d:%d, a[%d:%d] s[%d:%d] c[%d:%d]  pot= %d, targ=%6.2f, cmd=%6.2f,  %6.2f, %6.2f, %6.2f\n",
	data_log.log("%15.6f, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %6.2f, %6.2f, %6.2f, %6.2f, %6.2f\n",
		gsi::Time::getTime(),
		can_dom_subsystem_ready,
		getCyclesSincePublish(),
		closed_loop,
		left_top_limit_pressed,
		right_top_limit_pressed,
//		left_bottom_limit_pressed,
//		right_bottom_limit_pressed,
		left_active,
		right_active,
		left_sol_state,
		right_sol_state,
		race_sol_state,
		left_sol_cmd,
		right_sol_cmd,
		race_sol_cmd,
		arm_angle_pot_ready,
		arm_angle_pot_raw,
		arm_angle_pot_position,
		position_target,
		winch_motor_target,
		winch_command_power);
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean("  Can Dom  ", can_dom_subsystem_ready && (getCyclesSincePublish() > 0));
	SmartDashboard::PutNumber("CD cycles: ", getCyclesSincePublish());
	SmartDashboard::PutBoolean("CD closed loop: ", closed_loop);

	SmartDashboard::PutBoolean("CD top l lim: ", left_top_limit_pressed);
	SmartDashboard::PutBoolean("CD top r lim: ", right_top_limit_pressed);
//	SmartDashboard::PutBoolean("CD bot l lim: ", left_bottom_limit_pressed);
//	SmartDashboard::PutBoolean("CD bot r lim: ", right_bottom_limit_pressed);

	SmartDashboard::PutBoolean("CD pot ready: ", arm_angle_pot_ready);
	SmartDashboard::PutNumber("CD pot raw: ", arm_angle_pot_raw);
	SmartDashboard::PutNumber("CD arm pos: ", arm_angle_pot_position);

	SmartDashboard::PutBoolean("CD right active: ", right_active);
	SmartDashboard::PutBoolean("CD left active: ", left_active);
	SmartDashboard::PutBoolean("CD l sol targ: ", left_sol_state);
	SmartDashboard::PutBoolean("CD r sol targ: ", right_sol_state);
	SmartDashboard::PutBoolean("CD race sol targ: ", race_sol_state);
	SmartDashboard::PutBoolean("CD l sol cmd: ", left_sol_cmd);
	SmartDashboard::PutBoolean("CD r sol cmd: ", right_sol_cmd);
	SmartDashboard::PutBoolean("CD race sol cmd: ", race_sol_cmd);
	SmartDashboard::PutNumber("CD pos targ: ", position_target);
	SmartDashboard::PutNumber("CD winch targ: ", winch_motor_target);
	SmartDashboard::PutNumber("CD winch power: ", winch_command_power);
#endif
}

/******************************************************************************
 *
 * Returns the solenoid state
 *
 ******************************************************************************/
bool CanDom::getSolenoidState(void)
{
	return left_sol_state || right_sol_state;
}

/******************************************************************************
 *
 * Returns the arm angle
 *
 ******************************************************************************/
float CanDom::getArmAngle(void)
{
	return arm_angle_pot_position;
}
/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanDom::doPeriodic()
{
	if(! can_dom_subsystem_ready)
	{
		return;
	}

	{
//		MutexScopeLock block(getLock());

		//
		// Get Inputs
		//
		arm_angle_pot_ready = arm_angle_pot->isReady();
		arm_angle_pot_raw = arm_angle_pot->getRaw();
		arm_angle_pot_position = arm_angle_pot_ready ? arm_angle_pot->getPosition() : -999.99;

		right_top_limit_pressed = right_top_limit_sw->Get() != right_top_limit_invert;
//		right_bottom_limit_pressed = right_bottom_limit_sw->Get() != right_bottom_limit_invert;
//		left_bottom_limit_pressed =left_bottom_limit_sw->Get() != left_bottom_limit_invert;
		left_top_limit_pressed = left_top_limit_sw->Get() != left_top_limit_invert;


		if(this->getPhase() == ControlPhase::DISABLED)
		{
			winch_motor_target = 0.0F;
			position_target = arm_angle_pot_position;
		}
		//
		// Closed Loop
		//
		if (closed_loop)
		{
			if (arm_angle_pot_ready)
			{
				winch_command_power = arm_angle_pid->calculateControlValue(
					position_target, arm_angle_pot_position);
			}
			else
			{
				winch_command_power = 0.0;
			}

			if ((position_target < arm_angle_pot_position) &&
				(arm_angle_pot_position > arm_position_min_latch))
			{
				right_sol_cmd =  right_active || right_sol_state;
				left_sol_cmd = left_active || left_sol_state;
				race_sol_cmd = race_sol_state;
			}
			else
			{
				right_sol_cmd =  right_sol_state;
				left_sol_cmd = left_sol_state;
				race_sol_cmd = race_sol_state;
			}
		}

		//
		// Open Loop
		//
		else
		{
			// Ramp the right power changes
			if (winch_command_power + winch_max_power_delta < winch_motor_target)
			{
				winch_command_power += winch_max_power_delta;
			}
			else if (winch_command_power - winch_max_power_delta > winch_motor_target)
			{
				winch_command_power -= winch_max_power_delta;
			}
			else
			{
				winch_command_power = winch_motor_target;
			}

			if (winch_command_power < -0.1)
			{
				right_sol_cmd = right_active  || right_sol_state;
				left_sol_cmd = left_active || left_sol_state;
				race_sol_cmd = race_sol_state;
			}
			else
			{
				right_sol_cmd = right_sol_state;
				left_sol_cmd = left_sol_state;
				race_sol_cmd = race_sol_state;
			}
		}

		if (left_top_limit_pressed || right_top_limit_pressed)
		{
			winch_command_power = RobotUtil::limit(-1.0, 0.0, winch_command_power);
		}

//		if (left_bottom_limit_pressed || right_bottom_limit_pressed)
//		{
//			winch_command_power = RobotUtil::limit(0.0, 1.0, winch_command_power);
//		}

		//
		// Set Outputs
		//
		winch_motor->Set(winch_command_power * winch_motor_invert);

		left_latch_sol->Set(left_latch_invert ? !left_sol_cmd : left_sol_cmd);
		right_latch_sol->Set(right_latch_invert? !right_sol_cmd : right_sol_cmd);
		race_sol->Set(race_invert ? !race_sol_cmd : race_sol_cmd);
	}

	writeLogMessage();
}


// =============================================================================
// === MSCanDomFire Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSCanOpenLatch::MSCanOpenLatch(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	candom = (CanDom *)control;
	left_fire = xml->BoolAttribute("left_fire");
	right_fire = xml->BoolAttribute("right_fire");
	race_fire = xml->BoolAttribute("race_fire");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSCanOpenLatch::init()
{
	candom->setLatchOpen(left_fire, right_fire, race_fire);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSCanOpenLatch::update()
{
	return next_step;
}
// =============================================================================
// === MSCanDomFire Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSCanDomSetWinchPower::MSCanDomSetWinchPower(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	candom = (CanDom *)control;
	winch_pwr = xml->FloatAttribute("winch_pwr");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSCanDomSetWinchPower::init()
{
	candom->setWinchPower(winch_pwr);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSCanDomSetWinchPower::update()
{
	return next_step;
}

// =============================================================================
// === MSCanDomSetPosition
// =============================================================================
/******************************************************************************
 *
 ******************************************************************************/
MSCanDomSetPosition::MSCanDomSetPosition(std::string type,
		tinyxml2::XMLElement *xml, void *control)
	: MacroStepSequence(type, xml, control)
{
	candom = (CanDom *)control;

	position = CanDom::StowPosition;

	const char *pos = xml->Attribute("position");
	if (strcmp(pos, "stow") == 0)
	{
		position = CanDom::StowPosition;
	}
	else if (strcmp(pos, "ready") == 0)
	{
		position = CanDom::ReadyPosition;
	}
	else if (strcmp(pos, "grab") == 0)
	{
		position = CanDom::GrabPosition;
	}

	tolerance = 1.0;
	xml->QueryFloatAttribute("tolerance", &tolerance);
}

/******************************************************************************
 *
 ******************************************************************************/
void MSCanDomSetPosition::init(void)
{
	candom->setArmPosition(position);
}

/******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSCanDomSetPosition::update(void)
{
	if (candom->isArmPosition(position, tolerance))
	{
		return next_step;
	}

	return this;
}
