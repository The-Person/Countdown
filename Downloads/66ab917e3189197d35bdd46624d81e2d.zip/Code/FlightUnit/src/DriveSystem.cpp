/*******************************************************************************
 *
 * File: DriveSystem.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include "DriveSystem.h"
#include "RobonautsLibrary/RobotUtil.h"
#include <cmath>
#include "gsi/UdpSocket.h"


double DriveSystem::start_time = 0.0;

using namespace tinyxml2;
using namespace gsi;

/**********************************************************************
 *
 * Create and initialize all of the elements of the Drive System
 * 
 **********************************************************************/
DriveSystem::DriveSystem(tinyxml2::XMLElement *xml, double period) : 
	PeriodicControl("DriveSystem", period)
{
	printf("========================= Creating Drive System =========================\n");
	system_period = period;

	XMLElement *comp;
	const char *name;

	// create null versions of anything hardware
	drive_motor_l_a = NULL;
	drive_motor_r_a = NULL;
	drive_motor_l_b = NULL;
	drive_motor_r_b = NULL;
	encoder_l = NULL;
	encoder_r = NULL;
	drive_gyro = NULL;

	// register macro steps
	new MacroStepProxy<MSDriveDistance>("drive", "MSDriveDistance", this);
	new MacroStepProxy<MSDrivePower>("drive", "MSDrivePower", this);
	new MacroStepProxy<MSDriveRotate>("drive", "MSDriveRotate", this);

	// create data logger for drive system
	drive_log = new DataLogger("drive", "csv");

	// initialize member variables
	start_time = 0.0;
	drive_ready = false;
	
	drive_invert_l_a = false;
	drive_invert_r_a = false;
	drive_invert_l_b = false;
	drive_invert_r_b = false;

	drive_mode = MODE_POWER;

	drive_cmd_fwd = 0.0;       // for power percent, for others inches / second
	drive_cmd_trn = 0.0;       // for power percent, for others degree / second
	drive_cmd_distance = 0.0;  // inches

    drive_max_speed = 180.0;
    drive_max_turn = 180.0;
    
	previous_time = 0.0;      // seconds
	previous_distance = 0.0;   // inches
	previous_distance_l = 0.0;   // inches
	previous_distance_r = 0.0;   // inches
	previous_velocity_l = 0.0; // inches
	previous_velocity_r = 0.0; // inches

	previous_heading = 0.0;    // degrees
   	
   	gyro_desired = 0.0;

   	drive_rate_limit_on = true;
	power_left_last = 0.0; 
	power_right_last = 0.0; 
	drive_rate_limit_per_step = 1.0;

	motor_left = 0.0;
	motor_right = 0.0;
	vel_cmd = 0.0;

	drive_dist_kgyro = 0.0;
	drive_dist_kp = 0.0;
	drive_vel_kv = 0.0;
	drive_rot_kp = 0.0;

	v_desired_left_sat = 0.0;
	v_desired_right_sat = 0.0;
	v_desired_left = 0.0;
	v_desired_right = 0.0;
	v_desired_max = 0.0;

	test_fwd = 0.0;
	test_rev = 0.0;
	test_incr = Parameter::getAsFloat("DRIVE_TEST_INCR", 0.01);
	test_last_fwd = false;
	test_last_rev = false;

	for(int i=0;i<MODEL_DIM;i++)
	{
		for(int j=0;j<MODEL_SIZE;j++)
		{
			motor_model_slope[i][j]=0.0;
			motor_model_intercept[i][j]=0.0;
		}
	}

	// read and parse XML file
	comp = xml->FirstChildElement("motor");
	while (comp != NULL)
	{
		name = comp->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "left_a") == 0)
			{				
				printf("  creating speed controller for %s\n", name);
				drive_motor_l_a = XmlRobotUtil::createSpeedController(comp);
				drive_invert_l_a = comp->BoolAttribute("invert") ? -1.0 : 1.0;

			}
			else if (strcmp(name, "right_a") == 0)
			{
				printf("  creating speed controller for %s\n", name);
				drive_motor_r_a = XmlRobotUtil::createSpeedController(comp);
				drive_invert_r_a = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
			else if (strcmp(name, "left_b") == 0)
			{
				printf("  creating speed controller for %s\n", name);
				drive_motor_l_b = XmlRobotUtil::createSpeedController(comp);
				drive_invert_l_b = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
			else if (strcmp(name, "right_b") == 0)
			{
				printf("  creating speed controller for %s\n", name);
				drive_motor_r_b = XmlRobotUtil::createSpeedController(comp);
				drive_invert_r_b = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
		}
		comp = comp->NextSiblingElement("motor");
	}

	comp = xml->FirstChildElement("gyro");
	if (comp != NULL)
	{
		printf("  creating gyro\n");
	    drive_gyro = XmlRobotUtil::createGyro(comp);
	}
	
	comp = xml->FirstChildElement("encoder");
	while (comp != NULL)
	{
		name = comp->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "left") == 0)
			{				
				printf("  creating encoder for %s\n", name);
				encoder_l = XmlRobotUtil::createEncoder(comp);
			}
			else if (strcmp(name, "right") == 0)
			{				
				printf("  creating encoder for %s\n", name);
				encoder_r = XmlRobotUtil::createEncoder(comp);
			}
			comp = comp->NextSiblingElement("encoder");
		}
	}
    
	comp = xml-> FirstChildElement("oi");
	while (comp != NULL)
	{
		name = comp->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "forward") == 0)
			{
				printf("  connecting to forward channel\n");
				OIController::subscribeAnalog(comp, this, CMD_FORWARD);
			}
			else if (strcmp(name, "turn") == 0)
			{
				printf("  connecting to turn channel\n");
				OIController::subscribeAnalog(comp, this, CMD_TURN);
			}
			else if (strcmp(name, "test_fwd") == 0)
			{
				printf("  connecting to turn channel\n");
				OIController::subscribeDigital(comp, this, CMD_TEST_FWD);
			}
			else if (strcmp(name, "test_rev") == 0)
			{
				printf("  connecting to turn channel\n");
				OIController::subscribeDigital(comp, this, CMD_TEST_REV);
			}
		}
		comp = comp->NextSiblingElement("oi");
	}

	drive_ready = true;
	if (drive_motor_l_a == NULL)
	{
		printf("WARNING: did not create DriveSystem left motor A\n");
		drive_ready = false;
	}

	if (drive_motor_r_a == NULL)
	{
		printf("WARNING: did not create DriveSystem right motor A\n");
		drive_ready = false;
	}

	if (drive_motor_l_b == NULL)
	{
		printf("WARNING: did not create DriveSystem left motor B\n");
		drive_ready = false;
	}

	if (drive_motor_r_b == NULL)
	{
		printf("WARNING: did not create DriveSystem right motor B\n");
		drive_ready = false;
	}
	if (drive_gyro == NULL)
	{
		printf("WARNING: did not create DriveSystem gyro\n");
		drive_ready = false;
	}
	
	if (encoder_l == NULL)
	{
		printf("WARNING: did not create DriveSystem left encoder\n");
		drive_ready = false;
	}
	
	if (encoder_r == NULL)
	{
		printf("WARNING: did not create DriveSystem right encoder\n");
		drive_ready = false;
	}
}


/**********************************************************************
 *
 *  Destructor, releases any resources allocated by this class
 * 
 **********************************************************************/
DriveSystem::~DriveSystem(void)
{
	printf("DriveSystem::~DriveSystem\n");
	if (drive_motor_l_a != NULL) 
	{
		delete drive_motor_l_a;
		drive_motor_l_a = NULL;
	}
	
	if (drive_motor_r_a != NULL)
	{
		delete drive_motor_r_a;
		drive_motor_r_a = NULL;
	}
	if (drive_motor_l_b != NULL)
	{
		delete drive_motor_l_b;
		drive_motor_l_b = NULL;
	}

	if (drive_motor_r_b != NULL)
	{
		delete drive_motor_r_b;
		drive_motor_r_b = NULL;
	}

	if (encoder_l != NULL)
	{
		delete encoder_l;
		encoder_l = NULL;
	}
	
	if (encoder_r != NULL)
	{
		delete encoder_r;
		encoder_r = NULL;
	}
	
	if (drive_gyro != NULL)
	{
		delete drive_gyro;
		drive_gyro = NULL;
	}

}

/**********************************************************************
 * 
 * Take care of any initialization that needs to be done after all
 * controls have been created.
 * 
 **********************************************************************/
void DriveSystem::controlInit()
{	
}

/**********************************************************************
 * 
 * Reread any parameters used by this class and reconfigure as a 
 * result of parameter changes
 * 
 **********************************************************************/
void DriveSystem::updateConfig(void)
{
	//
	// constants
	//

    drive_max_speed = Parameter::getAsFloat("DRIVE_MAX_FWD_SPEED", drive_max_speed);
    drive_max_turn = Parameter::getAsFloat("DRIVE_MAX_TURN_SPEED", drive_max_turn);

    drive_rate_limit_on = Parameter::getAsBool("DRIVE_RATE_LIMIT_ON", drive_rate_limit_on);
    drive_rate_limit_per_step = Parameter::getAsFloat("DRIVE_RATE_LIMIT_PER_STEP", drive_rate_limit_per_step);

    // gains for drive distance, rotate and velocity
	drive_dist_kgyro =  Parameter::getAsFloat("DRIVE_PID_KG", 0.015);
	drive_dist_kp =  Parameter::getAsFloat("DRIVE_PID_KP", 0.005);
	drive_vel_kv = Parameter::getAsFloat("DRIVE_PID_KV", 0.005);
	drive_rot_kp = Parameter::getAsFloat("DRIVE_PID_KROT", 4.0);

    // test code for drive train characterization
	test_incr = Parameter::getAsFloat("DRIVE_TEST_INCR", 0.01f);

	v_desired_left = 0.0;
	v_desired_right = 0.0;
	v_desired_left_sat = 0.0;
	v_desired_right_sat = 0.0;
	v_desired_max = 0.0;

	char param[64];
	for(int i=0;i<MODEL_DIM;i++)
	{
		for(int j=0;j<MODEL_SIZE;j++)
		{
			sprintf(param, "DRIVE_MOTOR_MODEL_SLOPE_%d%d", i, j);
			motor_model_slope[i][j] = Parameter::getAsFloat(param, pow(-1,i));
			sprintf(param, "DRIVE_MOTOR_MODEL_INTERCEPT_%d%d", i, j);
			motor_model_intercept[i][j] = Parameter::getAsFloat(param, 0.0f);
		}

	}
	return;
}

/**********************************************************************
 *
 * Set the robot into a safe mode
 * 
 **********************************************************************/
void DriveSystem::disabledInit(void)
{
	printf("DriveSystem::disabledInit\n");
	drivePower(0.0,0.0);

	power_left_last = 0.0; 
	power_right_last = 0.0; 
	
	drive_log->close();	
}

/**********************************************************************
 * 
 * Prepare for Autonomous Operations
 * 
 **********************************************************************/
void DriveSystem::autonomousInit(void)
{
	printf("DriveSystem::autonomousInit\n");
	initLogFile("Auton");

	//
	// reset the gyro, 
	// give it some time to finish the reset,
	// check to make sure the reset worked
	//
	drive_gyro->Reset();
	previous_heading = drive_gyro->GetAngle();
	
	//
	// reset the encoders and PIDs
	//
	encoder_l->Reset();
	encoder_r->Reset();

	//
	// Initialize variables for Auton
	//
	drive_mode = MODE_DISTANCE;

	drive_cmd_fwd = 0.0;
	drive_cmd_trn = 0.0;
	drive_cmd_distance = 0.0;

	previous_time = 0.0;      // seconds
	previous_distance = 0.0;   // inches
	previous_distance_l = 0.0;   // inches
	previous_distance_r = 0.0;   // inches
	previous_heading = 0.0;    // degrees
	previous_velocity_l = 0.0; // inches
	previous_velocity_r = 0.0; // inches
}

/**********************************************************************
 * 
 * 
 **********************************************************************/
void DriveSystem::teleopInit(void)
{
	printf("DriveSystem::teleopInit\n");
	initLogFile("Teleop");
	
	drive_gyro->Reset();

	previous_heading = drive_gyro->GetAngle();
	gyro_desired = drive_gyro->GetAngle();

	drive_cmd_distance = 0.0;  // inches

	v_desired_left_sat = 0.0;
	v_desired_right_sat = 0.0;
	v_desired_left = 0.0;
	v_desired_right = 0.0;
	v_desired_max = 0.0;

	// reset the encoders
	encoder_l->Reset();
	encoder_r->Reset();

	// set mode
	drive_mode = MODE_POWER;
}


/**********************************************************************
 *
 **********************************************************************/
void DriveSystem::setHeading(float val)
{
//	MutexScopeLock block(getLock());
	gyro_desired = val;
}

/**********************************************************************
 *
 **********************************************************************/
void DriveSystem::setVelMax(float val)
{
//	MutexScopeLock block(getLock());
	v_desired_max = val;
}

/**********************************************************************
 *
 **********************************************************************/
void DriveSystem::setDriveDistance(float val)
{
//	MutexScopeLock block(getLock());
	drive_cmd_distance = val;
}

/**********************************************************************
 *
 **********************************************************************/
void DriveSystem::setAnalog(int id, float val)
{
//	MutexScopeLock block(getLock());

	switch (id)
	{
		case CMD_TURN:
			drivePower(drive_cmd_fwd, val, false);
			break;

		case CMD_FORWARD:
			drivePower(val, drive_cmd_trn, false);
			break;

		default:
			break;
	}
}

/**********************************************************************
 *
 **********************************************************************/
void DriveSystem::setDigital(int id, bool val)
{
//	MutexScopeLock block(getLock());
	switch(id)
	{
		case CMD_TEST_FWD:
			if(this->getPhase() == ControlPhase::TEST)
			{
				if(val == true)
				{
					doTestMode(true, false);  // test mode
				}
				else
				{
					doTestMode(false, false);  // test mode
				}
			}
			break;
		case CMD_TEST_REV:
			if(this->getPhase() == ControlPhase::TEST)
			{
				if(val == true)
				{
					doTestMode(false, true);  // test mode
				}
				else
				{
					doTestMode(false, false);  // test mode
				}
			}
			break;
		default:
			break;
	}
}

/**********************************************************************
 *
 * Set the DriveSystem to drive by power with the given forward and 
 * turn percentages
 * 
 * @param fwd percent of power -1.0 to 1.0
 * @param trn percent of power -1.0 to 1.0
 *
 **********************************************************************/
void DriveSystem::drivePower(float fwd, float trn, bool mut)
{   
	if(mut == true)
	{
//		MutexScopeLock block(getLock());
	}
	drive_cmd_fwd = fwd;
	drive_cmd_trn = trn;
	drive_cmd_distance = 0.0;

	drive_mode = MODE_POWER;
}

/**********************************************************************
 *
 * Set the DriveSystem to drive by power with the given forward and
 * turn percentages
 *
 * @param fwd percent of power -1.0 to 1.0
 * @param trn percent of power -1.0 to 1.0
 *
 **********************************************************************/
void DriveSystem::driveMotor(float m1, float m2)
{
//	MutexScopeLock block(getLock());

	motor_left = m1;
	motor_right = m2;
	drive_cmd_distance = 0.0;

	drive_mode = MODE_MOTOR;
}

/**********************************************************************
 *
 * Set the DriveSystem to drive by velocity with the given forward 
 * speed and turn rate percentages
 * 
 * @param fwd percent of max speed
 * @param trn percent of max turn
 *
 **********************************************************************/
void DriveSystem::driveVelocity(float fwd, float trn)
{
//	MutexScopeLock block(getLock());
	
	drive_cmd_fwd = fwd * drive_max_speed;
	drive_cmd_trn = trn * drive_max_turn;
	drive_cmd_distance = 0.0;

	drive_mode = MODE_VELOCITY;

}

/**********************************************************************
 *
 * Set the DriveSystem to rotate mode *
 **********************************************************************/
void DriveSystem::setDriveRotateMode()
{
//	MutexScopeLock block(getLock());

	gyro_desired = getHeading();
	drive_cmd_distance = 0.0;  // inches

	drive_mode = MODE_ROTATE;
}
/**********************************************************************
 *
 * Set the DriveSystem to rotate mode *
 **********************************************************************/
void DriveSystem::setDriveDistanceMode()
{
//	MutexScopeLock block(getLock());

	drive_mode = MODE_DISTANCE;
	//gyro_desired = getHeading();
}

/**********************************************************************
 *
 * Set the DriveSystem to move the specified distance with the
 * givin speed and turn limits
 * 
 * @param dist - amount to turn in inches
 * @param fwd   - max desired vel in percent of max forward vel
 * @param trn   - max desired turn vel in percent of max turn vel
 *
 **********************************************************************/
void DriveSystem::driveDistance(float dist, float fwd, float trn)
{
//	MutexScopeLock block(getLock());
	
	// note: currently only performs resets and changes mode; parameters not used
	
    previous_time = getPhaseElapsedTime();
    previous_distance = 0.0;
    previous_distance_l = 0.0;
    previous_distance_r = 0.0;
	previous_velocity_l = 0.0; // inches
	previous_velocity_r = 0.0; // inches
    previous_heading = drive_gyro->GetAngle();

	encoder_l->Reset();
	encoder_r->Reset();

	drive_mode = MODE_DISTANCE;
}

/**********************************************************************
 *
 * @return the distance the left side has moved since the last
 * 		time a distance was set
 * 
 **********************************************************************/
float DriveSystem::getLeftDistance()
{
	return previous_distance_l;
}

/**********************************************************************
 *
 * @return the distance the right side has moved since the last
 * 		time a distance was set
 * 
 **********************************************************************/
float DriveSystem::getRightDistance()
{
	return previous_distance_r;
}

/**********************************************************************
 *
 *  @return the heading of the DriveSystem relative to the heading 
 * 		the last time the automomousInit method was called
 * 
 **********************************************************************/
float DriveSystem::getHeading()
{
	return previous_heading;
}

/**********************************************************************
 *
 * @return the distance (in inches) remaining since the last call 
 * 		to driveDistance
 * 
 **********************************************************************/
float DriveSystem::getDistanceToGo()
{
	return drive_cmd_distance - previous_distance;
}

/**********************************************************************
 *
 * @return the rotation (in degrees) remaining since the last call
 * 		to driveRotate
 * 
 **********************************************************************/
float DriveSystem::getRotateToGo()
{
	return gyro_desired - previous_heading;
}

/**********************************************************************
 *
 * @return predicted (based on a model) motor command based on a
 * desired velocity; will have two sets
 * initial approach is piecewise linear with two segments
 *
 *
 *          \  mtr 2      |   mtr1      /
 *           \___         |            /
 *               \___     |        ___/
 *                   \___ |    ___/
 *                        |___/
 *                        |
 *        ----------------------------------
 *                     ___|
 *        mtr 1    ___/   |____   mtr 2
 *             ___/       |    \____
 *            /           |         \
 *           /            |          \
 *
 **********************************************************************/
float DriveSystem::ffMotorModel(float des_cmd, int idx)
{
	float mtr=0;
	float battery = DriverStation::GetInstance()->GetBatteryVoltage();

	if(idx == 0 || idx == 1)
	{
		des_cmd /= battery;  // model built independent of battery voltage
		if(des_cmd == 0)
		{
			mtr = 0.0;
		}
		else if(des_cmd > 0)
		{
			mtr = motor_model_slope[idx][0] * des_cmd + motor_model_intercept[idx][0];
		}
		else if(des_cmd < 0)
		{
			mtr = motor_model_slope[idx][1] * des_cmd + motor_model_intercept[idx][1];
		}
	}

	return(mtr);
}

/**********************************************************************
 *
 * Every period, get the current state of the DriveSystem and update
 * the actuators as needed
 * 
 **********************************************************************/
void DriveSystem::doPeriodic(void)
{
	// make sure drive is ready before proceeding
	if(drive_ready == false)
	{
		printf("drive_ready == false\n");
		return;
	}

	float power_left = 0.0;
	float power_right = 0.0;

	double current_time = getPhaseElapsedTime();     // seconds
	double delta_time = current_time - previous_time;    // seconds

	double meas_dist_l = encoder_l->GetDistance();  // should be calibrated to inches
	double meas_dist_r = encoder_r->GetDistance();  // should be calibrated to inches

	float meas_head = 0.0;
	float meas_dist_fwd = ( meas_dist_l + meas_dist_r ) / 2.0;  // inches

	float meas_vel_l = (meas_dist_l - previous_distance_l) / delta_time;
	float meas_vel_r = (meas_dist_r - previous_distance_r) / delta_time;

	float rot_to_go = 0.0;     // degrees
	float dist_to_go = 0.0;      // inches

//	float calc_trn_vel = 0.0;  // only used for MODE_VELOCITY
	float delta_th = 0.0;
	float ml=0.0, mr=0.0, v_err;


	if (drive_gyro->IsReady())
	{
		if (getPhase() == DISABLED)
		{
			meas_head = drive_gyro->Calibrate();  // should be calibrated to degrees		
		}
		else
		{
			meas_head = drive_gyro->GetAngle();  // should be calibrated to degrees
		}
	}
//	printf("gYRo = %.3f, le = %.3f, re = %.3f \n", meas_head, meas_dist_l, meas_dist_r);
	rot_to_go = gyro_desired - meas_head;     // degrees

	switch (drive_mode)
	{
		case MODE_ROTATE:
			if (drive_gyro->IsReady())
			{
				// position loop
				v_desired_left = rot_to_go * drive_rot_kp;
				v_desired_right = -rot_to_go * drive_rot_kp;

				// saturate speed, which is generally set by the turn parameter in the auton xml
				v_desired_left_sat = RobotUtil::limit(-v_desired_max, v_desired_max, v_desired_left);
				v_desired_right_sat = RobotUtil::limit(-v_desired_max, v_desired_max, v_desired_right);

				// velocity loop
				ml = ffMotorModel(v_desired_left_sat, 0);
				mr = ffMotorModel(v_desired_right_sat, 1);

				v_err = v_desired_left_sat - meas_vel_l;
				power_left = drive_vel_kv * v_err + ml + delta_th;
				v_err = v_desired_right_sat - meas_vel_r;
				power_right = drive_vel_kv * v_err + mr - delta_th;
			}
			else
			{
				power_left = power_right = 0.0;
				printf("MODE_ROTATE: gyro not ready, not moving\n");
			}
			break;
		case MODE_DISTANCE:
			if (drive_gyro->IsReady())
			{
				delta_th = drive_dist_kgyro * (rot_to_go);   // degrees

				dist_to_go = drive_cmd_distance - meas_dist_fwd;      // inches

				// approach with a position loop wrapping a velocity loop and feed forward model

				// position loop
				v_desired_left = dist_to_go * drive_dist_kp;
				v_desired_right = dist_to_go * drive_dist_kp;

				// saturate speed, which is generally set by the forward parameter in the auton xml
				v_desired_left_sat = RobotUtil::limit(-v_desired_max, v_desired_max, v_desired_left);
				v_desired_right_sat = RobotUtil::limit(-v_desired_max, v_desired_max, v_desired_right);

				// velocity loop

				// calculate feedforward model
				ml = ffMotorModel(v_desired_left_sat, 0);
				mr = ffMotorModel(v_desired_right_sat, 1);

				v_err = v_desired_left_sat - meas_vel_l;
				power_left = drive_vel_kv * v_err + ml + delta_th;
				v_err = v_desired_right_sat - meas_vel_r;
				power_right = drive_vel_kv * v_err + mr - delta_th;

			}
			else
			{
				power_left = power_right = 0.0;
				printf("MODE_ROTATE: gyro not ready, not moving\n");
			}
			break;

		case MODE_VELOCITY:
			if (drive_gyro->IsReady())
			{
/*
				calc_trn_vel = 0.0;   // force to zero;  change back once testing again
				calc_trn_vel = ( drive_cmd_trn / RobotUtil::DEGREE_PER_RADIAN ) * drive_radius;

				delta_th = drive_dist_kgyro * (gyro_desired-meas_head);

				// test code for algorithm development
				if(fabs(calc_trn_vel) > (0.05))
				{
					gyro_desired = meas_head;
					delta_th = 0.0;
				}
				else
				{
					calc_trn_vel = 0.0;
				}

				v_desired_right = v_desired_left = drive_cmd_fwd;

				// saturate speed, which is generally set by the forward parameter in the auton xml
				v_desired_left_sat = RobotUtil::limit(-v_desired_max, v_desired_max, v_desired_left);
				v_desired_right_sat = RobotUtil::limit(-v_desired_max, v_desired_max, v_desired_right);

				// calculate feedforward model
				ml = ffMotorModel(v_desired_left_sat, 0);
				mr = ffMotorModel(v_desired_right_sat, 1);

				v_err = v_desired_left_sat - meas_vel_l;
				power_left = drive_vel_kv * v_err + ml + delta_th;
				v_err = v_desired_right_sat - meas_vel_r;
				power_right = drive_vel_kv * v_err + mr - delta_th;
*/
			}
			else
			{
				power_left = power_right = 0.0;
				printf("MODE_ROTATE: gyro not ready, not moving\n");
			}
			break;

		case MODE_MOTOR:
			power_left = motor_left;
			power_right = motor_right;
			break;

		default:  // MODE_POWER
			power_left = RobotUtil::limit(-1.0f, 1.0f, drive_cmd_fwd - drive_cmd_trn);
			power_right = RobotUtil::limit(-1.0f, 1.0f, drive_cmd_fwd + drive_cmd_trn);
			
//			if(drive_rate_limit_on == true)
//			{
//				if(RobotUtil::increasingInMagnitude(power_left, power_left_last))
//				{
//					power_left = RobotUtil::rateLimit(drive_rate_limit_per_step, power_left, power_left_last);
//				}
//				if(RobotUtil::increasingInMagnitude(power_right, power_right_last))
//				{
//					power_right = RobotUtil::rateLimit(drive_rate_limit_per_step, power_right, power_right_last);
//				}
//			}
			break;
	}
	if(drive_rate_limit_on == true)
	{
		if(RobotUtil::increasingInMagnitude(power_left, power_left_last))
		{
			power_left = RobotUtil::rateLimit(drive_rate_limit_per_step, power_left, power_left_last);
		}
		if(RobotUtil::increasingInMagnitude(power_right, power_right_last))
		{
			power_right = RobotUtil::rateLimit(drive_rate_limit_per_step, power_right, power_right_last);
		}
	}

	drive_motor_l_a->Set(power_left * drive_invert_l_a);
	drive_motor_l_b->Set(power_left * drive_invert_l_b);
	drive_motor_r_a->Set(power_right * drive_invert_r_a);
	drive_motor_r_b->Set(power_right * drive_invert_r_b);

//	drive_log->log("time, battery, mode, cmd_fwd, cmd_turn, cmd_dist, distance_traveled");
//	drive_log->log(",dist_to_go, gyro_d, gyro_m, rot_to_go");
//	drive_log->log(",encl, encr, vel_l,vel_r, v_desired_left, v_desired_right,power_l,power_r,motor_l,motor_r");
//	drive_log->log(",model_l, model_r, delta_th ");
//	drive_log->log(",kgyro, dist_kp, vel_kp, rot_kp\n");

	drive_log->log("%8.6f, %8.6f, %d, ",
	    current_time, DriverStation::GetInstance()->GetBatteryVoltage(), drive_mode);
	drive_log->log("%8.6f, %8.6f, %8.6f,", drive_cmd_fwd, drive_cmd_trn, drive_cmd_distance);
	drive_log->log("%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,%8.6f,",
		meas_dist_fwd, dist_to_go, gyro_desired, meas_head, rot_to_go,
		meas_dist_l, meas_dist_r, meas_vel_l, meas_vel_r, v_desired_left, v_desired_right);
	drive_log->log("%8.6f, %8.6f, %8.6f,%8.6f,%8.6f,%8.6f,%8.6f,",
			power_left, power_right, drive_motor_l_a->Get(), drive_motor_r_a->Get(), ml, mr, delta_th);
	drive_log->log("%8.6f, %8.6f, %8.6f,%8.6f\n",
			drive_dist_kgyro, drive_dist_kp, drive_vel_kv, drive_rot_kp);
	drive_log->flush();

	// save state for next loop
	power_left_last = power_left;
	power_right_last = power_right;
	previous_time = current_time;
	previous_distance = meas_dist_fwd; 
	previous_distance_l = meas_dist_l;
	previous_distance_r = meas_dist_r;
	previous_velocity_l = meas_vel_l; // inch/s
	previous_velocity_r = meas_vel_r; // inch/s
	previous_heading = meas_head;
}

/**********************************************************************
 *
 * This method is used to print a header line to the log
 * 
 * @param	phase	the name of the phase is used to name the log file
 * 
 **********************************************************************/
void DriveSystem::initLogFile(std::string phase)
{
	drive_log->initLog(phase);
	
	drive_log->log("time, battery, mode, cmd_fwd, cmd_turn, cmd_dist, distance_traveled");
	drive_log->log(",dist_to_go, gyro_d, gyro_m, rot_to_go");
	drive_log->log(",encl, encr, vel_l,vel_r, v_desired_left, v_desired_right,power_l,power_r,motor_l,motor_r");
	drive_log->log(",model_l, model_r, delta_th ");
	drive_log->log(",kgyro, dist_kp, vel_kp, rot_kp\n");
	drive_log->flush();

}


/**********************************************************************
 *
 * update the driverstation with the latest information
 * 
 **********************************************************************/
void DriveSystem::publish(void)
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean("  Drive  ", drive_ready && (getCyclesSincePublish() > 0));

	SmartDashboard::PutNumber("Drive Cycles: ", getCyclesSincePublish());
	SmartDashboard::PutNumber("Drive Mode", (double)drive_mode);

	SmartDashboard::PutNumber("Drv enc L", (double)previous_distance_l);
	SmartDashboard::PutNumber("Drv enc R", (double)previous_distance_r);
	SmartDashboard::PutNumber("Drv cmd dist", (double)drive_cmd_distance);
	SmartDashboard::PutNumber("Drv vel L", (double)previous_velocity_l);
	SmartDashboard::PutNumber("Drv vel R", (double)previous_velocity_r);
	SmartDashboard::PutNumber("Drv vel R", (double)previous_velocity_r);

	SmartDashboard::PutNumber("Drv pow L", (double)power_left_last);
	SmartDashboard::PutNumber("Drv pow R", (double)power_right_last);

	SmartDashboard::PutNumber("Drv gyro M", (double)previous_heading);
	SmartDashboard::PutNumber("Drv gyro D", (double)gyro_desired);

	SmartDashboard::PutNumber("Drv K:gyro", (double)drive_dist_kgyro);
	SmartDashboard::PutNumber("Drv K:vel", (double)drive_vel_kv);
	SmartDashboard::PutNumber("Drv Kp:dist", (double)drive_dist_kp);
	SmartDashboard::PutNumber("Drv K:vel", (double)drive_rot_kp);

	SmartDashboard::PutBoolean("Drv Rate Lim", drive_rate_limit_on);
#endif
}

void DriveSystem::testInit()
{
	printf("DriveSystem::testInit\n");
	initLogFile("Test");
	test_last_fwd = false;
	test_last_rev = false;
	test_fwd = test_rev = 0.0;
}

void DriveSystem::doTestMode(bool fwd, bool rev)
{
#if 0
	// when button pressed, increase
	test_incr = 5;  // TODO: get hard of test_incr hard code
	if(fwd == true)  // when button pressed,
	{
		if(test_last_fwd == false)
		{
			test_fwd += test_incr;
			if(test_fwd > 200.0)
			{
				test_fwd = 0.0;
			}
		}
		vel_cmd = test_fwd;
	}
	else if(rev == true)
	{
		if(test_last_rev == false)
		{
			test_rev -= test_incr;
			if(test_rev < -200.0)
			{
				test_rev = 0.0;
			}
		}
		vel_cmd = test_rev;
	}

	float drive_ff_model_l, drive_ff_model_r;

	// determine model and write to motors
	drive_ff_model_l = ffMotorModel(vel_cmd, 0);
	drive_ff_model_r = ffMotorModel(vel_cmd, 1);
	printf(" * %.3f %.3f %.3f * ", vel_cmd, drive_ff_model_l, drive_ff_model_r);
	driveMotor(drive_ff_model_l, drive_ff_model_r);
	test_last_rev = rev;
	test_last_fwd = fwd;

#endif

	float cmd = 0;
	// when button pressed, increase
	if(fwd == true)  // when button pressed,
	{
		if(test_last_fwd == false)
		{
			test_fwd += test_incr;
			if(test_fwd > 1.0)
			{
				test_fwd = 0.0;
			}
		}
		cmd = test_fwd;
	}
	else if(rev == true)
	{
		if(test_last_rev == false)
		{
			test_rev -= test_incr;
			if(test_rev < -1.0)
			{
				test_rev = 0.0;
			}
		}
		cmd = test_rev;
	}
//	printf(" %.3f %.3f ", left, right);
	drivePower(cmd, 0);
	test_last_rev = rev;
	test_last_fwd = fwd;
}

// =============================================================================
// === MSDriveDistance Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSDriveDistance::MSDriveDistance(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	distance = xml->FloatAttribute("distance");   // distance is forward distance
	forward = xml->FloatAttribute("forward");     // forward is velocity into trajectory generator
	//turn = xml->FloatAttribute("turn");           // turn currently unused; could be added back for arc turns
	tolerance = xml->FloatAttribute("tolerance"); // tolerance is how close it gets to
	duration = xml->FloatAttribute("duration");   // time out
	desired_head = xml->FloatAttribute("desired");// desired heading during drive

	expire_time = GetTime();
	init_time = expire_time;
	drive = (DriveSystem *)control;

	trap = new TrapezoidalProfile(forward,
			Parameter::getAsFloat("MSDD_PERC", 0.20),
			Parameter::getAsFloat("MSDD_DT", 0.02));
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSDriveDistance::init()
{
//	drive = this->parent_macro->getRobotMain()->getDriveSystem();
	drive->driveDistance(distance, forward, 0.0);
	init_time = GetTime();
	expire_time = init_time + duration;
	drive->setHeading(desired_head);
	drive->setVelMax(forward);

	trap->setMaxVelocity(forward);
	trap->setPercentAcc(Parameter::getAsFloat("MSDD_PERC", 0.20));
	drive->setDriveDistanceMode();  // probably not necessary

	// initialize trajectory generator
	trap->initialize(((drive->getLeftDistance()+drive->getRightDistance())/2), distance);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSDriveDistance::update()
{
	float heading = drive->getHeading();

	if(fabs(((drive->getLeftDistance()+drive->getRightDistance())/2)-distance) < tolerance)
	{
		drive->setHeading(desired_head);
		return next_step;
	}

	if (GetTime() > expire_time)
	{
		drive->setHeading(desired_head);
		return next_step;
	}
	if(GetTime() > init_time + 0.4 && 		// TODO get rid of hard code
			(fabs(drive->getLeftDistance()) < 0.02 || fabs(drive->getRightDistance()) < 0.02 ||
			 heading > 360.0 || heading < -360.0 ))
	{
		printf("%s:%d -- bad encoder detected, aborting\n", __FUNCTION__, __LINE__);
		parent_macro->abort();
		drive->drivePower(0.0,0.0,true);
		return nullptr;
	}

	trap->update();
	drive->setDriveDistance(trap->getPos());
	return this;
}

// =============================================================================
// === MSDriveRotate Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSDriveRotate::MSDriveRotate(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	drive = (DriveSystem *)control;
	expire_time = GetTime();
	init_time = expire_time;
	rotate = xml->FloatAttribute("rotation");  // rotate is the angle to turn (in absolute)
	turn = xml->FloatAttribute("turn");   // turn is the rate that goes into the trapezoid trajectory
	tolerance = xml->FloatAttribute("tolerance");
	duration = xml->FloatAttribute("duration");
	first_time = true;

	trap = new TrapezoidalProfile(turn,
			Parameter::getAsFloat("MSDR_PERC", 0.20),
			Parameter::getAsFloat("MSDR_DT", 0.02));
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSDriveRotate::init()
{
	trap->setMaxVelocity(turn);
	trap->setPercentAcc(Parameter::getAsFloat("MSDR_PERC", 0.20));
	trap->initialize(drive->getHeading(), rotate);

	drive->setVelMax(turn);
	drive->setDriveRotateMode();

	first_time = true;
	printf("\n\n*** init %.3f %.3f ***\n\n", drive->getHeading(),rotate);
	init_time = GetTime();
	expire_time = init_time + duration;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSDriveRotate::update()
{
	float heading = drive->getHeading();

	if(first_time == true)
	{
		first_time = false;
	}
	else if(fabs(drive->getHeading()-rotate) < tolerance)
	{
		printf("\n\n*** exit %.3f %.3f ***\n\n", drive->getHeading(),rotate);
		drive->setHeading(rotate);
		return next_step;
	}

	else if (GetTime() > expire_time)
	{
		drive->setHeading(rotate);
		return next_step;
	}
	// error: encoders not moving
	if(GetTime() > init_time + 0.4 && 		// TODO get rid of hard code
			(fabs(drive->getLeftDistance()) < 0.02 || fabs(drive->getRightDistance()) < 0.02 ||
			 heading > 360.0 || heading < -360.0 ))
	{
		printf("%s:%d -- bad encoder detected, aborting\n", __FUNCTION__, __LINE__);
		parent_macro->abort();
		drive->drivePower(0.0,0.0,true);
		return nullptr;
	}
	trap->update();
	drive->setHeading(trap->getPos());

	return this;
}

// =============================================================================
// === MSDrivePower Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSDrivePower::MSDrivePower(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	drive = (DriveSystem *)control;
	forward = xml->FloatAttribute("forward");
	turn = xml->FloatAttribute("turn");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSDrivePower::init()
{
	drive->drivePower(forward, turn);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSDrivePower::update()
{
		return next_step;
}

