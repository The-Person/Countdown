/*******************************************************************************
 *
 * File: CompressorSys.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Chami
 *
 ******************************************************************************/
#include <math.h>

#include "RobonautsLibrary/RobotUtil.h"
#include "RobotMain.h"

#include "CompressorSys.h"

using namespace tinyxml2;
using namespace gsi;

/******************************************************************************
 *
 ******************************************************************************/
CompressorSys::CompressorSys(PowerDistributionPanel* pdp, tinyxml2::XMLElement *xml, double period) :
	PeriodicControl("CompressorSys", period)
{
	XMLElement *element;

	printf("========================= Creating CompressorSys =========================\n");

	compressor_relay = nullptr;
	compressor_switch = nullptr;

	compressor_switch_invert = false;
	compressor_on = false;
	compressor_fuse = 0xFF;
	compressor_current = 0.0;

	power_panel = pdp;

	//
	// Parse the XML
	//
	element = xml->FirstChildElement("digital_input");
	if (element != nullptr)
	{
		printf("  creating switch for compressor\n");
		compressor_switch = XmlRobotUtil::createDigitalInput(element);
		compressor_switch_invert = element->BoolAttribute("invert") ? true : false;

		if (element->Attribute("pb_port") != nullptr)
		{
			compressor_fuse = element->IntAttribute("pb_port");
		}
	}

	element = xml->FirstChildElement("relay");
	if (element != NULL)
	{
		printf("  creating compressor relay\n");
		compressor_relay = XmlRobotUtil::createRelay(element);
	}

	if (compressor_switch == nullptr)
	{
		printf("  WARNING: failed to initialize compressor switch\n");
	}

	if (compressor_relay == nullptr)
	{
		printf("  WARNING: failed to create compressor relay\n");
	}
}

/******************************************************************************
 * Destructor
 ******************************************************************************/
CompressorSys::~CompressorSys()
{
	printf("CompressorSys::~CompressorSys\n");
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::controlInit()
{

}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::updateConfig()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::disabledInit()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::autonomousInit()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::teleopInit()
{
}

/**********************************************************************
 *
 *
 **********************************************************************/
void CompressorSys::testInit(void)
{
}


/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)

	SmartDashboard::PutBoolean("  Compressor  ", (compressor_switch != nullptr) &&
				(compressor_relay != nullptr) && (getCyclesSincePublish() > 0));


	SmartDashboard::PutNumber("  Compressor Cycles: ", getCyclesSincePublish());

	SmartDashboard::PutBoolean("  Compressor On: ", (compressor_switch != nullptr) && compressor_on);

	SmartDashboard::PutNumber("  Compressor Current: ", compressor_current);
#endif
}


/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorSys::doPeriodic()
{
	if (compressor_switch != nullptr)
	{
		compressor_on = compressor_switch->Get() != compressor_switch_invert;
	}

	if ((power_panel != nullptr) && (compressor_fuse != 0xFF))
	{
		compressor_current = power_panel->GetCurrent(compressor_fuse);
	}

	if (compressor_relay != nullptr)
	{
		if (compressor_on)
		{
			compressor_relay->Set(Relay::kForward);
		}
		else
		{
			compressor_relay->Set(Relay::kOff);
		}
	}
}
