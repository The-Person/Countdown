/*******************************************************************************
 *
 * File: CanLift.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 * 	Devin
 *
 ******************************************************************************/
#include <math.h>

#include "RobonautsLibrary/RobotUtil.h"
#include "RobotMain.h"
#include "gsi/time.h"
#include "CanLift.h"

using namespace tinyxml2;
using namespace gsi;

/******************************************************************************
 *
 ******************************************************************************/
CanLift::CanLift(tinyxml2::XMLElement *xml, double period)
	: PeriodicControl("CanLift", period)
	, data_log("can_lift", "csv")
{
	printf("========================= Creating Can Lift =========================\n");

	new MacroStepProxy<MSOpen007>("canlift", "Open007", this);
	new MacroStepProxy<MSOpenPincher>("canlift", "OpenPincher", this);

	tote_holder_sol = nullptr;
	tote_holder_sol_b = nullptr;
	can_holder_sol = nullptr;
	can_pike_sol = nullptr;

	can_lift_subsystem_ready = false;

	tote_holder_sol_invert = false;
	can_holder_sol_invert = false;
	can_pike_sol_invert = false;

	// Input from driver
	tote_holder_open_trg = false;
	can_holder_open_trg = false;
	can_pike_open_trg = false;

	XMLElement *comp;
	const char *name;

	comp = xml->FirstChildElement("solenoid");
	while (comp != NULL)
	{
		name = comp->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "tote_holder") == 0)
			{
				printf("  creating solenoid for tote_holder\n");
				tote_holder_sol = XmlRobotUtil::createSolenoid(comp);
				tote_holder_sol_invert = comp->BoolAttribute("invert");
			}
			else if (strcmp(name, "can_pike") == 0)
			{
				printf("  creating solenoid for can_pike\n");
				can_pike_sol = XmlRobotUtil::createSolenoid(comp);
				can_pike_sol_invert = comp->BoolAttribute("invert");
			}
			else if (strcmp(name, "tote_holder_b") == 0)
			{
				printf("  creating solenoid b for tote_holder\n");
				tote_holder_sol_b = XmlRobotUtil::createSolenoid(comp);
			}
			else if (strcmp(name, "can_front_holder") == 0)
			{
				printf("  creating solenoid for can_holder\n");
				can_holder_sol = XmlRobotUtil::createSolenoid(comp);
				can_holder_sol_invert = comp->BoolAttribute("invert");
			}
		}
		comp = comp->NextSiblingElement("solenoid");
	}

	comp = xml-> FirstChildElement("oi");
	while (comp != NULL)
	{
		name = comp->Attribute("name");
		if (name != NULL)
		{
			if (strcmp(name, "tote_holder_open") == 0)
			{
				printf("  connecting to tote holder open channel\n");
				OIController::subscribeDigital(comp, this, CMD_TOTE_HOLDER_OPEN);
			}
			else if (strcmp(name, "tote_holder_close") == 0)
			{
				printf("  connecting to tote holder close channel\n");
				OIController::subscribeDigital(comp, this, CMD_TOTE_HOLDER_CLOSED);
			}
			else if (strcmp(name, "tote_holder_toggle") == 0)
			{
				printf("  connecting to tote holder toggle channel\n");
				OIController::subscribeDigital(comp, this, CMD_TOTE_HOLDER_TOGGLE);
			}
			else if (strcmp(name, "tote_holder_state") == 0)
			{
				printf("  connecting to tote holder state channel\n");
				OIController::subscribeDigital(comp, this, CMD_TOTE_HOLDER_STATE);
			}
			else if (strcmp(name, "can_holder_open") == 0)
			{
				printf("  connecting to can holder open channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_HOLDER_OPEN);
			}
			else if (strcmp(name, "can_holder_close") == 0)
			{
				printf("  connecting to can holder close channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_HOLDER_CLOSED);
			}
			else if (strcmp(name, "can_holder_toggle") == 0)
			{
				printf("  connecting to can holder toggle channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_HOLDER_TOGGLE);
			}
			else if (strcmp(name, "can_holder_state") == 0)
			{
				printf("  connecting to can holder state channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_HOLDER_STATE);
			}
			else if (strcmp(name, "can_pike_down") == 0)
			{
				printf("  connecting to can pike down channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_PIKE_DOWN);
			}
			else if (strcmp(name, "can_pike_up") == 0)
			{
				printf("  connecting to can pike up channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_PIKE_UP);
			}
			else if (strcmp(name, "can_pike_toggle") == 0)
			{
				printf("  connecting to can pike toggle channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_PIKE_TOGGLE);
			}
			else if (strcmp(name, "can_pike_state") == 0)
			{
				printf("  connecting to can pike state channel\n");
				OIController::subscribeDigital(comp, this, CMD_CAN_PIKE_STATE);
			}
		}
		comp = comp->NextSiblingElement("oi");
	}
}

/******************************************************************************
 * Destructor
 ******************************************************************************/
CanLift::~CanLift()
{
	printf("CanLift::~CanLift\n");
	if (tote_holder_sol != nullptr)
	{
		delete tote_holder_sol;
		tote_holder_sol = nullptr;
	}
	if (tote_holder_sol_b != nullptr)
	{
		delete tote_holder_sol_b;
		tote_holder_sol_b = nullptr;
	}
	if (can_holder_sol != nullptr)
	{
		delete can_holder_sol;
		can_holder_sol = nullptr;
	}
	if (can_pike_sol != nullptr)
	{
		delete can_pike_sol;
		can_pike_sol = nullptr;
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::controlInit()
{
	can_lift_subsystem_ready = true;

	if (tote_holder_sol == nullptr)
	{
		printf("WARNING: did not create Tote Holder Solenoid\n");
		can_lift_subsystem_ready = false;
	}

	if (tote_holder_sol_b == nullptr)
	{
		printf("WARNING: did not create Tote Holder Solenoid B\n");
		can_lift_subsystem_ready = false;
	}

	if (can_holder_sol == nullptr)
	{
		printf("WARNING: did not create Can Holder Solenoid\n");
		can_lift_subsystem_ready = false;
	}

	if (can_pike_sol == nullptr)
	{
		printf("WARNING: did not create Can Pike Solenoid\n");
		can_lift_subsystem_ready = false;
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::updateConfig()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::disabledInit()
{
	data_log.close();
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::autonomousInit()
{
	initLogFile("Auton");
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::teleopInit()
{
	initLogFile("Teleop");
}

/**********************************************************************
 *
 *
 **********************************************************************/
void CanLift::testInit(void)
{
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void CanLift::setAnalog(int id, float val)
{
//	MutexScopeLock block(getLock());
	printf("CanLift::setAnalog(%d, %f)\n", id, val);
}

/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void CanLift::setDigital(int id, bool val)
{
//	MutexScopeLock block(getLock());
	printf("CanLift::setDigital(%d, %s)\n", id, val?"true":"false");

	switch(id)
	{
		case CMD_TOTE_HOLDER_OPEN:
		{
			if (val)
			{
				tote_holder_open_trg=true;
			}
		} break;

		case CMD_TOTE_HOLDER_CLOSED:
		{
			if (val)
			{
				tote_holder_open_trg=false;
			}
		} break;

		case CMD_TOTE_HOLDER_TOGGLE:
		{
			if (val)
			{
				tote_holder_open_trg=!tote_holder_open_trg;
			}
		} break;

		case CMD_TOTE_HOLDER_STATE:
		{
			tote_holder_open_trg=val;
		} break;

		case CMD_CAN_HOLDER_OPEN:
		{
			if (val)
			{
				can_holder_open_trg=true;
			}
		} break;

		case CMD_CAN_HOLDER_CLOSED:
		{
			if (val)
			{
				can_holder_open_trg=false;
			}
		} break;

		case CMD_CAN_HOLDER_TOGGLE:
		{
			if (val)
			{
				can_holder_open_trg=!can_holder_open_trg;
			}
		} break;

		case CMD_CAN_HOLDER_STATE:
		{
			can_holder_open_trg=val;
		} break;

		case CMD_CAN_PIKE_DOWN:
		{
			if (val)
			{
				can_pike_open_trg=true;
			}
		} break;

		case CMD_CAN_PIKE_UP:
		{
			if (val)
			{
				can_pike_open_trg=false;
			}
		} break;

		case CMD_CAN_PIKE_TOGGLE:
		{
			if (val)
			{
				can_pike_open_trg=!can_pike_open_trg;
			}
		} break;

		case CMD_CAN_PIKE_STATE:
		{
			can_pike_open_trg=val;
		} break;

		default:
		{

		} break;
	}
};


/******************************************************************************
 *
 * Implements method required by OIObserver
 * 
 ******************************************************************************/
void CanLift::setInt(int id, int val)
{
//	MutexScopeLock block(getLock());
	printf("CanLift::setInt(%d, %d)\n", id, val);
}

/**********************************************************************
 *
 * This method is used to print a header line to the log
 * 
 * @param	phase	the name of the phase is used to name the log file
 * 
 **********************************************************************/
void CanLift::initLogFile(std::string phase)
{
	//TODO: update logged variables, go through and identify important variables for log (include openloop)
	data_log.initLog(phase);

	data_log.log("%s, %s\n",
		"current_time",
		"cycle_counts");
}

/**********************************************************************
 *
 * This method is used to messages to the log
 *
 **********************************************************************/
void CanLift::writeLogMessage(void)
{
	//TODO: match this with initLogFile
	data_log.log("%8.6f, %d\n",
		gsi::Time::getTime(),
		getCyclesSincePublish());
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean("  Can Lift  ", can_lift_subsystem_ready && (getCyclesSincePublish() > 0));
	SmartDashboard::PutNumber("CL cycles: ", getCyclesSincePublish());
#endif
}

/******************************************************************************
 *
 ******************************************************************************/
bool CanLift::is007Open(void)
{
	return(tote_holder_open_trg);
}

/******************************************************************************
 *
 ******************************************************************************/
void CanLift::set007Open(bool openA)
{
	if (openA)
	{
		setDigital(CMD_TOTE_HOLDER_OPEN, true);
	}
	else
	{
		setDigital(CMD_TOTE_HOLDER_CLOSED, true);
	}
}

/******************************************************************************
 *
 ******************************************************************************/
bool CanLift::isPincherOpen(void)
{
	return(can_holder_open_trg);
}

/******************************************************************************
 *
 ******************************************************************************/
void CanLift::setPincherOpen(bool openA)
{
	if (openA)
	{
		setDigital(CMD_CAN_HOLDER_OPEN, true);
	}
	else
	{
		setDigital(CMD_CAN_HOLDER_CLOSED, true);
	}
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CanLift::doPeriodic()
{
	if ( ! can_lift_subsystem_ready)
	{
		return;
	}

	{
//		MutexScopeLock block(getLock());

		// Make sure the lift doesn't jump when enabled by keeping the
		// target position at the current position while disabled
		if (getPhase() == DISABLED)
		{
			tote_holder_open_trg = false;
			can_holder_open_trg = false;
			can_pike_open_trg = false;
		}

		//
		// Set Outputs
		//
		tote_holder_sol->Set(tote_holder_sol_invert ? !tote_holder_open_trg : tote_holder_open_trg);
		tote_holder_sol_b->Set(tote_holder_sol_invert ? tote_holder_open_trg : !tote_holder_open_trg);

		can_holder_sol->Set(can_holder_sol_invert ? !can_holder_open_trg : can_holder_open_trg);

		can_pike_sol->Set(can_pike_sol_invert ? !can_pike_open_trg : can_pike_open_trg);
	}

	writeLogMessage();
}

// =============================================================================
// === MSOpen007 Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSOpen007::MSOpen007(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	canlift = (CanLift *)control;
	open_007 = xml->BoolAttribute("open");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSOpen007::init()
{
	canlift->set007Open(open_007);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSOpen007::update()
{
	return next_step;
}
// =============================================================================
// === MSOpenPincher Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSOpenPincher::MSOpenPincher(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	canlift = (CanLift *)control;
	open_pincher = xml->BoolAttribute("open");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSOpenPincher::init()
{
	canlift->setPincherOpen(open_pincher);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSOpenPincher::update()
{
	return next_step;
}
