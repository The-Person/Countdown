This is the code that was being used on the Robonauts robot (Empire) at the last 
off-season event of the year. It also includes the code from the PacBots -- 
practice robots and prototype testbeds.

The code is split into 5 projects. Three libraries that must be built in
the order of gsi (Generic System Interface, also known as an OS Abstraction
Layer), gsu (Generic Software Utilities), and RobonautsLibrary. The two 
remaining projects create images that can be loaded onto robots, one that
was for the competition and matching practice robot (FlightUnit) and the
other for our PacBots. 

The PacBot code has been loaded onto other teams robots at competition, 
it is fairly easy to reconfigure it for a wide variety of hardware
configurations. However, much of the PackBot specific code was reworked
after the competition season and has not been fully tested yet.

