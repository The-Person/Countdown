/*******************************************************************************
 *
 * File: CompressorControl.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <math.h>

#include "RobonautsLibrary/RobotUtil.h"

#include "DashboardDefs.h"
#include "CompressorControl.h"

using namespace tinyxml2;
using namespace gsi;

/******************************************************************************
 *
 *
 *
 ******************************************************************************/
CompressorControl::CompressorControl(std::string name, tinyxml2::XMLElement *xml, double period)
	: PeriodicControl(name, period)
{
	XMLElement *element;

	printf("========================= Creating Compressor Control [%s] =========================\n",
			name.c_str());

	compressor_relay = nullptr;
	compressor_switch = nullptr;

	compressor_switch_invert = false;
	compressor_on = false;
	compressor_fuse = -1;
	compressor_current = 0.0;

	//
	// Parse the XML
	//
	xml->QueryIntAttribute("fuse", &compressor_fuse);

	element = xml->FirstChildElement("digital_input");
	if (element != nullptr)
	{
		printf("  creating switch for compressor\n");
		compressor_switch = XmlRobotUtil::createDigitalInput(element);
		compressor_switch_invert = element->BoolAttribute("invert") ? true : false;
	}

	element = xml->FirstChildElement("relay");
	if (element != NULL)
	{
		printf("  creating compressor relay\n");
		compressor_relay = XmlRobotUtil::createRelay(element);
	}

	if (compressor_switch == nullptr)
	{
		printf("  WARNING: failed to initialize compressor switch\n");
	}

	if (compressor_relay == nullptr)
	{
		printf("  WARNING: failed to create compressor relay\n");
	}
}

/******************************************************************************
 *
 * Destructor
 * 
 ******************************************************************************/
CompressorControl::~CompressorControl()
{
	printf("CompressorSys::~CompressorSys\n");
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorControl::controlInit()
{

}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 *
 ******************************************************************************/
void CompressorControl::updateConfig()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 *
 ******************************************************************************/
void CompressorControl::disabledInit()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 *
 ******************************************************************************/
void CompressorControl::autonomousInit()
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 *
 ******************************************************************************/
void CompressorControl::teleopInit()
{
}

/**********************************************************************
 *
 *
 **********************************************************************/
void CompressorControl::testInit(void)
{
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorControl::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean(std::string("  ") + getName() + "  ", (getCyclesSincePublish() > 0));
	SmartDashboard::PutNumber(getName() +" cycles: ", getCyclesSincePublish());

	SmartDashboard::PutBoolean(getName() + " on: ", (compressor_switch != nullptr) && compressor_on);
	SmartDashboard::PutNumber(getName() + " current: ", compressor_current);
#endif
}

/******************************************************************************
 *
 * Implements method required by PeriodicControl
 * 
 ******************************************************************************/
void CompressorControl::doPeriodic()
{
	if (compressor_switch != nullptr)
	{
		compressor_on = compressor_switch->Get() != compressor_switch_invert;
	}

	if (compressor_fuse != 0xFF)
	{
		compressor_current = RobotUtil::getCurrent(compressor_fuse);
	}

	if (compressor_relay != nullptr)
	{
		compressor_relay->Set(compressor_on ? Relay::kForward : Relay::kOff);
	}
}
