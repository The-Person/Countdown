/*******************************************************************************
 *
 * File: PeriodicControlFactor.h
 *
 * @see PeriodicControlFactory.h for more information about creating controls
 *
 * Written by:
 * 	The Robonautss
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include "PeriodicControlFactory.h"

#include "ArcadeDriveControl.h"
#include "CompressorControl.h"
#include "MotorControl.h"
#include "SolenoidControl.h"
#include "TurretControl.h"
#include "RelayControl.h"

using namespace std;

/*******************************************************************************
 * 
 * This map holds an instance of the ProxyBase class for each type of
 * PeriodicControls that can be created by this factory.
 *    
 ******************************************************************************/
map<string, PeriodicControlProxyBase *> * control_factory_map = nullptr;

/*******************************************************************************
 *
 * Initialize the factory
 *
 * NOTE:	The factory used to use self-registering objects but C++11 does not
 * 			insure that static initializers are executed for library objects so
 * 			controls from libraries were not getting registered. Therefore, this
 * 			init method was added to make sure all objects get registered.
 *
 *			That does mean this file needs to be modified each time a new type
 *			of control is created, the .h file needs to be included and the
 *			class needs to be registered with the factory inside of this init()
 *			method.
 *
 ******************************************************************************/
void PeriodicControlFactory::init(void)
{
	control_factory_map = new map<string, PeriodicControlProxyBase *> ;
	control_factory_map->clear();

	registerProxy("arcade_drive", new PeriodicControlProxy<ArcadeDriveControl>());
	registerProxy("turret", new PeriodicControlProxy<TurretControl>());

	registerProxy("compressor", new PeriodicControlProxy<CompressorControl>());
	registerProxy("motor", new PeriodicControlProxy<MotorControl>());
	registerProxy("solenoid", new PeriodicControlProxy<SolenoidControl>());
	registerProxy("relay", new PeriodicControlProxy<RelayControl>());
}

/*******************************************************************************
 *
 * Register a control with a proxy so it can be created when needed
 *
 ******************************************************************************/
void PeriodicControlFactory::registerProxy(string type, PeriodicControlProxyBase * proxy)
{
	control_factory_map->insert(pair<string, PeriodicControlProxyBase *> (type, proxy));
}

/*******************************************************************************
 *
 * Use a proxy to create a instance of the control
 *
 ******************************************************************************/
PeriodicControl * PeriodicControlFactory::create(string type,
	tinyxml2::XMLElement *xml)
{
	map<string, PeriodicControlProxyBase *>::iterator ittr = control_factory_map->find(type);

	if (ittr == control_factory_map->end())
	{
		return nullptr;
	}

	PeriodicControlProxyBase *proxy = ittr->second;

	return proxy->create(xml);;
}
