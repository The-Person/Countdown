/*******************************************************************************
 *
 * File: ArcadeDriveControl.cpp
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/

#include "RobonautsLibrary/RobotUtil.h"
#include "RobonautsLibrary/XmlRobotUtil.h"

#include "DashboardDefs.h"
#include "ArcadeDriveControl.h"

using namespace tinyxml2;

/*******************************************************************************	
 * 
 * Create an instance of this object and configure it based on the provided
 * XML, period, and priority
 * 
 * @param	xml			the XML used to configure this object, see the class
 * 						definition for the XML format
 * 						
 * @param	period		the time (in seconds) between calls to update()
 * @param	priority	the priority at which this thread/task should run
 * 
 * *****************************************************************************/
ArcadeDriveControl::ArcadeDriveControl(std::string control_name, XMLElement* xml, double period, 	gsi::Thread::ThreadPriority priority)
	:	PeriodicControl(control_name, period, priority)
{
	XMLElement *comp;

	const char *name;

	drive_motor_fl = nullptr;
	drive_motor_fr = nullptr;
	drive_motor_bl = nullptr;
	drive_motor_br = nullptr;

	drive_gear_solenoid = nullptr;
	drive_brake_solenoid = nullptr;

	drive_brake_engaged = false;
	drive_brake_solenoid_invert = false;

	drive_gear_high = false;
	drive_gear_solenoid_invert = false;

	drive_strafe_enabled = false;
	drive_strafe_state = false;
	
	drive_motor_invert_fl = 1.0;
	drive_motor_invert_fr = 1.0;
	drive_motor_invert_bl = 1.0;
	drive_motor_invert_br = 1.0;

	drive_motor_cmd_fl = 0.0;
	drive_motor_cmd_fr = 0.0;
	drive_motor_cmd_bl = 0.0;
	drive_motor_cmd_br = 0.0;

	drive_trn_power = 0.0;
	drive_fwd_power = 0.0;
	
	name = xml->Attribute("name");
	if (name == nullptr)
	{
		name="drive";
		printf(  "WARNING: DriveArchadePBC created without name, assuming \"%s\"\n", name);
	}

	//
	// Register Macro Steps
	//
	new MacroStepProxy<MSDriveArchadeDrivePower>(control_name, "DrivePower", this);
	
	//
	// Parse the XML
	//
	comp = xml-> FirstChildElement("motor");
	while (comp != nullptr)
	{
		name = comp->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "front_left") == 0)
			{				
				printf("  creating speed controller for %s\n", name);
				drive_motor_fl = XmlRobotUtil::createSpeedController(comp);
				drive_motor_invert_fl = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
			else if (strcmp(name, "front_right") == 0)
			{
				printf("  creating speed controller for %s\n", name);
				drive_motor_fr = XmlRobotUtil::createSpeedController(comp);
				drive_motor_invert_fr = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
			else if (strcmp(name, "back_left") == 0)
			{
				printf("  creating speed controller for %s\n", name);
				drive_motor_bl = XmlRobotUtil::createSpeedController(comp);
				drive_motor_invert_bl = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
			else if (strcmp(name, "back_right") == 0)
			{
				printf("  creating speed controller for %s\n", name);
				drive_motor_br = XmlRobotUtil::createSpeedController(comp);
				drive_motor_invert_br = comp->BoolAttribute("invert") ? -1.0 : 1.0;
			}
		}
		comp = comp->NextSiblingElement("motor");
	}

	comp = xml-> FirstChildElement("solenoid");
	while (comp != nullptr)
	{
		name = comp->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "brake") == 0)
			{				
				printf("  creating solenoid for %s\n", name);
				drive_brake_solenoid = XmlRobotUtil::createSolenoid(comp);
				drive_brake_solenoid_invert = comp->BoolAttribute("invert");
			}
			else if (strcmp(name, "gear") == 0)
			{
				printf("  creating solenoid for %s\n", name);
				drive_gear_solenoid = XmlRobotUtil::createSolenoid(comp);
				drive_gear_solenoid_invert = comp->BoolAttribute("invert");
			}
		}
		comp = comp->NextSiblingElement("solenoid");
	}

	comp = xml-> FirstChildElement("oi");
	while (comp != nullptr)
	{
		name = comp->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "forward") == 0)
			{
				printf("  connecting to forward channel\n");
				OIController::subscribeAnalog(comp, this, CMD_FORWARD);
			}
			else if (strcmp(name, "turn") == 0)
			{
				printf("  connecting to turn channel\n");
				OIController::subscribeAnalog(comp, this, CMD_TURN);
			}
			else if (strcmp(name, "strafe_on") == 0)
			{
				printf("  connecting to strafe on channel\n");
				OIController::subscribeDigital(comp, this, CMD_STRAFE_ON);
				drive_strafe_enabled = true;
			}
			else if (strcmp(name, "strafe_off") == 0)
			{
				printf("  connecting to strafe off channel\n");
				OIController::subscribeDigital(comp, this, CMD_STRAFE_OFF);
				drive_strafe_enabled = true;
			}
			else if (strcmp(name, "strafe_toggle") == 0)
			{
				printf("  connecting to strafe toggle channel\n");
				OIController::subscribeDigital(comp, this, CMD_STRAFE_TOGGLE);
				drive_strafe_enabled = true;
			}
			else if (strcmp(name, "strafe_state") == 0)
			{
				printf("  connecting to strafe state channel\n");
				OIController::subscribeDigital(comp, this, CMD_STRAFE_STATE);
				drive_strafe_enabled = true;
			}
			else if (strcmp(name, "brake_on") == 0)
			{
				printf("  connecting to brake_on channel\n");
				OIController::subscribeDigital(comp, this, CMD_BRAKE_ON);
			}
			else if (strcmp(name, "brake_off") == 0)
			{
				printf("  connecting to brake_off channel\n");
				OIController::subscribeDigital(comp, this, CMD_BRAKE_OFF);
			}
			else if (strcmp(name, "brake_toggle") == 0)
			{
				printf("  connecting to brake_toggle channel\n");
				OIController::subscribeDigital(comp, this, CMD_BRAKE_TOGGLE);
			}
			else if (strcmp(name, "brake_state") == 0)
			{
				printf("  connecting to brake_state channel\n");
				OIController::subscribeDigital(comp, this, CMD_BRAKE_STATE);
			}
			else if (strcmp(name, "gear_high") == 0)
			{
				printf("  connecting to gear_high channel\n");
				OIController::subscribeDigital(comp, this, CMD_GEAR_HIGH);
			}
			else if (strcmp(name, "gear_low") == 0)
			{
				printf("  connecting to gear_low channel\n");
				OIController::subscribeDigital(comp, this, CMD_GEAR_LOW);
			}
			else if (strcmp(name, "gear_toggle") == 0)
			{
				printf("  connecting to gear_toggle channel\n");
				OIController::subscribeDigital(comp, this, CMD_GEAR_TOGGLE);
			}
			else if (strcmp(name, "gear_state") == 0)
			{
				printf("  connecting to gear_state channel\n");
				OIController::subscribeDigital(comp, this, CMD_GEAR_STATE);
			}
		}
		comp = comp->NextSiblingElement("oi");
	}
}

/*******************************************************************************	
 *
 * Release any resources used by this object
 * 
 ******************************************************************************/
ArcadeDriveControl::~ArcadeDriveControl(void)
{
	if (drive_motor_fl == nullptr)
	{
		delete drive_motor_fl;
		drive_motor_fl = nullptr;
	}
	
	if (drive_motor_fr == nullptr)
	{
		delete drive_motor_fr;
		drive_motor_fr = nullptr;
	}
	
	if (drive_motor_bl == nullptr)
	{
		delete drive_motor_bl;
		drive_motor_bl = nullptr;
	}
	
	if (drive_motor_br == nullptr)
	{
		delete drive_motor_br;
		drive_motor_br = nullptr;
	}

	if (drive_gear_solenoid != nullptr)
	{
		delete drive_gear_solenoid;
		drive_gear_solenoid = nullptr;
	}
	
	if (drive_brake_solenoid != nullptr)
	{
		delete drive_brake_solenoid;
		drive_brake_solenoid = nullptr;
	}
}

/*******************************************************************************	
 *
 ******************************************************************************/
void ArcadeDriveControl::updateConfig()
{
}

/*******************************************************************************	
 *
 ******************************************************************************/
void ArcadeDriveControl::controlInit()
{
	drive_fwd_power = 0.0;
	drive_trn_power = 0.0;
}

/*******************************************************************************	
 *
 ******************************************************************************/
void ArcadeDriveControl::disabledInit()
{
	drive_fwd_power = 0.0;
	drive_trn_power = 0.0;
}

/*******************************************************************************	
 *
 ******************************************************************************/
void ArcadeDriveControl::autonomousInit()
{
	drive_fwd_power = 0.0;
	drive_trn_power = 0.0;
}

/*******************************************************************************	
 *
 ******************************************************************************/
void ArcadeDriveControl::teleopInit()
{
	drive_fwd_power = 0.0;
	drive_trn_power = 0.0;
}

/*******************************************************************************	
 *
 ******************************************************************************/
void ArcadeDriveControl::testInit()
{
	drive_fwd_power = 0.0;
	drive_trn_power = 0.0;
}

/*******************************************************************************
 *
 * Sets the state of the control based on the command id and value
 * 
 * Handled command ids are CMD_TURN and CMD_FORWARD, all others are ignored
 * 
 * @param	id	the command id that indicates what the val argument means
 * @param	val	the new value
 * 
 ******************************************************************************/
void ArcadeDriveControl::setAnalog(int id, float val)
{
	switch (id)
	{
		case CMD_TURN:
			drive_trn_power = val;
			break;

		case CMD_FORWARD:
			drive_fwd_power = val;
			break;

		default:
			break;
	}
}

/*******************************************************************************	
 *
 * Sets the state of the control based on the command id and value
 *  
 * Handled command ids are CMD_BRAKE_[ON|OFF|TOGGLE|STATE] and 
 * CMD_GEAR_[HIGH|LOW|TOGGLE|STATE], all others are ignored
 *
 * @param	id	the command id that indicates what the val argument means
 * @param	val	the new value
 * 
 ******************************************************************************/
void ArcadeDriveControl::setDigital(int id, bool val)
{
	switch(id)
	{
		case CMD_BRAKE_ON:
			if (val) drive_brake_engaged = true;
			break;
			
		case CMD_BRAKE_OFF:
			if (val) drive_brake_engaged = false;
			break;
			
		case CMD_BRAKE_TOGGLE:
			if (val) drive_brake_engaged = !drive_brake_engaged;
			break;
			
		case CMD_BRAKE_STATE:
			drive_brake_engaged = val;
			break;
			
		case CMD_GEAR_HIGH:
			if (val) drive_gear_high = true;
			break;
			
		case CMD_GEAR_LOW:
			if (val) drive_gear_high = false;
			break;
			
		case CMD_GEAR_TOGGLE:
			if (val) drive_gear_high = !drive_gear_high;
			break;
			
		case CMD_GEAR_STATE:
			drive_gear_high = val;
			break;

		case CMD_STRAFE_ON:
			if (val) drive_strafe_state = true;
			break;

		case CMD_STRAFE_OFF:
			if (val) drive_strafe_state = false;
			break;

		case CMD_STRAFE_TOGGLE:
			if (val) drive_strafe_state = !drive_strafe_state;
			break;

		case CMD_STRAFE_STATE:
			drive_strafe_state = val;
			break;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void ArcadeDriveControl::publish()
{
#if (DASHBOARD_TYPE == SMART_DASHBOARD)
	SmartDashboard::PutBoolean(std::string("  ") + getName() + "  ", (getCyclesSincePublish() > 0));
	SmartDashboard::PutNumber(getName() +" cycles: ", getCyclesSincePublish());

	SmartDashboard::PutNumber(getName() +" forward: ", drive_fwd_power);
	SmartDashboard::PutNumber(getName() +" turn: ", drive_trn_power);

	if (drive_gear_solenoid != nullptr)
	{
		SmartDashboard::PutBoolean(getName() +" gear: ", drive_gear_high);
	}

	if (drive_brake_solenoid != nullptr)
	{
		SmartDashboard::PutBoolean(getName() +" brake: ", drive_brake_engaged);
	}

	if (drive_motor_fl != nullptr)
	{
		SmartDashboard::PutNumber(getName() +" fl cmd: ", drive_motor_cmd_fl);
	}

	if (drive_motor_fr != nullptr)
	{
		SmartDashboard::PutNumber(getName() +" fr cmd: ", drive_motor_cmd_fr);
	}

	if (drive_motor_bl != nullptr)
	{
		SmartDashboard::PutNumber(getName() +" bl cmd: ", drive_motor_cmd_bl);
	}

	if (drive_motor_br != nullptr)
	{
		SmartDashboard::PutNumber(getName() +" br cmd: ", drive_motor_cmd_br);
	}

	if (drive_strafe_enabled)
	{
		SmartDashboard::PutBoolean(getName() +" strafe: ", drive_strafe_state);
	}

#endif
}

/*******************************************************************************	
 * 
 * Sets the actuator values every period
 * 
 ******************************************************************************/
void ArcadeDriveControl::doPeriodic()
{
	//
	// Read Sensors
	//

	//
	// Calculate Values
	//
	drive_motor_cmd_fl = RobotUtil::limit(-1.0, 1.0, drive_fwd_power - drive_trn_power);
	drive_motor_cmd_fr = RobotUtil::limit(-1.0, 1.0, drive_fwd_power + drive_trn_power);
	drive_motor_cmd_bl = drive_motor_cmd_fl;
	drive_motor_cmd_br = drive_motor_cmd_fr;

	if (drive_strafe_state)
	{
		drive_motor_cmd_fl *= -1.0;
		drive_motor_cmd_br *= -1.0;
	}

	// don't drive motors against the brake;
	if (drive_brake_engaged)
	{
		drive_motor_cmd_fl = 0.0;
		drive_motor_cmd_fr = 0.0;
	    drive_motor_cmd_bl = 0.0;
        drive_motor_cmd_br = 0.0;
	}

	//
	// Set Outputs
	//
	if (drive_brake_solenoid != nullptr)
	{
		drive_brake_solenoid->Set(drive_brake_engaged != drive_brake_solenoid_invert);
	}

	if (drive_gear_solenoid != nullptr)
	{
		drive_gear_solenoid->Set(drive_gear_high != drive_gear_solenoid_invert);
	}
	
	if (drive_motor_fl != nullptr)
	{
		drive_motor_fl->Set(drive_motor_cmd_fl * drive_motor_invert_fl);
	}
	
	if (drive_motor_fr != nullptr)
	{
		drive_motor_fr->Set(drive_motor_cmd_fr * drive_motor_invert_fr);
	}
	
	if (drive_motor_bl != nullptr)
	{
		drive_motor_bl->Set(drive_motor_cmd_bl * drive_motor_invert_bl);
	}
	
	if (drive_motor_br != nullptr)
	{
		drive_motor_br->Set(drive_motor_cmd_br * drive_motor_invert_br);
	}	
}


// =============================================================================
// =============================================================================

/*******************************************************************************
 *
 ******************************************************************************/
MSDriveArchadeDrivePower::MSDriveArchadeDrivePower(std::string type, tinyxml2::XMLElement *xml, void *control)
	: MacroStepSequence(type, xml, control)
{
	parent_control = (ArcadeDriveControl *)control;

	forward = 0.0;
	turn    = 0.0;
	strafe  = false;

	xml->QueryFloatAttribute("forward", &forward);
	xml->QueryFloatAttribute("turn", &turn);
	xml->QueryBoolAttribute("strafe", &strafe);
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSDriveArchadeDrivePower::init(void)
{
	parent_control->setDigital(ArcadeDriveControl::CMD_STRAFE_STATE, strafe);
	parent_control->setAnalog(ArcadeDriveControl::CMD_FORWARD, forward);
	parent_control->setAnalog(ArcadeDriveControl::CMD_TURN, turn);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MSDriveArchadeDrivePower::update(void)
{
	return next_step;
}
