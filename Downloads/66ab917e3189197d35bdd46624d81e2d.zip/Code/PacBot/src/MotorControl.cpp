/*******************************************************************************
 *
 * File: MotorControl.cpp
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include "RobonautsLibrary/RobotUtil.h"
#include "RobonautsLibrary/XmlRobotUtil.h"

#include "MotorControl.h"

using namespace tinyxml2;

/*******************************************************************************	
 * 
 * Create an instance of a motor control and connect it to the specified
 * motor and inputs
 * 
 ******************************************************************************/
MotorControl::MotorControl(std::string control_name, XMLElement* xml, double period,
	gsi::Thread::ThreadPriority priority)
	: PeriodicControl(control_name, period, priority)
{
	XMLElement *comp;
	
	motor_a = nullptr;
	motor_b = nullptr;

	motor_increment_step = 0.1;
	motor_decrement_step = 0.1;

	motor_momentary_a_value = 0.0;
	motor_momentary_b_value = 0.0;
	motor_momentary_c_value = 0.0;
	motor_momentary_d_value = 0.0;

	motor_max_cmd_delta = 0.25;

	motor_a_scale = 1.0;  // if invert = true, scale = -1.0, else scale = 1.0
	motor_b_scale = 1.0;  // if invert = true, scale = -1.0, else scale = 1.0

	motor_target_power = 0.0;
	motor_command_power = 0.0;

	const char *name = nullptr;

	//
	// Register Macro Steps
	//

	//
	// Parse XML
	//
	comp = xml-> FirstChildElement("motor");
	if (comp != nullptr)
	{
		printf("  creating speed controller for motor_a\n");
		motor_a = XmlRobotUtil::createSpeedController(comp);
		motor_a_scale = comp->BoolAttribute("invert") ? -1.0f : 1.0f;
	}
	
	comp = comp-> NextSiblingElement("motor");
	if (comp != nullptr)
	{
		printf("  creating speed controller for motor_b\n");
		motor_b = XmlRobotUtil::createSpeedController(comp);
		motor_b_scale = comp->BoolAttribute("invert") ? -1.0f : 1.0f;
	}
	
	xml->QueryFloatAttribute("max_cmd_delta", &motor_max_cmd_delta);
	printf("  max cmd delta = %f\n", motor_max_cmd_delta);

	comp = xml-> FirstChildElement("oi");
	while (comp != nullptr)
	{
		name = comp->Attribute("name");
		if (name != nullptr)
		{
			if (strcmp(name, "analog") == 0)
			{
				printf("  connecting analog channel\n");
				OIController::subscribeAnalog(comp, this, CMD_ANALOG);
			}
			else if (strcmp(name, "increment") == 0)
			{
				printf("  connecting increment channel\n");
				comp->QueryFloatAttribute("step", &motor_increment_step);
				OIController::subscribeDigital(comp, this, CMD_INCREMENT);
			}
			else if (strcmp(name, "decrement") == 0)
			{
				printf("  connecting decrement channel\n");
				comp->QueryFloatAttribute("step", &motor_decrement_step);
				OIController::subscribeDigital(comp, this, CMD_DECREMENT);
			}
			else if (strcmp(name, "stop") == 0)
			{
				printf("  connecting stop channel\n");
				OIController::subscribeDigital(comp, this, CMD_STOP);
			}
			else if (strcmp(name, "momentary_a") == 0)
			{
				printf("  connecting momentary_a channel\n");
				comp->QueryFloatAttribute("value", &motor_momentary_a_value);
				OIController::subscribeDigital(comp, this, CMD_MOMENTARY_A);
			}
			else if (strcmp(name, "momentary_b") == 0)
			{
				printf("  connecting momentary_b channel\n");
				comp->QueryFloatAttribute("value", &motor_momentary_b_value);
				OIController::subscribeDigital(comp, this, CMD_MOMENTARY_B);
			}
			else if (strcmp(name, "momentary_c") == 0)
			{
				printf("  connecting momentary_c channel\n");
				comp->QueryFloatAttribute("value", &motor_momentary_c_value);
				OIController::subscribeDigital(comp, this, CMD_MOMENTARY_C);
			}
			else if (strcmp(name, "momentary_d") == 0)
			{
				printf("  connecting momentary_d channel\n");
				comp->QueryFloatAttribute("value", &motor_momentary_d_value);
				OIController::subscribeDigital(comp, this, CMD_MOMENTARY_D);
			}
		}
		
		comp = comp->NextSiblingElement("oi");
	}
}

/*******************************************************************************	
 * 
 * Release any resources allocated by this object
 * 
 ******************************************************************************/
MotorControl::~MotorControl(void)
{
	if (motor_a != nullptr)
	{
		delete motor_a;
		motor_a = nullptr;
	}
	if (motor_b != nullptr)
	{
		delete motor_b;
		motor_b = nullptr;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void MotorControl::controlInit(void)
{

}

/*******************************************************************************
 *
 ******************************************************************************/
void MotorControl::updateConfig(void)
{

}

/*******************************************************************************	
 *
 * Reset power to 0
 * 
 ******************************************************************************/
void MotorControl::disabledInit(void)
{
	motor_target_power = 0.0;
	motor_command_power = 0.0;
}

/*******************************************************************************	
 *
 * Reset power to 0
 * 
 ******************************************************************************/
void MotorControl::autonomousInit(void)
{
	motor_target_power = 0.0;
	motor_command_power = 0.0;
}

/*******************************************************************************	
 *
 * Reset power to 0
 * 
 ******************************************************************************/
void MotorControl::teleopInit(void)
{
	motor_target_power = 0.0;
	motor_command_power = 0.0;
}

/*******************************************************************************	
 *
 * Reset power to 0
 *
 ******************************************************************************/
void MotorControl::testInit(void)
{
}

/*******************************************************************************
 *
 * This is the callback for OIController::subscribeAnalog, if the XML config 
 * specifies an analog input, the constructor of this object will connect that 
 * input to this method.
 * 
 * @param id	the control id passed to the subscribe
 * @param val	the new value of the analog channel that was subscribed to
 * 
 ******************************************************************************/
void MotorControl::setAnalog(int id, float val)
{
	if (id == CMD_ANALOG)
	{
		motor_target_power = RobotUtil::limit(-1.0, 1.0, val);
	}
}

/*******************************************************************************	
 *
 * This is the callback for OIController::setDigital, if the XML config 
 * specifies an increment, decrement, or stop input, the constructor 
 * of this object will connect that/those input(s) to this method.
 * 
 * @param id	the control id passed to the subscribe
 * @param val	the new value of the digital channel that was subscribed to
 * 
 ******************************************************************************/
void MotorControl::setDigital(int id, bool val)
{
	switch (id)
	{
		case CMD_INCREMENT:
		{
			if (val)
			{
				motor_target_power = RobotUtil::limit(-1.0, 1.0, motor_target_power + motor_increment_step);
			}
		} break;
			
		case CMD_DECREMENT:
		{
			if (val)
			{
				motor_target_power = RobotUtil::limit(-1.0, 1.0, motor_target_power - motor_decrement_step);
			}
		} break;
			
		case CMD_STOP:
		{
			if (val)
			{
				motor_target_power = 0.0;
			}
		} break;

		case CMD_MOMENTARY_A:
		{
			if(val)
			{
				motor_target_power = RobotUtil::limit(-1.0, 1.0, motor_momentary_a_value);
			}
			else
			{
				motor_target_power = 0.0;
			}
		} break;

		case CMD_MOMENTARY_B:
		{
			if(val)
			{
				motor_target_power = RobotUtil::limit(-1.0, 1.0, motor_momentary_b_value);
			}
			else
			{
				motor_target_power = 0.0;
			}
		} break;

		case CMD_MOMENTARY_C:
		{
			if(val)
			{
				motor_target_power = RobotUtil::limit(-1.0, 1.0, motor_momentary_c_value);
			}
			else
			{
				motor_target_power = 0.0;
			}
		} break;

		case CMD_MOMENTARY_D:
		{
			if(val)
			{
				motor_target_power = RobotUtil::limit(-1.0, 1.0, motor_momentary_d_value);
			}
			else
			{
				motor_target_power = 0.0;
			}
		} break;
			
		default:
			break;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void MotorControl::setInt(int id, int val)
{
}

/*******************************************************************************	
 *
 ******************************************************************************/
void MotorControl::publish()
{
}

/*******************************************************************************
 *
 * This method will be called once a period to do anything that is needed,
 * in this case it just sets the motor power to the current value.
 * 
 ******************************************************************************/
void MotorControl::doPeriodic()
{
	// no sensor inputs for this object

	//
	// process values
	//
	if (motor_target_power > motor_command_power + motor_max_cmd_delta)
	{
		motor_command_power += motor_max_cmd_delta;
	}
	else if (motor_target_power < motor_command_power - motor_max_cmd_delta)
	{
		motor_command_power -= motor_max_cmd_delta;
	}
	else
	{
		motor_command_power = motor_target_power;
	}

	//
	// Set Outputs
	//
	if (motor_a != nullptr)
	{
		motor_a->Set(motor_command_power * motor_a_scale);
	}

	if (motor_b != nullptr)
	{
		motor_b->Set(motor_command_power * motor_b_scale);
	}
}


// =============================================================================
// =============================================================================

/*******************************************************************************
 *
 ******************************************************************************/
//MSMotorControlSetPower::MSMotorControlSetPower(std::string type, tinyxml2::XMLElement *xml, void *control)
//	: MacroStepSequence(type, xml, control)
//{
//	parent_control = (MotorControl *)control;
//
//	power = xml->FloatAttribute("power");
//}

/*******************************************************************************
 *
 ******************************************************************************/
//void MSMotorControlSetPower::init(void)
//{
//	parent_control->setAnalog(MotorControl::CMD_ANALOG, power);
//}

/*******************************************************************************
 *
 ******************************************************************************/
//MacroStep * MSMotorControlSetPower::update(void)
//{
//	return next_step;
//}

