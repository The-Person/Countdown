/*******************************************************************************
 *
 * File: RobotMain.cpp
 *
 * Written by:   
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <stdlib.h>
#include <string>
#include <iostream>

#include "WPILib.h"

#include "PeriodicControlFactory.h"
#include "DashboardDefs.h"

#include "RobotMain.h"

using namespace tinyxml2;

/******************************************************************************
 *
 * Creates a new RobotMain instance and initializes some private variables,
 * most of the work is done in RobotInit
 *
 ******************************************************************************/
RobotMain::RobotMain(void) : IterativeRobot(), OIObserver()
{
	printf("RobotMain::RobotMain\n");

	publish_count = 0;

	PeriodicControlFactory::init();

	macro_controller = new MacroController();
}

/******************************************************************************
 *
 * Deletes any controls in the destructor
 *
 ******************************************************************************/
RobotMain::~RobotMain()
{
	printf("RobotMain::~RobotMain\n");

	for (PeriodicControl *control :  controls )
	{
		delete control;
	}
	controls.clear();

	if (macro_controller != nullptr)
	{
		delete macro_controller;
		macro_controller = nullptr;
	}
}

/******************************************************************************
 *
 * Initializes the robot and controls
 *
 * First loads the control definitions, then initializes each of the controls,
 * and finally starts each of the controls.
 *
 ******************************************************************************/
void RobotMain::RobotInit(void)
{
	printf("RobotMain::RobotInit\n");

	LoadRobot("/config/RobotControl.xml");

	for (PeriodicControl *control : controls )
	{
		control->doControlInit();
	}

	for (PeriodicControl *control : controls )
	{
		control->start();
	}
}

/******************************************************************************
 *
 * Loads the XML file and creates each control object accordingly
 *
 * Expected XML file format is defined below, element order does not matter
 *
 * <robot [name="robot1"]>
 *   [<interface>
 *      [<device name="base" type="joystick" num="0" />]
 *      [ ... more devices ... ]
 *   </interface>]
 *
 *   [<control type="compressor" [name="onboard"] [control dependent options] >
 *   	[define control elements]
 *   </control>]
 *   [ ... more controls ...]
 *
 *   [<macro name"macro1" file="macro1_file.txt" >
 *   	[<oi name="start" device="base" chan="7" />]
 *   	[ ... more button connections ...]
 *   </macro>]
 *   [ ... more macros ...]
 * </robot>
 *
 ******************************************************************************/
void RobotMain::LoadRobot(std::string file)
{
	XMLDocument doc;
	doc.LoadFile(file.c_str());
	XMLElement *robot = doc.FirstChildElement("robot");

	if (robot == nullptr)
	{
		printf("ERROR: could not read config file %s, no \"robot\" element\n",
			file.c_str());
		return;
	}
	
	const char *name = robot->Attribute("name");
	if (name != nullptr)
	{
		printf("RobotMain  Loading Robot: %s\n", name);
	}
	else
	{
		printf("RobotMain  Loading Robot: unnamed\n");
	}

	XMLElement *oi_xml = robot->FirstChildElement("interface");
	if (oi_xml != nullptr)
	{
		OIController::configure(oi_xml);
	}
	else
	{
		printf("ERROR: could not initialize OIController, no xml element named \"interface\"");
		return;
	}
	
	XMLElement *control_xml = robot->FirstChildElement("control");
	while (control_xml != nullptr)
	{
		const char *type = control_xml->Attribute("type");
		const char *name = control_xml->Attribute("name");
		
		if (name == nullptr)
		{
			name = "unnamed";
		}
		
		if (type != nullptr)
		{
			printf("Create %s - %s\n", type, name);
			PeriodicControl *control = PeriodicControlFactory::create(type, control_xml);

			if (control != nullptr)
			{
				controls.push_back(control);
			}
			else
			{
				printf("ERROR: failed to create control %s - %s\n", type, name);
				printf("       make sure the %s type is registered with the factory\n\n", type);
			}
		}
		else
		{
			printf("ERROR: could not create control, type is NULL\n");
		}

		control_xml = control_xml->NextSiblingElement("control");
	}

	XMLElement *macro_xml = robot->FirstChildElement("macro");
	while (macro_xml != nullptr)
	{
		const char *macro_name = macro_xml->Attribute("name");
		const char *macro_file = macro_xml->Attribute("file");

		if ((macro_name != nullptr) && (macro_file != nullptr))
		{
			macro_controller->loadMacro(macro_name, macro_file, this);

			XMLElement *oi_xml = macro_xml->FirstChildElement("oi");
			while (oi_xml != nullptr)
			{
				printf("  connecting macro %s to oi button\n", macro_name);
				OIController::subscribeDigital(oi_xml, this, CMD_START_MACRO + macro_name_list.size());
				oi_xml = oi_xml->NextSiblingElement("oi");
			}

			macro_name_list.push_back(macro_name);
			macro_file_list.push_back(macro_file);

			if ((CMD_START_MACRO + macro_name_list.size()) > CMD_START_MACRO_MAX)
			{
				printf("WARNING: maximum number of macro files loaded, no more will be loaded\n");
				break;
			}
		}
		else
		{
			printf("ERROR: could not load macro file\n");
		}
		macro_xml = macro_xml->NextSiblingElement("macro");
	}
}

/*******************************************************************************
 *
 * Overrides the default implementation of the OIObserver method to handle
 * button clicks that are used to start macros
 *
 ******************************************************************************/
void RobotMain::setDigital(int id, bool val)
{
	try
	{
		if ((id >= CMD_START_MACRO) && (id < CMD_START_MACRO_MAX))
		{
			if (val)
			{
				macro_controller->startMacro(macro_name_list[id - CMD_START_MACRO]);
			}
		}
	}
	catch (...)
	{
		printf("EXCEPTION: caught in RobotMain::setDigital\n");
	}
}

/******************************************************************************
 *
 * Disables the robot, calls each control to notify them of the change in
 * operations mode
 *
 ******************************************************************************/
void RobotMain::DisabledInit(void)
{
	printf("RobotMain::DisabledInit\n");

	macro_controller->abortAll();

	for (PeriodicControl *control :  controls )
	{
		control->doDisabledInit();
	}
}

/******************************************************************************
 *
 * Handles cycles while disabled, allows for user inputs to be processed and
 * publishes robot status
 *
 ******************************************************************************/
void RobotMain::DisabledPeriodic(void)
{
	OIController::update();
	publish();
}

/******************************************************************************
 *
 * Initializes Autonomous mode, calls each control to notify them of the
 * change in operations mode, then starts the auton macro if one was loaded.
 *
 ******************************************************************************/
void RobotMain::AutonomousInit(void)
{
	printf("RobotMain::AutonomousInit\n");

	for (PeriodicControl *control :  controls )
	{
		control->doAutonomousInit();
	}

	macro_controller->startMacro("auton");
}

/******************************************************************************
 *
 * Handles cycles while in autonomous mode, allows for user inputs to be
 * processed, updates any running macros, and publishes robot status
 *
 ******************************************************************************/
void RobotMain::AutonomousPeriodic(void)
{
	OIController::update();
	macro_controller->update();
	publish();
}

/******************************************************************************
 *
 * Initializes Teleop mode, calls each control to notify them of the
 * change in operations mode.
 *
 ******************************************************************************/
void RobotMain::TeleopInit(void)
{
	printf("RobotMain::TeleopInit\n");

	for (PeriodicControl *control :  controls )
	{
		control->doTeleopInit();
	}
}

/******************************************************************************
 *
 * Handles cycles while in teleop mode, allows for user inputs to be
 * processed, updates any running macros, and publishes robot status
 *
 ******************************************************************************/
void RobotMain::TeleopPeriodic(void)
{
	OIController::update();
	macro_controller->update();
	publish();
}

/******************************************************************************
 *
 * Initializes Test mode, calls each control to notify them of the
 * change in operations mode.
 *
 ******************************************************************************/
void RobotMain::TestInit(void)
{
	printf("RobotMain::TestInit\n");

	for (PeriodicControl *control :  controls )
	{
		control->doTestInit();
	}
}

/******************************************************************************
 *
 * Handles cycles while in test mode, allows for user inputs to be
 * processed, updates any running macros, and publishes robot status
 *
 ******************************************************************************/
void RobotMain::TestPeriodic(void)
{
	OIController::update();
	macro_controller->update();
	publish();
}

/******************************************************************************
 *
 * Publishes any top level status and calls each control to allow them to
 * publish their status
 *
 ******************************************************************************/
void RobotMain::publish(void)
{
	if (publish_count++ >= 10)
	{
#if (DASHBOARD_TYPE == LABVIEW_DASHBOARD)

#elif (DASHBOARD_TYPE == SMART_DASHBOARD)
		SmartDashboard::PutNumber("Macros Started:",   macro_controller->getMacroStarts());
		SmartDashboard::PutNumber("Macros Completed:", macro_controller->getMacroCompletes());
		SmartDashboard::PutNumber("Macros Aborted:",   macro_controller->getMacroAborts());
		SmartDashboard::PutNumber("Macros Running:",   macro_controller->getMacrosRunning());

#elif (DASHBOARD_TYPE == UDP_DASHBOARD)

#endif

		for (PeriodicControl *control : controls )
		{
			control->doPublish();
		}
		publish_count = 0;
	}
}

/******************************************************************************
 *
 * This macro is required to register this as the class that should be
 * used to control the robot
 *
 ******************************************************************************/
START_ROBOT_CLASS(RobotMain)
