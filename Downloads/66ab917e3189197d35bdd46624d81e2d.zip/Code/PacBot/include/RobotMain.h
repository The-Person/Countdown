/*******************************************************************************
 *
 * File: RobotMain.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "IterativeRobot.h"

#include "RobonautsLibrary/PeriodicControl.h"
#include "RobonautsLibrary/MacroController.h"
#include "RobonautsLibrary/OIController.h"
#include "RobonautsLibrary/OIObserver.h"

/*******************************************************************************
 *
 * The main class for this robot controls the creation of the robot, loading
 * the configuration from file, and controlling the transition between
 * operation phases.
 * 
 ******************************************************************************/
class RobotMain : public IterativeRobot, public OIObserver
{
	enum RobotMainCommand
	{
		CMD_START_MACRO = 1000, CMD_START_MACRO_MAX = 1199
	};

	public:
		RobotMain(void);
		~RobotMain();

		void RobotInit(void);
		void UpdateConfig(void);
		void LoadRobot(std::string file);

		void DisabledInit(void);
		void DisabledPeriodic(void);

		void AutonomousInit(void);
		void AutonomousPeriodic(void);

		void TeleopInit(void);
		void TeleopPeriodic(void);

		void TestInit(void);
		void TestPeriodic(void);

		void setDigital(int id, bool val);
		// void setAnalog(int id, float val);
		// void setInt(int id, int val);

	private:
		void publish(void);

		MacroController *macro_controller;
		std::vector<std::string> macro_name_list;
		std::vector<std::string> macro_file_list;

		std::vector<PeriodicControl*> controls;

		uint8_t publish_count;
};
