/*******************************************************************************
 *
 * File: PeriodicControlFactor.h
 * 
 * This file contains the definition of the PeriodicControlProxyBase, the
 * PeriodicControlProxy template, and the PeriodicControlFactory classes.
 *
 * 
 *  Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include <vector>
#include <map>
#include <string>

#include "RobonautsLibrary/XmlRobotUtil.h"

#include "RobonautsLibrary/PeriodicControl.h"

/*******************************************************************************
 *
 * The PacbotContrlProxy class is the base class for all proxy classes.  These
 * proxy classes are used to register a PacbotControl class with the factory so
 * instances can be created via the factory.
 * 
 * Most PacbotControl classes will be able to use the c preprocessor macro 
 * defined below to declare and create a single proxy instance.  Howerver, if 
 * the PacbotControl requires special construction a separate proxy that 
 * extends this base class can be declared and instantiated.
 * 
 ******************************************************************************/
class PeriodicControlProxyBase
{
	public:
		PeriodicControlProxyBase(void)	{}
		virtual ~PeriodicControlProxyBase(void) {}
		virtual PeriodicControl * create(tinyxml2::XMLElement *xml) = 0;
};

/*******************************************************************************
 *
 *
 *
 ******************************************************************************/
template <class PCB>
class PeriodicControlProxy : public PeriodicControlProxyBase
{
	public:
		PeriodicControlProxy(): PeriodicControlProxyBase()	{}
		~PeriodicControlProxy(void) {}

		PeriodicControl * create(tinyxml2::XMLElement *xml)
		{
			PeriodicControl *pc = nullptr;

			const char *control_name = xml->Attribute("name");
			if (control_name == nullptr)
			{
				control_name = "unnamed";
			}

			double period = 0.0;
			xml->QueryDoubleAttribute("period", &period);
			if (period == 0.0)
			{
				PCB *c = new PCB(std::string(control_name), xml);
				pc = (PeriodicControl *)(c);
			}
			else
			{
				pc = (PeriodicControl *)(new PCB(std::string(control_name), xml, period));
			}

			return pc;
		}
};

/*******************************************************************************
 *
 * This class is used to create PacbotControls given a string that represents
 * the type of control and a pointer to an XML structure that contains the
 * definition needed to configure the control.
 *
 * Every PacbotControll needs to have a PacbotControlProxy that knows how to 
 * create the PacbotControl.  The proxy needs to register with this factory 
 * when it is created.  A single static instance of the proxy should be 
 * created in the same file that the proxy is defined.
 *
 ******************************************************************************/
class PeriodicControlFactory
{
	public:
		static void init(void);
		static void registerProxy(std::string type, PeriodicControlProxyBase * proxy);
		static PeriodicControl * create(std::string type, tinyxml2::XMLElement *xml);
};
