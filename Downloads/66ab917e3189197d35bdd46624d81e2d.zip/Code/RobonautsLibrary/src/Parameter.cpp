/*******************************************************************************
 *
 * File: Balance.cpp
 *
 * This file contains the definition of a class used to read name-value pairs
 * from a file and make them available to all other classes.
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <string>
#include <cstdio>
#include <cstdlib>

#include "RobonautsLibrary/Parameter.h"

using namespace std;

/*******************************************************************************
 * 
 ******************************************************************************/
map<string, string> Parameter::params;
string Parameter::filename = "/ni-rt/startup/params.txt";

/*******************************************************************************
 * 
 * Set the name of the file that will be loaded.
 * 
 ******************************************************************************/
void Parameter::setFilename(string file)
{
	filename = file;
}

/*******************************************************************************
 * 
 * This method reads in the parameter file (params.txt) and saves the
 * values into a map.
 * 
 ******************************************************************************/
void Parameter::load(void)
{
	params.clear();

	FILE *file = fopen(filename.c_str(), "r");

	char key[64];
	char value[32];

	if (file)
	{
		while (fscanf(file, "%s%s", key, value) != EOF)
		{
			params.insert(pair<string, string> (key, value));
		}

		fclose(file);
		file = NULL;
	}
	else
	{
		printf("WARNING: Could not open parameter file %s\n", filename.c_str());
	}
}

/*******************************************************************************
 * 
 * This method searches a map to find a parameter with a key that matches
 * the given name. If found, the integer value is returned, otherwise
 * a default value is returned.
 * 
 ******************************************************************************/
int Parameter::getAsInt(string name, int def)
{
	map<string, string>::iterator it = params.find(name);
	if (it != params.end())
		return atoi(it->second.c_str());
	return def;
}

/*******************************************************************************
 * 
 * This method searches a map to find a parameter with a key that matches
 * the given name. If found, the float value is returned, otherwise
 * a default value is returned.
 * 
 ******************************************************************************/
float Parameter::getAsFloat(string name, float def)
{
	map<string, string>::iterator it = params.find(name);
	if (it != params.end())
		return atof(it->second.c_str());
	return def;
}

/*******************************************************************************
 * 
 * This method searches a map to find a parameter with a key that matches
 * the given name. If found, the boolean value is returned, otherwise
 * a default value is returned.
 * 
 ******************************************************************************/
bool Parameter::getAsBool(string name, bool def)
{
	map<string, string>::iterator it = params.find(name);
	if (it != params.end())
	{
		return strcmp(it->second.c_str(), "true") == 0;
	}
	return def;
}

/*******************************************************************************
 *
 ******************************************************************************/
string Parameter::getAsString(string name, string def)
{
	map<string, string>::iterator it = params.find(name);
	if (it != params.end())
		return (it->second.c_str());

	return def;
}
