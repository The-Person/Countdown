/*******************************************************************************
 *
 * File: OIDriverStation.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/

#include <RobonautsLibrary/OIDriverStation.h>

/*******************************************************************************
 *
 * Create an instance of a Driver Station. This class acts like a middle man
 * between the WPI DriverStation and OIController.
 *
 * @param	name	The name of the OIDriverStation.
 * @param	ds		The DriverStation OIDriverStation will communicate to.
 *
 ******************************************************************************/
OIDriverStation::OIDriverStation(std::string name, DriverStation* ds) :
	OIDevice(name, NUM_ANALOG_CHANNELS, NUM_DIGITAL_CHANNELS, NUM_INT_CHANNELS)
{
	printf("Creating OI Driver Station %s\n", name.c_str());

	this->ds = ds;
}

/*******************************************************************************
 *
 * Release any resources allocated by an instance of this class.
 *
 ******************************************************************************/
OIDriverStation::~OIDriverStation()
{
	ds = nullptr;
}

/*******************************************************************************
 *
 * Check all of the input channels, if any of them changed notify the
 * observer of the change.
 *
 ******************************************************************************/
void OIDriverStation::update(void)
{
	updateAnalog(MATCH_TIME, ds->GetMatchTime());
	updateAnalog(BATTERY_VOLTAGE, ds->GetBatteryVoltage());

	updateDigital(IS_ENABLED, ds->IsEnabled());
	updateDigital(IS_AUTON, ds->IsAutonomous());
	updateDigital(IS_TELEOP, ds->IsOperatorControl());
	updateDigital(IS_TEST, ds->IsTest());
	updateDigital(IS_DS_ATTACHED, ds->IsDSAttached());
	updateDigital(IS_FMS_ATTACHED, ds->IsEnabled());
	updateDigital(IS_SYS_ACTIVE, ds->IsSysActive());
	updateDigital(IS_SYS_BROWNED_OUT, ds->IsSysBrownedOut());

	updateInt(ALLIANCE, ds->GetAlliance());
	updateInt(LOCATION, ds->GetLocation());
}


