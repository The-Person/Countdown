/*******************************************************************************
 *
 * File: MacroStep.cpp
 *
 * This file contains the definition of several base classes for MacroSteps
 * as well as some generic MacroStep classes.
 *
 *  - MacroStep
 *  - MacroStepProxy
 *
 *  - MacroStepSequence
 *  - MacroStepCondition
 *  - MacroStepCompare
 *
 *  - MSWait
 *  - MSSplit
 *  - MSForLoop
 *
 * @see MacroStepFactory.h for more information about Macros
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include "RobonautsLibrary/MacroStep.h"
#include "RobonautsLibrary/MacroStepFactory.h"

#include "Timer.h"


// =============================================================================
// === MacroStep Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MacroStep::MacroStep(std::string type, tinyxml2::XMLElement *xml, void *control)
{
	parent_macro = NULL;
	step_type = type;
	step_name = "unknown";
	is_clear = false;

	step_control = control;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep::~MacroStep()
{
	parent_macro = NULL;
	step_type = "unknown";
}

/*******************************************************************************
 *
 ******************************************************************************/
void MacroStep::abort()
{
	if (parent_macro != NULL)
	{
		parent_macro->abort();
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void MacroStep::setParentMacro(Macro *macro)
{
	if (macro == NULL)
	{
		printf("WARNING: %s setting parent macro to NULL\n",
		    this->toString().c_str());
		printf(
		    "steps should only be chained after the head is added to a macro\n");
	}

	parent_macro = macro;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MacroStep::setUnclear(void)
{
	is_clear = false;
}
void MacroStep::setName(std::string name)
{
	step_name = name;
}
/*******************************************************************************
 *
 ******************************************************************************/
std::string MacroStep::toString()
{
	std::string rtn = "MacroStep:";
	rtn.append(step_type);
	rtn.append("(");
	rtn.append(step_name);
	rtn.append(")");
	return (rtn);
}

// =============================================================================
// === MacroStepSequence Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MacroStepSequence::MacroStepSequence(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStep(type, xml, control)
{
	next_step = NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStepSequence::~MacroStepSequence()
{
	if (next_step != NULL)
	{
		delete next_step;
		next_step = NULL;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MacroStepSequence::connect(std::string which, MacroStep * step)
{
	if (which.compare("next") == 0)
	{
		next_step = step;
		if (next_step != NULL)
		{
			next_step->setParentMacro(parent_macro);
		}

		return next_step;
	}

	printf(
	    "MacroStepSequence::connect invalid connection of %s for %s ignored\n",
	    which.c_str(), step_type.c_str());

	return NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MacroStepSequence::clear(void)
{
	if (! is_clear)
	{
		is_clear = true; // set is_clear before calling connections to 
		            	 // stop a recursive loop
		if (next_step != NULL)
		{
			next_step->clear();
		}
	}
}

// =============================================================================
// === MacroStepCondition Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MacroStepCondition::MacroStepCondition(std::string type, 
	tinyxml2::XMLElement *xml, void *control) : MacroStep(type, xml,control)
{
	true_step = NULL;
	false_step = NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStepCondition::~MacroStepCondition()
{
	if (true_step != NULL)
	{
		delete true_step;
		true_step = NULL;
	}

	if (false_step != NULL)
	{
		delete false_step;
		false_step = NULL;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MacroStepCondition::connect(std::string which, MacroStep * step)
{
	if (which.compare("true") == 0)
	{
		true_step = step;
		if (true_step != NULL)
		{
			true_step->setParentMacro(parent_macro);
		}
		return true_step;
	}
	else if (which.compare("false") == 0)
	{
		false_step = step;
		if (false_step != NULL)
		{
			false_step->setParentMacro(parent_macro);
		}
		return false_step;
	}

	printf(
	    "MacroStepCondition::connect invalid connection of %s for %s ignored\n",
	    which.c_str(), step_type.c_str());

	return NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MacroStepCondition::clear(void)
{
	if (! is_clear)
	{
		is_clear = true; // set is_clear before calling connections to 
		            	 // stop a recursive loop

		if (true_step != NULL)
		{
			true_step->clear();
		}
		
		if (false_step != NULL)
		{
			false_step->clear();
		}
	}
}

// =============================================================================
// === MacroStepCompare Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MacroStepCompare::MacroStepCompare(std::string type, tinyxml2::XMLElement *xml, void *control):
	MacroStep(type, xml, control)
{
	gt_step = NULL;
	eq_step = NULL;
	lt_step = NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStepCompare::~MacroStepCompare()
{
	if (gt_step != NULL)
	{
		delete gt_step;
		gt_step = NULL;
	}

	if (eq_step != NULL)
	{
		delete eq_step;
		eq_step = NULL;
	}

	if (lt_step != NULL)
	{
		delete lt_step;
		lt_step = NULL;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep * MacroStepCompare::connect(std::string which, MacroStep * step)
{
	if (which.compare("gt") == 0)
	{
		gt_step = step;
		if (gt_step != NULL)
		{
			gt_step->setParentMacro(parent_macro);
		}
		return gt_step;
	}
	else if (which.compare("eq") == 0)
	{
		eq_step = step;
		if (eq_step != NULL)
		{
			eq_step->setParentMacro(parent_macro);
		}
		return eq_step;
	}
	else if (which.compare("lt") == 0)
	{
		lt_step = step;
		if (lt_step != NULL)
		{
			lt_step->setParentMacro(parent_macro);
		}
		return lt_step;
	}

	printf(
	    "MacroStepCompare::connect invalid connection of %s for %s ignored\n",
	    which.c_str(), step_type.c_str());

	return NULL;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MacroStepCompare::clear(void)
{
	if (! is_clear)
	{
		is_clear = true; // set is_clear before calling connections to 
		            	 // stop a recursive loop
		
		if (gt_step != NULL)
		{
			gt_step->clear();
		}
		if (eq_step != NULL)
		{
			eq_step->clear();
		}
		if (lt_step != NULL)
		{
			lt_step->clear();
		}
	}
}

// =============================================================================
// === MSWait Methods
// =============================================================================
/*******************************************************************************
 *
 ******************************************************************************/
MSWait::MSWait(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	wait_time = xml->FloatAttribute("time");
	expire_time = 0.0;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSWait::init()
{
	expire_time = GetTime() + wait_time;
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSWait::update()
{
	if (GetTime() > expire_time)
	{
		return next_step;
	}
	return this;
}

// =============================================================================
// === MSSplit Methods
// =============================================================================
/*******************************************************************************
 *@run_split: arg 0 runs macro one
 ******************************************************************************/
MSSplit::MSSplit(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	run_macro_one = xml->Attribute("start_macro");
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSSplit::init()
{
	((MacroController *)step_control)->startMacro(run_macro_one);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSSplit::update()
{
	return next_step;
}

// =============================================================================
// === MSIntSet Methods
// =============================================================================
/*******************************************************************************
 *
 *@param arg[0] = name
 *@param arg[1] = value
 *
 ******************************************************************************/
MSIntSet::MSIntSet(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepSequence(type, xml, control)
{
	var_name = xml->Attribute("var_name");
	
	try
	{
		var_value = xml->IntAttribute("var_value");
	}
	catch (...)
	{
		var_value = 0;
	}
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSIntSet::init()
{
	parent_macro->setIntVar(var_name, var_value);
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSIntSet::update()
{
	return next_step;
}

// =============================================================================
// === MSForLoop Methods
// =============================================================================
/*******************************************************************************
 *@run_for_loop: arg 0 num_loop_cycles
 ******************************************************************************/
MSForLoop::MSForLoop(std::string type, tinyxml2::XMLElement *xml, void *control) :
	MacroStepCondition(type, xml, control)
{
	try
	{
		num_loop_cycles = xml->IntAttribute("cycles");
	}
	catch (...)
	{
		num_loop_cycles = 0;
	}

	cur_loop_cycle = -1;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSForLoop::init()
{
	cur_loop_cycle++;
}

/*******************************************************************************
 *
 ******************************************************************************/
void MSForLoop::clear(void)
{
	cur_loop_cycle = -1;
	MacroStepCondition::clear();
}

/*******************************************************************************
 *
 ******************************************************************************/
MacroStep *MSForLoop::update()
{
	if (cur_loop_cycle < num_loop_cycles)
	{
		return true_step;
	}

	cur_loop_cycle = -1;
	return false_step;
}
