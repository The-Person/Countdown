/*******************************************************************************
 *
 * File: RobotUtil.cpp
 * 
 * This file contains the definition of a class that is used to hold utility
 * type methods that as of yet don't fit anywhere else.
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/

#include <math.h>
#include "RobonautsLibrary/RobotUtil.h"
#include <string>

using namespace std;

const float RobotUtil::DEGREE_PER_RADIAN = 57.295779513082;

PowerDistributionPanel *RobotUtil::util_power_panel = nullptr;

/*******************************************************************************
 *
 * Splits a string into tokens
 *
 ******************************************************************************/
void RobotUtil::split(vector<string> *tokens, string text, char sep,
    bool include_empty)
{

	int idx = text.find_last_not_of(" \n\r\t");
	text = text.substr(0, idx + 1);

	unsigned int start = 0;
	unsigned int end = 0;
	string tok;

	while ((end = text.find(sep, start)) != string::npos)
	{
		if (((end - start) > 0) || include_empty)
		{
			tokens->push_back(text.substr(start, end - start));
		}
		start = end + 1;
	}

	tokens->push_back(text.substr(start));
}

/*******************************************************************************
 * changes string to upper
 ******************************************************************************/
std::string RobotUtil::toUpper(std::string log_name)
{
	unsigned int i = 0;

	while (i < log_name.length())
	{
		log_name.at(i) = toupper(log_name.at(i));
		i++;
	}

	return log_name;
}

/*******************************************************************************
 *
 * Limit the provided value between the provided min and max
 *
 ******************************************************************************/
float RobotUtil::limit(float min, float max, float val)
{
	if (val < min)
	{
		return min;
	}

	if (val > max)
	{
		return max;
	}

	return val;
}

/*******************************************************************************
 *
 * the returned value is limited both by position constraints and power
 * constraints -- if the position is already outside of the specified range,
 * it can not be moved any further in that direction.
 *
 ******************************************************************************/
float RobotUtil::directionalLimit(float min_pos, float max_pos, float pos,
    float min_pwr, float max_pwr, float pwr)
{
	if (pos > max_pos)
	{
		return RobotUtil::limit(0.0, max_pwr, pwr);
	}
	else if (pos < min_pos)
	{
		return RobotUtil::limit(min_pwr, 0.0, pwr);
	}
	else
	{
		return RobotUtil::limit(min_pwr, max_pwr, pwr);
	}
}

/*******************************************************************************
 *
 * rate limit; steps per cycle
 * 
 * @param	max		the maximum amount by which the value can change
 * @param	val		the input value
 * @param	last	the previous input value
 * 
 * @return	the last value adjusted by the maximum allowed adjustment or the
 * 			input value if it can be reached by adjusting the last value by
 * 			an amount less that the maximum allowed change.
 *
 ******************************************************************************/
float RobotUtil::rateLimit(float max, float val, float last)
{
	// from excel =IF(ABS(B3-C2)>=E$2, C2+SIGN(B3-C2)*E$2, B3)
	float delta = val - last;
	float signDelta = RobotUtil::sign(delta);
	float retL = val;

	if (fabs(delta) >= max)
	{
		retL = last + signDelta * max;
	}

	return retL;
}

/*******************************************************************************
 *
 *  Get the sign of the specified value.
 *
 *  @return 1.0 if the value is positive, 0.0 if the value is 0.0 and -1.0 if 
 *          the value is negative.
 * 
 ******************************************************************************/
float RobotUtil::sign(float val)
{
	float retL = 0.0;
	if (val != 0.0)
	{
		retL = val / fabs(val);
	}
	return (retL);
}

/*******************************************************************************
 * 
 * Runs a first order low pass filter using externally held information
 * 
 * @param	newValue    the new input value
 * @param	lastValue	the previous value, will be updated by this method
 * @param	filterCoeff	the filter coefficient
 * 
 * @return	the specified value filtered by the coefficient
 * 
 ******************************************************************************/
float RobotUtil::lowPass(float newValue, float *lastValue, float filterCoeff)
{
	float retL;

	retL = filterCoeff * (*lastValue) + (1 - filterCoeff) * newValue;
	*lastValue = retL;

	return (retL);

}

/*******************************************************************************
* 
 * Runs a first order high pass filter using externally held information
 * 
 * @param	newValue    the new input value
 * @param	lastInput	the previous value, will be updated by this method
 * @param	lastOutput	the previous value, will be updated by this method
 * @param	filterCoeff	the filter coefficient
 * 
 * @return	the specified value filtered by the coefficient
 * 
 ******************************************************************************/
float RobotUtil::highPass(float newValue, float *lastInput, float *lastOutput,
    float filterCoeff)
{
	float retL;

	retL = filterCoeff * ((*lastOutput) + newValue - (*lastInput));
	*lastOutput = retL;
	*lastInput = newValue;

	return (retL);
}

/*******************************************************************************
 * 
 * Joystick deadband, symmetric, float
 * 
 * @param	input	the new joystick value
 * @param	db		the deadband width
 * @param	max		the maximum value the joystick will indicate
 * 
 * @return	if input is between -db and db, a value of 0.0 will be returned
 * 			otherwise a value on the slope line produced by connecting 
 *          -max,-max to -db,0.0 or db, 0.0 to max,max
 * 
 ******************************************************************************/
float RobotUtil::deadbandJoy(float input, float db, float max)
{
	float output;

	input = RobotUtil::limit(-max, max, input); // force input to make sure it's within max
	if (fabs(max - db) < 0.001)
		return input;

	float scale_intercept = db / (max - db);
	float scale_slope = max / (max - db);

	if (input < (-1 * db))
	{
		output = (input * scale_slope) + scale_intercept;
	}
	else if (input > db)
	{
		output = (input * scale_slope) - scale_intercept;
	}
	else
	{
		output = 0.0;
	}

	return (output);
}

bool RobotUtil::increasingInMagnitude(float input, float last_input)
{
	bool retL = false;

	if((input > last_input && input > 0) || (input < last_input && input < 0) )
	{
		retL = true;
	}
	return(retL);
}

bool RobotUtil::steady(float input, float last_input)
{
	bool retL = false;

	if(input == last_input)
	{
		retL = true;
	}
	return(retL);
}

double RobotUtil::getCurrent(uint8_t channel)
{
	if (util_power_panel == nullptr)
	{
		// NOTE: attempting to initialize this as a static instance
		//       causes a segmentation fault. Thus, it is initialized
		//       on demand.
		util_power_panel = new PowerDistributionPanel();
	}

	return util_power_panel->GetCurrent(channel);
}

//**********************************************************
// washout a signal;
//**********************************************************
WashoutCommand::WashoutCommand()
{
	initialized = false;
	last_input = 0.0;
	last_decay = 0.0;

	setDecayPercent(1.0);
	setCoefficient(1.0);
}

WashoutCommand::WashoutCommand(float coefficient, float decay_perc)
{
	initialized = false;
	last_input = 0.0;
	last_decay = 0.0;

	setDecayPercent(decay_perc);
	setCoefficient(coefficient);
}

WashoutCommand::~WashoutCommand()
{

}

float WashoutCommand::setCoefficient(float coefficient)
{
	coeff = coefficient;
	return(coeff);
}

float WashoutCommand::setDecayPercent(float decay_perc)
{
	decay_percent = decay_perc;
	return(decay_percent);
}

float WashoutCommand::update(float input)
{
	float increasing_or_steady;
	float steady_state;
	float decay;

	value = input;

	if(initialized == false)  // inititalize class when first classed
	{
		initialized = true;
	}
	else
	{
		increasing_or_steady = (float)RobotUtil::increasingInMagnitude(input, last_input) || RobotUtil::steady(input, last_input);
		steady_state = input * decay_percent;
		decay = increasing_or_steady * (coeff * (input - last_input + last_decay));
		value = decay + steady_state;
		if(((value > input) && (input > 0)) || ((value < input) && (input < 0)))
		{
			value = input;
		}
//		printf("ios %.0f in %.3f dec %.3f ss %.3f val = %.3f coef %.3f  dp %.3f ", 
//				increasing_or_steady, input, decay, steady_state, value, coeff, decay_percent);
	}
	last_input = input;
	last_decay = decay;
	return(value);
}

//*************************************************************************
// Very Base Trapezoidal profile generator
// Initial and final velocity are zero, not maximum acceleration
//*************************************************************************
TrapezoidalProfile::TrapezoidalProfile()
{
	max_velocity = fabs(1.0f);
	percent_acc = fabs(0.2f);
	dt = fabs(0.02f);

	acc = last_acc = 0.0;
	vel = last_vel = 0.0;
	pos = last_pos = 0.0;

	target_time = 0.0;
	target_pos = 0.0;
	time_1 = time_2 = 0.0;
	max_acc = 0.0;
	running_time = 0.0;
	initialized = false;
}

TrapezoidalProfile::TrapezoidalProfile(float max_vel, float perc_acc, float delta_t)
{
	max_velocity = fabs(max_vel);
	percent_acc = fabs(perc_acc);
	dt = fabs(delta_t);

	acc = last_acc = 0.0;
	vel = last_vel = 0.0;
	pos = last_pos = 0.0;

	target_time = 0.0;
	target_pos = 0.0;
	time_1 = time_2 = 0.0;
	max_acc = 0.0;
	running_time = 0.0;
	initialized = false;
}

TrapezoidalProfile::~TrapezoidalProfile()
{

}

float TrapezoidalProfile::setMaxVelocity(float value)
{
	max_velocity = fabs(value);
	return(max_velocity);

}

float TrapezoidalProfile::setPercentAcc(float value)
{
	percent_acc = fabs(value);
	return(percent_acc);

}

float TrapezoidalProfile::setDeltaTime(float value)
{
	dt = fabs(value);
	return(dt);

}

float TrapezoidalProfile::getPos()
{
	return(pos);
}

float TrapezoidalProfile::getVel()
{
	return(vel);

}

float TrapezoidalProfile::getAcc()
{
	return(acc);

}

bool TrapezoidalProfile::update()
{
	if(initialized == true)
	{
		// use euler integration (not absolutely accurate; close enough for this if loops running about 50 hz and rates up to 100 units/sec
		running_time += dt;
		if(running_time > target_time)
		{
			acc = 0.0;
			pos = target_pos;
			vel = 0;
			initialized = false;  // trajector is complete
		}
		else if(running_time <= time_1)
		{
			acc = max_acc;
		}
		else if(running_time < time_2)
		{
			acc = 0.0;
			vel = max_velocity * max_acc / fabs(max_acc);
		}
		else if(running_time >= time_2)
		{
			acc = -max_acc;
		}
		// most simple of integrations
		vel += dt * acc;
		pos += dt * vel;
	}
#if 0
	if(initialized == true)
	{
		printf("TrapezoidalProfile::update(%%=%.3f p=%.3f  r=%.3f mv=%.3f, ma=%.3f, t=%.3f t1=%.3f t2=%.3f te=%.3f)\n", 
				percent_acc, pos, target_pos, max_velocity, max_acc, running_time, time_1, time_2, target_time);
	}
#endif
	
	return(initialized);
}

bool TrapezoidalProfile::initialize(float current, float end)
{
	initialized = false;
	target_pos = end;
	if(max_velocity > 0 && !(percent_acc > 1.0) && percent_acc != 0.0)    // avoid divide by zero errors
	{
		target_time  = (end - current)/(max_velocity * (1-percent_acc));
		time_1 = percent_acc * target_time;
		time_2 = target_time - time_1;
		acc = 0.0;
		vel = 0.0;
		pos = current;
		if(time_1 != 0.0)
		{
			running_time = 0.0;
			max_acc = max_velocity / time_1;
			initialized = true;
			target_time = fabs(target_time);
			time_1 = fabs(time_1);
			time_2 = fabs(time_2);
		}
		else 
		{
		}
	}
//	printf("TrapezoidalProfile::initialize(%.3f  %.3f %.3f)\n", current, end, target_pos);
	return(initialized);
}
