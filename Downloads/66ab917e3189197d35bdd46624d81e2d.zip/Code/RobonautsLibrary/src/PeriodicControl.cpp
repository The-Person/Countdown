/*******************************************************************************
 *
 * File: PeriodicControl.cpp
 *
 * This file contains the definition of a base class for controls that need
 * to run in a separate thread.
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include <stdio.h>
#include <math.h>

#include "gsi/Time.h"

#include "RobonautsLibrary/PeriodicControl.h"

static const double MIN_SLEEP_TIME = 0.001;

using namespace std;

/*******************************************************************************
 *
 * This constructor for PeriodicControl initializes the instance variables for
 * the control.
 *
 * @param name		The name of the control, also used as the name of the
 * 					parent Thread and Task
 *
 * @param period	The time between calls to update() in seconds.
 * 
 * @param priority	The optional priority of the task running this control,
 * 					if not specified Task::kDefaultPriority will be used.
 *
 ******************************************************************************/
PeriodicControl::PeriodicControl(string name, double period, 
	gsi::Thread::ThreadPriority priority) :
	gsi::Thread(name, priority)
{
	control_name = name;
	control_period = period;

	control_cycles_since_publish = 0;

	phaseInit(INIT);
}

/*******************************************************************************
 *
 *  Free the resources for this class.
 *
 ******************************************************************************/
PeriodicControl::~PeriodicControl()
{
}

std::string PeriodicControl::getName(void)
{
	return control_name;
}

/*******************************************************************************
 *
 * @return a reference to the locking semaphore used by instances of this
 * class.
 *
 ******************************************************************************/
gsi::Mutex& PeriodicControl::getLock()
{
	return control_lock;
}

/*******************************************************************************
 *
 * @return the phase that this control is currently in
 *
 ******************************************************************************/
PeriodicControl::ControlPhase PeriodicControl::getPhase()
{
	return control_phase;
}

/*******************************************************************************
 *
 * @return the period of this control
 *
 ******************************************************************************/
double PeriodicControl::getPeriod()
{
	return control_period;
}

/*******************************************************************************
 *
 * This method can be used to help monitor the status of the thread, the
 * returned value should be dependent on the period of this thread and the
 * period of the doPublish call.
 *
 * @return the number of times doPeriodic returned since the last time the
 * publish method was called
 *
 ******************************************************************************/
uint16_t PeriodicControl::getCyclesSincePublish(void)
{
	return control_cycles_since_publish;
}

/*******************************************************************************
 *
 * @return how long (in seconds) this object has been in the current phase
 *
 ******************************************************************************/
double PeriodicControl::getPhaseElapsedTime()
{
	return gsi::Time::getTime() - control_phase_time;
}

/*******************************************************************************
 *
 * This method is called internally to initialize variables that are used
 * to track phase transitions and the amount of time spent in a phase.
 *
 ******************************************************************************/
void PeriodicControl::phaseInit(ControlPhase phase)
{
	control_phase = phase;
	control_phase_time = gsi::Time::getTime();
}

/*******************************************************************************
 *
 * This method should be called shortly after the object is created, normally
 * during robot initialization, it will acquire the controls lock before
 * calling the subclasses controlInit() method.
 *
 ******************************************************************************/
void PeriodicControl::doControlInit()
{
	try
	{
		phaseInit(INIT);
		controlInit();
	}
	catch (...)
	{
		printf("EXCEPTION: caught in PeriodicControl::doControlInit -- %s\n", control_name.c_str());		
	}
}

/*******************************************************************************
 *
 * This method should be called when the robots configuration is being reloaded,
 * it will acquire the controls lock before calling the subclasses
 * updateConfig() method.
 *
 ******************************************************************************/
void PeriodicControl::doUpdateConfig()
{
	try
	{
		updateConfig();
	}
	catch (...) 
	{
		printf("EXCEPTION: caught in PeriodicControl::doUpdateConfig -- %s\n", control_name.c_str());			
	}
}

/*******************************************************************************
 *
 * This method should be called when the robot is entering the disabled mode,
 * it will acquire the controls lock before calling the subclasses
 * disableInit() method.
 *
 ******************************************************************************/
void PeriodicControl::doDisabledInit()
{
	try
	{
		phaseInit(DISABLED);
		disabledInit();
	}
	catch (...) 
	{
		printf("EXCEPTION: caught in PeriodicControl::doDisabledInit -- %s\n", control_name.c_str());		
	}
}

/*******************************************************************************
 *
 * This method should be called when the robot is entering the autonomous mode,
 * it will acquire the controls lock before calling the subclasses
 * autonomousInit() method.
 *
 ******************************************************************************/
void PeriodicControl::doAutonomousInit()
{
	try
	{
		phaseInit(AUTON);
		autonomousInit();
	}
	catch (...) 
	{
		printf("EXCEPTION: caught in PeriodicControl::doAutonomousInit -- %s\n", control_name.c_str());	
	}
}

/*******************************************************************************
 *
 * This method should be called when the robot is entering the teleop mode,
 * it will acquire the controls lock before calling the subclasses
 * teleopInit() method.
 *
 ******************************************************************************/
void PeriodicControl::doTeleopInit()
{
	try
	{
		phaseInit(TELEOP);
		teleopInit();
	}
	catch(...)
	{
		printf("EXCEPTION: caught in PeriodicControl::doTeleopInit -- %s\n", control_name.c_str());	
	}
}

/*******************************************************************************
 *
 * This method should be called when the robot is entering the test mode,
 * it will acquire the controls lock before calling the subclasses
 * teleopInit() method.
 *
 ******************************************************************************/
void PeriodicControl::doTestInit()
{
	try
	{
		phaseInit(TEST);
		testInit();
	}
	catch (...) 
	{
		printf("EXCEPTION: caught in PeriodicControl::doTestInit -- %s\n", control_name.c_str());		
	}
}


/*******************************************************************************
 *
 * This method should be called when the robot is entering the test mode,
 * it will acquire the controls lock before calling the subclasses
 * teleopInit() method.
 *
 ******************************************************************************/
void PeriodicControl::doPublish()
{
	try
	{
		publish();
		control_cycles_since_publish = 0;
	}
	catch (...)
	{
		printf("EXCEPTION: caught in PeriodicControl::doPublish -- %s\n", control_name.c_str());
	}
}

/*******************************************************************************
 *
 * This method implements the required Thread run() method.  It will enter
 * a loop that calls the subclasses update() method, then waits until the
 * next time the threads update() method should be called.
 *
 * The controls lock is acquired before and released after each call to
 * update() to help insure other threads do not change critical values
 * while the update() method is using them.
 *
 ******************************************************************************/
void PeriodicControl::run(void)
{
	double next_period_start_time = gsi::Time::getTime();
	double wait_time = control_period;

	while (!isStopRequested())
	{
		try
		{
			try
			{
				doPeriodic();
			}
			catch(...)
			{
				printf("EXCEPTION: caught in PeriodicControl::doPeriodic -- %s\n", control_name.c_str());
			}
			
			//
			// Wait until the next update cycle should begin
			//
			control_cycles_since_publish++;
			next_period_start_time += control_period;
			wait_time = next_period_start_time - gsi::Time::getTime();

			if (fabs(wait_time) > (5 * control_period))
			{
				// if the wait time is too far off in either direction reset
				printf("PeriodicControl::run -- bad wait time of %f, waiting for period\n",
					wait_time);
				
				next_period_start_time = gsi::Time::getTime() + control_period;
				wait_time = control_period;
			}
			else if (wait_time < MIN_SLEEP_TIME)
			{
				wait_time = MIN_SLEEP_TIME;
			}

			gsi::Thread::sleep(wait_time);
		}
		catch (...)
		{
			printf("EXCEPTION: caught in PeriodicControl::run -- %s\n", control_name.c_str());	
		}
	}
}
