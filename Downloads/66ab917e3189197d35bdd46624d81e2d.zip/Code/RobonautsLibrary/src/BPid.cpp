/*******************************************************************************
 *
 * File: BPid.cpp
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#include "RobonautsLibrary/BPid.h"
#include "RobonautsLibrary/RobotUtil.h"

#include <math.h>

/******************************************************************************
 * constructor: initialize variable
 ******************************************************************************/
BPid::BPid()
{
	reset();
}

/******************************************************************************
 * destructor: clean up
 ******************************************************************************/
BPid::~BPid()
{

}

/******************************************************************************
 * reset by re-initializing all variables; (possible never needeed)
 ******************************************************************************/
void BPid::reset()
{
	enabled = true;
	gains_set = false;
	limits_set = false;

	ki = 0.0;
	kp = 0.0;
	integrate_threshold = 100000000.0f; // set value "large", so integration not used until set

	ref = 0.0; // initialize setpoint
	prev_error = 0.0f; // zero integrator

#if HIGHPASS
	// initialize highpass filter parameters
	last_highpass_output = 0.0f;
	last_highpass_input = 0.0f;
	hp_coeff = 0.0; // high pass filter coefficent; will be enabled if needed
#endif

	ffwd_0 = 0.0; // feed forward coefficient (input^3)
	ffwd_1 = 0.0; // feed forward coefficient (input^2)
	ffwd_2 = 0.0; // feed forward coefficient (input^1)
	ffwd_3 = 0.0; // feed forward coefficient (input^0)

}

/******************************************************************************
 *	set the p gain, i gain, threshold for engaging controller
 ******************************************************************************/
void BPid::setGains(float kpA, float kiA, float thresholdA)
{
	gains_set = true;
	kp = kpA;
	ki = kiA;
	integrate_threshold = thresholdA;
}

/******************************************************************************
 *	set the p gain, i gain, threshold for engaging controller
 ******************************************************************************/
void BPid::setLimits(float limitLower, float limitUpper)
{
	limits_set = true; // if the controller runs without first setting
	limits[0] = limitLower;
	limits[1] = limitUpper;
}

/******************************************************************************
 *	set the p gain, i gain, threshold for engaging controller
 ******************************************************************************/
void BPid::setFeedFowardCoefficient(float a0, float a1, float a2, float a3)
{
	ffwd_0 = a0; // feed forward coefficient (input^3)
	ffwd_1 = a1; // feed forward coefficient (input^2)
	ffwd_2 = a2; // feed forward coefficient (input^1)
	ffwd_3 = a3; // feed forward coefficient (input^0)
}

/******************************************************************************
 *	disable the control system
 ******************************************************************************/
void BPid::disable()
{
	enabled = false;
}

/******************************************************************************
 *	enable the control system
 ******************************************************************************/
void BPid::enable()
{
	enabled = true;
}

/******************************************************************************
 *	set enabled state to parameter
 ******************************************************************************/
void BPid::setState(bool enabledA)
{
	enabled = enabledA;
}

/******************************************************************************
 *  create feed forward term, fit third order polynomial
 ******************************************************************************/
float BPid::feedForward(float reference)
{
	return (pow(reference, 3) * ffwd_0 + pow(reference, 2) * ffwd_1 + pow(
	    reference, 1) * ffwd_2 + pow(reference, 0) * ffwd_3);
}

/******************************************************************************
 *  the control system; must be enabled to return a value
 ******************************************************************************/
float BPid::update(float referenceA, float actualA)
{
#if HIGHPASS
	float highpass;
#endif  // HIGHPASS
	actual = actualA; // necessary only for logging
	ref = referenceA; // necessary only for logging

	error = (ref - actual); // determine error
	if (error < integrate_threshold) // accumulate error
	{
		prev_error += error; // integrate error when small (integrate threshold defines small) 
	}
	else
	{
		prev_error /= 2.0; // decay error when large
	}

	//*********** begin: gain scheduling *****************
	// non-linear control law to get a fast star with low gains
	// NOTE: gain scheduling will be added if performance warrants
#if GAIN_SCHEDULE
	if(fabs(error) > integrate_threshold)
	{
		error /= 2.0;
	}
#endif		// GAIN_SCHEDULE
	//*********** end: gain scheduling *****************

	mot_cmd = feedForward(ref) + kp * error + ki * prev_error;

	// NOTE: highpass will be added if performance warrants
	// use highpass filter to get a quick start, then fade out
#if HIGHPASS
	//highpass = RobotUtil::highPass(mot_cmd, &last_highpass_input, &last_highpass_output, hp_coeff);
	//mot_cmd += highpass;
#endif  // HIGHPASS
	mot_cmd = RobotUtil::limit(limits[0], limits[1], mot_cmd);

	return mot_cmd;
}
