/*******************************************************************************
 * 
 * File: DataLogger.cpp
 *
 * This file contains a generic interface for creating and managing Log
 * files on the robot.
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/

#include "RobonautsLibrary/DataLogger.h"
#include "RobonautsLibrary/Parameter.h"

#include "RobonautsLibrary/RobotUtil.h"

using namespace std;

/*******************************************************************************
 * 
 ******************************************************************************/
DataLogger::DataLogger(std::string name, std::string type)
{
	log_name = name;
	log_type = type;

	log_file = NULL;
	log_enabled = false;
}

/*******************************************************************************
 * 
 ******************************************************************************/
DataLogger::~DataLogger(void)
{
}

/*******************************************************************************
 * 
 ******************************************************************************/
bool DataLogger::isEnabled(void)
{
	return log_enabled;
}

/*******************************************************************************
 *
 ******************************************************************************/
void DataLogger::initLog(string phase)
{
	try
	{
		if (log_file != NULL)
		{
			fclose(log_file);
			log_file = NULL;
		}
	
		char log_parm[64];
		sprintf(log_parm, "%s_LOG", RobotUtil::toUpper(log_name).c_str()); // do this the right way
	
		log_enabled = Parameter::getAsBool(log_parm, false);
		
		if (log_enabled)
		{
			char filename[256];
			FILE * chk_out;
			for (int i = 0; i < 10; i++)
			{
				// @TODO: eliminate hard coded path
				sprintf(filename, "/logs/%s_%s_%d.%s", log_name.c_str(),
				    phase.c_str(), i, log_type.c_str());
				chk_out = fopen(filename, "r");
				if (chk_out == NULL)
				{
					log_file = fopen(filename, "w");
					// remove the next file in the sequence so there's
					// always an empty slot for the next file.
					// @TODO: eliminate hard coded path
					sprintf(filename, "/logs/%s_%s_%d.%s", log_name.c_str(),
					    phase.c_str(), ((i + 1) % 10), log_type.c_str());
					remove(filename);
					break;
				}
				else
				{
					fclose(chk_out);
					chk_out = NULL;
				}
			}
		}
	}
	catch (...)
	{
		log_file = NULL;
	}
}

/*******************************************************************************
 * 
 ******************************************************************************/
void DataLogger::log(const char* fmt, ...)
{
	try
	{
		if (log_file != NULL)
		{
			va_list args;
			va_start (args, fmt);
			vfprintf(log_file, fmt, args);
			va_end(args);
			fflush(log_file);
		}
	}
	catch(...)
	{
	}
}

/*******************************************************************************
 * 
 ******************************************************************************/
void DataLogger::flush()
{
	try
	{
		if (log_file != NULL)
		{
			fflush(log_file);
		}
	}
	catch (...)
	{	
	}
}

/*******************************************************************************
 * 
 ******************************************************************************/
void DataLogger::close()
{
	try
	{
		if (log_file != NULL)
		{
			fflush(log_file);
			fclose(log_file);
			log_file = NULL;
		}
	}
	catch (...)
	{
	}
}
