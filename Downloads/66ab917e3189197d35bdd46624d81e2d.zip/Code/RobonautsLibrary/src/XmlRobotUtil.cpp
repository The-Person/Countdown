#include <math.h>

#include "WPILib.h"

#include "RobonautsLibrary/XmlRobotUtil.h"


/*******************************************************************************
 *
 * Create an instance of a speed controller from the given XML element.
 * 
 * The XML element must have the format of
 *  
 *  <motor [type="type"] [module="module"] [port="port"] [...] >
 *  
 *  Where:	type 	the type of speed controller being used to drive this
 *  				motor, can be Jaguar, Talon, or Victor, if a type is not 
 *  				specified, the default value of Victor will be used.
 *  		
 *  		module	the module (or card) to which this speed controller is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO Only)
 *  				
 *  		port	the port to which this speed controller is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="left"
 *  				
 ******************************************************************************/
SpeedController *XmlRobotUtil::createSpeedController(tinyxml2::XMLElement* xml)
{
	const char *type 	= xml->Attribute("type");

#if defined (FRC_CRIO)
	int module			= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port			= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		printf("    using default \"port\" of 1\n");
		port = 1;
	}
	
	if (strcmp(type, "Jaguar") == 0)
	{
#if defined (FRC_CRIO)
		printf("    creating %s on module %d, port %d\n", type, module, port);
		return new Jaguar(module, port);
#else
		printf("    creating %s on port %d\n", type, port);
		return new Jaguar(port);
#endif
	}
	else if (strcmp(type, "Talon") == 0)
	{
#if defined (FRC_CRIO)
		printf("    creating %s on module %d, port %d\n", type, module, port);
		return new Talon(module, port);
#else
		printf("    creating %s on port %d\n", type, port);
		return new Talon(port);
#endif
	}
	else if (strcmp(type, "Victor") == 0)
	{
#if defined (FRC_CRIO)
		printf("    creating %s on module %d, port %d\n", type, module, port);
		return new Victor(module, port);
#else
		printf("    creating %s on port %d\n", type, port);
		return new Victor(port);
#endif
	}
	else if (strcmp(type, "VictorSP") == 0)
	{
#if defined (FRC_CRIO)
		printf("    creating %s on module %d, port %d\n", type, module, port);
		return new VictorSP(module, port);

		// In case new cRio WPI Library does not support VictorSP
		//
		// printf("    could not create %s; %s is not supported by cRio");
		// printf("    using default speed controller \"type\" of Victor\n");
		// printf("    creating Victor on module %d, port %d\n", module, port);
		// return new Victor(module, port);

#else
		printf("    creating %s on port %d\n", type, port);
		return new VictorSP(port);
#endif
	}
	else if (strcmp(type, "TalonSRX") == 0)
	{
#if defined (FRC_CRIO)
		printf("    creating %s on module %d, port %d\n", type, module, port);
		return new TalonSRX(module, port);

		// In case new cRio WPI Library does not support TalonSRX
		//
		// printf("    could not create %s; %s is not supported by cRio");
		// printf("    using default speed controller \"type\" of Victor\n");
		// printf("    creating Victor on module %d, port %d\n", module, port);
		// return new Victor(module, port);
#else
		printf("    creating %s on port %d\n", type, port);
		return new TalonSRX(port);
#endif
	}
	else
	{
#if defined (FRC_CRIO)
		printf("    using default speed controller \"type\" of Victor\n");
		printf("    creating Victor on module %d, port %d\n", module, port);
		return new Victor(module, port); // TalonSRX not supported by cRio.
#else
		printf("    using default speed controller \"type\" of TalonSRX\n");
		printf("    creating TalonSRX on port %d\n", port);
		return new TalonSRX(port);
#endif
	}
}

/*******************************************************************************
 *
 * Create an instance of a solenoid from the given XML element.
 * 
 * The XML element must have the format of
 *  
 *  <solenoid [module="module"] [port="port"] [...] >
 *  
 *  Where:	module	the module (or card) to which this speed controller is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO Only)
 *  				
 *  		port	the port to which this speed controller is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
Solenoid *XmlRobotUtil::createSolenoid(tinyxml2::XMLElement* xml)
{
	int module = xml->IntAttribute("module");
	if ((module < 0) || (module > 5))
	{
		printf("    using default \"module\" of 1\n");
		module = 0;
	}
	
	int port = xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		printf("    using default \"port\" of 1\n");
		port = 1;
	}

	if (module > 0)
	{
		printf("    creating solenoid on module %d, port %d\n", module, port);
		return new Solenoid(module, port);
	}
	else
	{
		printf("    creating solenoid on port %d\n", port);
		return new Solenoid(port);
	}
}

/*******************************************************************************
 *
 * Create a encoder
 * 
 * The XML element must have the format of
 *  
 *  <encoder [module="1"] [port_a="1"] [port_b="2"] [invert="false"] />
 *  
 *  Where:	module	the module (or card) to which this speed controller is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO Only)
 *  				
 *  		port_a	one of the digital input ports to which this encoder is 
 *                  conncected, can be a value from 1 to 14, if not specified, 
 *                  the default value of 1 is used.
 *  				
 *  		port_b	one of the digital input ports to which this encoder is 
 *                  conncected, can be a value from 1 to 14, if not specified, 
 *                  the default value of 2 is used.
 *  				
 *  		invert	if true, the inputs will be reversed in software to
 *                  change the direction the encoder counts, default is false
 *  				
 ******************************************************************************/
Encoder *XmlRobotUtil::createEncoder(tinyxml2::XMLElement* xml)
{
	Encoder *encoder;
	
#if defined (FRC_CRIO)
	int module	= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port_a	= xml->IntAttribute("port_a");
	if ((port_a < 0) || (port_a > 20))
	{
		printf("    using default \"port_a\" of 1\n");
		port_a = 1;
	}
	
	int port_b  = xml->IntAttribute("port_b");
	if ((port_b < 0) || (port_b > 20))
	{
		printf("    using default \"port_a\" of 2\n");
		port_b = 2;
	}
	
	bool invert = xml->BoolAttribute("invert");

	float scale = xml->FloatAttribute("scale");
	if (scale == 0.0)
	{
		printf("    using default \"scale\" of 0.01\n");
		scale = 0.01;	
	}
	
#if defined (FRC_CRIO)
	printf("    creating encoder on module %d, port_a %d, port_b %d, escale=%f, invert %s\n", 
			module, port_a, port_b, scale, invert?"true":"false");
	
	encoder = new Encoder(module, port_a, module, port_b, invert);
#else
	printf("    creating encoder on port_a %d, port_b %d, escale=%f, invert %s\n",
			port_a, port_b, scale, invert?"true":"false");

	encoder = new Encoder(port_a, port_b, invert);
#endif
	
	encoder->SetDistancePerPulse(scale);

	return encoder;
}

/*******************************************************************************
 *
 * @TODO: look into adding RoboRIO PWM ID value
 *
 * < ... >
 *      <switch module="1" port="1" /> (FRC_CRIO Only)
 *      <relay  module="1" port="1" /> (FRC_CRIO Only)
 *  < ... >
 * 
 ******************************************************************************/
Compressor *XmlRobotUtil::createCompressor(tinyxml2::XMLElement *xml)
{
	if (xml) {} // stops unused variable warning

#if defined (FRC_CRIO)
	tinyxml2::XMLElement *comp;

	int switch_module = -1;
	int switch_port = -1;;

	int relay_module = -1;
	int relay_port = -1;
	
	comp = xml->FirstChildElement("switch");
	if (comp != NULL)
	{
		switch_module = comp->IntAttribute("module");	
		switch_port = comp->IntAttribute("port");
	}
	
	if ((switch_module < 1) || (switch_module > 2))
	{
		printf("  using default \"module\" of 1 for \"switch\"\n");
		switch_module = 1;
	}
	
	if ((switch_port < 1) || (switch_port > 14))
	{
		printf("  using default \"port\" of 14 for \"switch\"\n");
		switch_port = 14;
	}
	
	comp = xml->FirstChildElement("relay");
	if (comp != NULL)
	{
		relay_module = comp->IntAttribute("module");
		relay_port = comp->IntAttribute("port");
	}
	
	if ((relay_module < 1) || (relay_module > 2))
	{
		printf("  using default \"module\" of 1 for \"relay\"\n");
		relay_module = 1;
	}
	
	if ((relay_port < 1) || (relay_port > 8))
	{
		printf("  using default \"port\" of 1 for \"relay\"\n");
		relay_port = 1;
	}
	
	printf("  creating compressor\n");
	printf("    switch on module %d, port %d\n", 
		switch_module, switch_port);
	printf("    relay on module %d, port %d\n", 
		relay_module, relay_port);

	return (new Compressor(switch_module, switch_port, relay_module,
		relay_port));
#else
	printf("  creating compressor\n");
	return (new Compressor());
#endif
}

/*******************************************************************************
 *
 * Create a RPot
 * 
 * The XML element must have the format of
 *  
 *  <pot [module="module"] [port="port"] [scale="scale"] [offset="offset"]
 *    [min_raw="min_raw"] [max_raw="max_raw"] [...] >
 *  
 *  Where:	module	the module (or card) to which this speed controller is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO Only)
 *  				
 *  		port	the port to which this speed controller is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  				
 *  		scale	the scale that will be applied to the raw pot value
 *  				using val = (scale * raw) + offset
 *  				
 *  		offset  the offset that will be applied to the raw value
 *  				using val = (scale * raw) + offset
 *  				
 *  		min_raw	the minimum raw value that will be considered as 
 *  				valid, if the raw value is less than this, isReady()
 *  				will return false.  This is to help detect failed
 *  				sensors.
 *  				
 *  		max_raw	the maximum raw value that will be considered as 
 *  				valid, if the raw value is greater than this, isReady()
 *  				will return false.  This is to help detect failed
 *  				sensors.
 *  				
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
RPot *XmlRobotUtil::createPot(tinyxml2::XMLElement* xml)
{
	RPot *pot;
	
#if defined (FRC_CRIO)
	int module	= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port	= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		// don't default to 1, 1 must be used by gyros
		printf("    using default \"port\" of 2\n");
		port = 2;
	}
	
#if defined (FRC_CRIO)
	printf("    creating pot on module %d, port %d\n", module, port);
	pot = new RPot(module, port);
#else
	printf("    creating pot on port %d\n", port);
	pot = new RPot(port);
#endif
	
	if (pot != NULL)
	{
		float raw1 	= 0.0;
		float raw2  = 5.0;
		float calc1 = 0.0;
		float calc2 = 5.0;

		float scale = 1.0;
		float offset = 0.0;

		float min_raw = 0.05;
		float max_raw = 4.95;

		xml->QueryFloatAttribute("min_raw", &min_raw);
		xml->QueryFloatAttribute("max_raw", &max_raw);

		xml->QueryFloatAttribute("raw1", &raw1);
		xml->QueryFloatAttribute("raw2", &raw2);
		xml->QueryFloatAttribute("calc1", &calc1);
		xml->QueryFloatAttribute("calc2", &calc2);

		scale	= (calc2 - calc1)/(raw2 - raw1);
		offset 	= calc1-raw1*scale;
		
		pot->setScale(scale);
		pot->setOffset(offset);
		
		pot->setMinimumRawValue(min_raw);
		pot->setMaximumRawValue(max_raw);
	}

	return pot;
}

/*******************************************************************************
 *
 * Create a gyro
 * 
 * The XML element must have the format of
 *  
 *  <gyro [module="1"] [port="1"] [sensitivity="0.007"] />
 *  
 *  Where:	module	the module (or card) to which this speed controller is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used
 *  				
 *  		port	the port to which this speed controller is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  				
 *  		sensitivity	the sensitivity that will be applied to the raw gyro value
 *  				
 ******************************************************************************/
RGyro *XmlRobotUtil::createGyro(tinyxml2::XMLElement* xml)
{
	RGyro *gyro;
	
#if defined (FRC_CRIO)
	int module	= xml->IntAttribute("module");
	if ((module < 1) || (module > 1))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port	= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		printf("    using default \"port\" of 1\n");
		port = 1;
	}
	
#if defined (FRC_CRIO)
	printf("    creating gyro on module %d, port %d\n", module, port);
	gyro = new RGyro(module, port);
#else
	printf("    creating gyro on port %d\n", port);
	gyro = new RGyro(port);
#endif
	
	if (gyro != NULL)
	{
		float sensitivity = xml->FloatAttribute("sensitivity");
		if (sensitivity == 0.0)
		{
			printf("    using default \"sensitivity\" of 0.007\n");
			gyro->SetSensitivity(0.007);
		}
		else
		{
			gyro->SetSensitivity(sensitivity);
		}
	}

	return gyro;
}

/*******************************************************************************
 *
 * Create a RCounter
 * 
 * The XML element must have the format of
 *  
 *  <counter [module="1"] [port="3"] [count_per_rev="8"] 
 *  	[filter_coeff="0.9"] [...] >
 *  
 *  Where:	module	the module (or card) to which this speed controller is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used
 *  				
 *  		port	the port to which this speed controller is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  				
 *  		count_per_rev	how many times the counter will increment is 
 *  						a single rotation of the output shaft
 *  						
 *  		filter_coeff	the coefficient that will be used to smooth
 *  						the output
 *  						
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
RCounter *XmlRobotUtil::createCounter(tinyxml2::XMLElement* xml)
{
	RCounter *counter;
	
#if defined (FRC_CRIO)
	int module	= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port	= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		// don't default to 1, 1 must be used by gyros
		printf("    using default \"port\" of 2\n");
		port = 2;
	}
	
#if defined (FRC_CRIO)
	printf("    creating counter on module %d, port %d\n", module, port);
	counter = new RCounter(module, port);
#else
	printf("    creating counter on port %d\n", port);
	counter = new RCounter(port);
#endif
	
	if (counter != NULL)
	{
		int cnt_per_rev		= xml->IntAttribute("count_per_rev");
		float fltr_coeff	= xml->FloatAttribute("filter_coeff");

		if (cnt_per_rev < 1)
		{
			cnt_per_rev = 1;
			printf("    using default \"count_per_rev\" of 1\n");
		}
		counter->SetCountPerRev(cnt_per_rev);
		
		if (fltr_coeff == 0.0)
		{
			fltr_coeff = 0.5;
			printf("    using default \"filter_coeff\" of %f\n", fltr_coeff);
		}
		counter->SetFilterCoeff(fltr_coeff);
	}

	return counter;
}

/*******************************************************************************
 *
 * Create a pid (SimplePID)
 * 
 * The XML element must have the format of
 *  
 *  <pid [kp="kp"] [ki="ki"] [kd="kd"]
 *  	 [targ_min="targ_min"] [targ_max="targ_max"] [targ_thp="targ_thp"]
 *  	 [cntl_min="cntl_min"] [cntl_max="cntl_max"]
 *  	 [...] >
 *  
 *  Where:	kp		proportional constant
 *  		ki		integral constant
 *  		kd		dirivitive constant
 *  		
 *  		targ_min	minimum allowed value for the target
 *  		targ_max	maximum allowed value for the target
 *  		targ_thp	threashold perentage change
 *  		
 *  		cntl_min	the minimum control value that should be generated
 *  		cntl_max	the maximum control value that should be generated
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
SimplePID *XmlRobotUtil::createPID(tinyxml2::XMLElement* xml)
{
	SimplePID *pid;
	
	printf("    creating simple PID\n");
	pid = new SimplePID();
	
	if (pid != NULL)
	{
		float kp		= xml->FloatAttribute("kp");
		float ki		= xml->FloatAttribute("ki");
		float kd		= xml->FloatAttribute("kd");
		
		float targ_min	= xml->FloatAttribute("targ_min");
		float targ_max	= xml->FloatAttribute("targ_max");
		float targ_thp	= xml->FloatAttribute("targ_thp");

		float cntl_min	= xml->FloatAttribute("cntl_min");
		float cntl_max	= xml->FloatAttribute("cntl_max");

		pid->setPIDConstants(kp, ki, kd);
		if (targ_thp != 0.0)
		{
			pid->setTargetLimits(targ_min, targ_max, targ_thp);
		}
		else
		{
			pid->setTargetLimits(targ_min, targ_max, targ_thp);
		}
		
		pid->setControlLimits(cntl_min, cntl_max);
		
		printf("      PID Kp=%f, Ki=%f, Kd=%f, tmn=%f, tmx=%f, thp=%f, cmn=%f, cmx=%f\n",
				kp, ki, kd, targ_min, targ_max, targ_thp, cntl_min, cntl_max	);
	}

	return pid;
}

/*******************************************************************************
 *
 * Create a trapizod velocity control of position (SimpleTrapCntl)
 * 
 * The XML element must have the format of
 *  
 *  <pid [kp="kp"] [ki="ki"] [kd="kd"]
 *  	 [vel_min="targ_min"] [vel_max="targ_max"] [vel_thp="targ_thp"]
 *  	 [accel="accel_val"] [cntl_min="cntl_min"] [cntl_max="cntl_max"]
 *  	 [...] >
 *  
 *  Where:	kp		proportional constant
 *  		ki		integral constant
 *  		kd		dirivitive constant
 *  		
 *  		vel_min	minimum allowed value for the velocity
 *  		vel_max	maximum allowed value for the velocity
 *  		vel_thp	threashold perentage change
 *  		
 * 			accel	the slope of the velocity curve
 * 
 *  		cntl_min	the minimum control value that should be generated
 *  		cntl_max	the maximum control value that should be generated
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
SimpleTrapCntl *XmlRobotUtil::createTrapCntl(tinyxml2::XMLElement* xml)
{
	SimpleTrapCntl *trap;
	
	printf("    creating simple PID\n");
	trap = new SimpleTrapCntl();
	
	if (trap != NULL)
	{
		float kp		= xml->FloatAttribute("kp");
		float ki		= xml->FloatAttribute("ki");
		float kd		= xml->FloatAttribute("kd");
		
		float vel_min	= xml->FloatAttribute("vel_min");
		float vel_max	= xml->FloatAttribute("vel_max");
		float vel_thp	= xml->FloatAttribute("vel_thp");

		float accel		= xml->FloatAttribute("accel");
		
		float cntl_min	= xml->FloatAttribute("cntl_min");
		float cntl_max	= xml->FloatAttribute("cntl_max");

		trap->setPIDConstants(kp, ki, kd);
		if (vel_thp != 0.0)
		{
			trap->setVelocityLimits(vel_min, vel_max, vel_thp);
		}
		else
		{
			trap->setVelocityLimits(vel_min, vel_max, 0.20);
		}
		
		if (fabs(accel) < 0.01)
		{
			trap->setAccelLimits(1.0);
		}
		else
		{
			trap->setAccelLimits(accel);
		}

		trap->setControlLimits(cntl_min, cntl_max);
		
		printf("      TRAP Kp=%f, Ki=%f, Kd=%f, tmn=%f, tmx=%f, acc= %f, thp=%f, cmn=%f, cmx=%f\n",
				kp, ki, kd, vel_min, vel_max, accel, vel_thp, cntl_min, cntl_max	);
	}

	return trap;
}

/*******************************************************************************
 *
 * Create a trapizod velocity control of position (SimpleTrapCntl)
 * 
 * The XML element must have the format of
 *  
 *  <pid [kp="kp"] [ki="ki"] [kd="kd"]
 *  	 [vel_min="targ_min"] [vel_max="targ_max"] [vel_thp="targ_thp"]
 *  	 [accel="accel_val"] [cntl_min="cntl_min"] [cntl_max="cntl_max"]
 *  	 [...] >
 *  
 *  Where:	kp		proportional constant
 *  		ki		integral constant
 *  		kd		dirivitive constant
 *  		
 *  		vel_min	minimum allowed value for the velocity
 *  		vel_max	maximum allowed value for the velocity
 *  		vel_thp	threashold perentage change
 *  		
 * 			accel	the slope of the velocity curve
 * 
 *  		cntl_min	the minimum control value that should be generated
 *  		cntl_max	the maximum control value that should be generated
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
TrapezoidalProfile *XmlRobotUtil::createTrapezoid(tinyxml2::XMLElement* xml)
{
	TrapezoidalProfile *trap;
	
	printf("    creating trapezoidal profile\n");
	trap = new TrapezoidalProfile();
	
	if (trap != NULL)
	{
		float max_vel		= xml->FloatAttribute("max_vel");
		float percent_accel		= xml->FloatAttribute("percent_accel");
		float delta_time		= xml->FloatAttribute("delta_time");

		trap->setMaxVelocity(max_vel);
		trap->setPercentAcc(percent_accel);
		trap->setDeltaTime(delta_time);

		printf("      TRAP max_v=%f %% accel=%f dt=%f\n",max_vel, percent_accel, delta_time);
	}

	return trap;
}

/*******************************************************************************
 *
 * Create a washout filter for a command (WashoutCommand
 * 
 * The XML element must have the format of
 *  
  	<washout name="drive_washout" coefficient="coeff", decay_percent="decay%" />
 *  
 *  Where:	coefficient  decay coefficient (dependent on rate)
 *  		decay_percent is the amount to decay as percent of full command
 *  				
 ******************************************************************************/
WashoutCommand *XmlRobotUtil::createWashout(tinyxml2::XMLElement* xml)
{
	WashoutCommand *wash;
	
	printf("    creating washout commander\n");
	wash = new WashoutCommand();
	
	if (wash != NULL)
	{
		float coeff		= xml->FloatAttribute("coefficient");
		float percent_decay		= xml->FloatAttribute("decay_percent");

		wash->setCoefficient(coeff);
		wash->setDecayPercent(percent_decay);

		printf("      WASHOUT coeff=%f %% decay=%f\n",coeff, percent_decay);
	}

	return wash;
}

/*******************************************************************************
 *
 * Create an instance of a Relay from the given XML element.
 * 
 * The XML element must have the format of
 *  
 *  <Relay [module="module"] [port="port"] [...] >
 *  
 *  Where:	module	the module (or card) to which this Relay is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO Only)
 *  				
 *  		port	the port to which this Relay is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
Relay *XmlRobotUtil::createRelay(tinyxml2::XMLElement* xml)
{
#if defined (FRC_CRIO)
	int module			= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port			= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		printf("    using default \"port\" of 1\n");
		port = 1;
	}


#if defined (FRC_CRIO)
	printf("    creating relay on module %d, port %d\n", module, port);
	return new Relay(module, port);
#else
	printf("    creating relay on port %d\n", port);
	return new Relay(port);
#endif
}

/*******************************************************************************
 *
 * Create an instance of a Servo from the given XML element.
 * 
 * The XML element must have the format of
 *  
 *  <Servo [module="module"] [port="port"] [...] >
 *  
 *  Where:	module	the module (or card) to which this Servo is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO only)
 *  				
 *  		port	the port to which this Servo is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
Servo *XmlRobotUtil::createServo(tinyxml2::XMLElement* xml)
{
#if defined (FRC_CRIO)
	int module			= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port			= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		printf("    using default \"port\" of 1\n");
		port = 1;
	}

#if defined (FRC_CRIO)
	printf("    creating servo on module %d, port %d\n", module, port);
	return new Servo(module, port);
#else
	printf("    creating servo on port %d\n", port);
	return new Servo(port);
#endif
}

/*******************************************************************************
 *
 * Create an instance of a Servo from the given XML element.
 * 
 * The XML element must have the format of
 *  
 *  <DigitalInput [module="module"] [port="port"] [...] >
 *  
 *  Where:	module	the module (or card) to which this DigitalInput is 
 *  				connected, can be a vaule of 1 or 2, if a module is not 
 *  				specified, the default value of 1 will be used (FRC_CRIO only)
 *  				
 *  		port	the port to which this DigitalInput is conncected,
 *  				can be a value from 1 to 10, if not specified, the
 *  				default value of 1 is used.
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
DigitalInput *XmlRobotUtil::createDigitalInput(tinyxml2::XMLElement* xml)
{
#if defined (FRC_CRIO)
	int module			= xml->IntAttribute("module");
	if ((module < 1) || (module > 2))
	{
		printf("    using default \"module\" of 1\n");
		module = 1;
	}
#endif
	
	int port			= xml->IntAttribute("port");
	if ((port < 0) || (port > 20))
	{
		printf("    using default \"port\" of 1\n");
		port = 1;
	}

#if defined (FRC_CRIO)
	printf("    creating digital input on module %d, port %d\n", module, port);
	return new DigitalInput(module, port);
#else
	printf("    creating digital input on port %d\n", port);
	return new DigitalInput(port);
#endif
}

/*******************************************************************************
 *
 * Get the period attribute and do limit checking
 * 
 * The XML element must have the format of
 *  
 *  <control [period="period"] [...] >
 *  
 *  Where:	period		controls period in seconds
 *  	
 *  		...		other options may be required based on use, a common
 *  				option would be something like name="shoot"
 *  				
 ******************************************************************************/
double XmlRobotUtil::getPeriod(tinyxml2::XMLElement *xml)
{
	double period = xml->DoubleAttribute("period");

	// check for valid period
	if (period < 0.01)
	{
		period = 0.01;
		printf("    using minimum period of %5.3f\n", period);
	}
	else if (period > 10.0)
	{
		period = 10.0;
		printf("    using maximum period of %5.3f\n", period);
	}
	
	return period;
}

/*******************************************************************************
 *
 * Get the system priority from the specified attribute and do limit and 
 * error checking
 * 
 * The XML element must have the format of
 *  
 *  <control [priority="priority"] [...] >
 *
 *  Where:	priority is the controls thread priority 
 *  		not specified means use the default priority, 
 *          a value of  0 means use the default priority, 
 *          a value of -1 means use low priority,
 *          a value of -2 means use lower priority,
 *          a value of -3 or less means use lowest priority,
 *          a value of  1 means use high priority,
 *          a value of  2 means use higher priority,
 *          a value of  3 or more means use highest priority
 * 
 ******************************************************************************/
gsi::Thread::ThreadPriority XmlRobotUtil::getPriority(tinyxml2::XMLElement *xml)
{
	int priority = xml->IntAttribute("priority");
	
	if (priority == 0)
	{
		 return gsi::Thread::PRIORITY_DEFAULT; 
	}
	else if (priority <= -3)
	{
		 return gsi::Thread::PRIORITY_LOWEST; 
	}
	else if (priority == -2)
	{
		 return gsi::Thread::PRIORITY_LOWER; 
	}
	else if (priority == -1)
	{
		 return gsi::Thread::PRIORITY_LOW; 
	}
	else if (priority == 1)
	{
		 return gsi::Thread::PRIORITY_HIGH; 
	}
	else if (priority == 2)
	{
		 return gsi::Thread::PRIORITY_HIGHER; 
	}
	else
	{
		 return gsi::Thread::PRIORITY_HIGHEST; 
	}
}
