/*******************************************************************************
 *
 * File: OIJoystick.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "Joystick.h"

#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIDevice.h"

/*******************************************************************************
 *
 * This OI Device creates an event dispatcher for monitoring the buttons and
 * dials on a joystick or gamepad.
 *
 ******************************************************************************/
class OIJoystick : public OIDevice
{
	public:
		OIJoystick(std::string name, int device_id);
		~OIJoystick(void);

		void update(void);

	protected:
		Joystick *stick;
};
