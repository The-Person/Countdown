/*******************************************************************************
 *
 * File: SimpleTrapCntl.h - Trapizoidal Position Control
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include <string>

#include "RobonautsLibrary/Parameter.h"

/*******************************************************************************
 *
 * This Simple PID id for doing closed loop control
 * 
 ******************************************************************************/
class SimpleTrapCntl
{
	public:
		SimpleTrapCntl();
		~SimpleTrapCntl(void);

		void setPIDConstants(float p, float i, float d);
		void setVelocityLimits(float min, float max, float thp = 0.20);
		void setAccelLimits(float val);
		void setControlLimits(float min, float max);

		void reset(void);

		float calculateControlValue(float targ_val, float feedback_val);

		float getErrorP(void);
		float getErrorI(void);
		float getErrorD(void);
		
		float getTargetVel(void);
		float getTargetPos(void);
		float getMeasuredVel(void);
		
		float getVelocityMin(void);
		float getVelocityMax(void);
		float getControlMin(void);
		float getControlMax(void);
		float getThreshold(void);
		
		float limitTarget(float val);
		float limitControl(float val);

		void updateConfig(void);
		void setParamPrefix(std::string prefix);
		
	private:
//		float limit(float val, float min, float max);

		float stc_const_p; // proportional control factor
		float stc_const_i; // integral control factor
		float stc_const_d; // differential control factor

		float stc_error_p; // last p error term
		float stc_error_i; // last i error term
		float stc_error_d; // last d error term

		float stc_vel_max; // variables for target (or set point) and the
		float stc_vel_min; // feedback (or process) values

		float stc_cntl_max; // variables for control (or manipulated) values
		float stc_cntl_min;

		float stc_accel;
		
		float stc_threshold; // large changes in the target will cause
		float stc_previous_target_vel; // the internal accumulators to be reset
		float stc_previous_feedback_vel;
		
		double stc_previous_time;
		float stc_previous_feedback;
		
		float stc_target_pos;
		float stc_previous_target_pos;
		float stc_previous_feedback_pos;
		std::string stc_param_prefix;  // refix for all parameters for this PID
};
