/*******************************************************************************
 *
 * File: RCounter.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "Counter.h"

#include "RobonautsLibrary/RobotUtil.h"

#define SECONDS_TO_MINUTES 60.0

/*******************************************************************************
 *
 * This class provides a wrapper for the Counter class to convert counts into
 * RPM
 *  
 ******************************************************************************/
class RCounter : public Counter
{
	public:
#if defined (FRC_CRIO)
		RCounter(uint32_t slot, uint32_t channel, float filterCoeff = 0.9);
#else
		RCounter(uint32_t channel, float filterCoeff = 0.9);
#endif

		void Update();
		float GetSpeedRpm();
		float GetSpeedFiltered();
		float GetSpeedCountsPerSec();
		float GetSpeedRevsPerSec();
		float GetSpeedRpmFiltered();
		int32_t GetCounts();
		void SetCountPerRev(int cpr);
		void SetFilterCoeff(float coeff);
		void reset();

	private:
		int32_t counter_last_count;
		double counter_last_clock;
		float counter_counts_per_rev;

		float counter_speed_rpm_raw;
		float counter_speed_rps_raw;
		float counter_speed_cps_raw;
		float counter_speed_rpm_filter;
		float counter_low_pass_coeff;
		float counter_last_filter_data;
		bool counter_first;
};
