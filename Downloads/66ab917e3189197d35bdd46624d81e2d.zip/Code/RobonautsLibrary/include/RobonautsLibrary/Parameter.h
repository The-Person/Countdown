/*******************************************************************************
 * 
 * File: Parameter.h
 *
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 * 
 ******************************************************************************/
#pragma once

#include <map>
#include <string>
#include <stdio.h>

/*******************************************************************************
 *
 * This class contains the definition of a class used to read name-value pairs
 * from a file and make them available to all other classes.
 * 
 ******************************************************************************/
class Parameter
{
	public:
		static void setFilename(std::string filename);
		static void load(void);
		static int getAsInt(std::string name, int def);
		static float getAsFloat(std::string name, float def);
		static bool getAsBool(std::string name, bool def);
		static std::string getAsString(std::string name, std::string def);
		static FILE *dbg_out;

	private:
		static std::string filename;

		static std::map<std::string, std::string> params;

		static void clearList(void);
};
