/*******************************************************************************
 *
 * File: BPid.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#define HIGHPASS	0
#define	GAIN_SCHEDULE 0

const float DEFAULT_INTEGRATOR_THRESH = 150.0; // high number due to significant quantization

const float DEFAULT_HIGH_PASS_COEFF = 0.8f;

/*******************************************************************************
 *
 * This class is used for closed loop control of high speed motors that 
 * will see rapid changes in loading
 * 
 ******************************************************************************/
class BPid
{
	public:
		BPid();
		~BPid();

		void setGains(float kp, float ki, float threshold);
		void setLimits(float lower, float upper);
		void setFeedFowardCoefficient(float a0, float a1, float a2, float a3);
		void disable();
		void enable();
		void setState(bool enabledA);
		void reset();

		float update(float referenceA, float actualA);

	private:
		float kp; // proportional gain
		float ki; // integral gain
		float ref; // setpoint desired 

		float ffwd_0; // feed forward coefficient (input^3)
		float ffwd_1; // feed forward coefficient (input^2)
		float ffwd_2; // feed forward coefficient (input^1)
		float ffwd_3; // feed forward coefficient (input^0)

		float actual; // actual or measured value
		float mot_cmd; // output of controller, usually a motor command [-1,1]
		float prev_error; // sum of all prior error, subject to decay
		float error; // kept for logging
		float limits[2]; // limits on output of controller [0] = lower, [1] = upper

		// threshold for turning on integrator part of controller
		float integrate_threshold;

#if HIGHPASS	
		// highpass filter (to be used later)
		float last_highpass_output;
		float last_highpass_input;
		float hp_coeff;
#endif

		bool enabled;
		bool gains_set;
		bool limits_set;

		float feedForward(float ref);
};

