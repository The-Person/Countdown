/*******************************************************************************
 *
 * File: XmlRobotUtil.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include "SpeedController.h"
#include "Solenoid.h"
#include "Encoder.h"
#include "DigitalInput.h"
#include "Compressor.h"
#include "Relay.h"
#include "Servo.h"

#include "gsi/Thread.h"
#include "gsu/tinyxml2.h"

#include "RobonautsLibrary/Rpot.h"
#include "RobonautsLibrary/RCounter.h"
#include "RobonautsLibrary/SimplePID.h"
#include "RobonautsLibrary/SimpleTrapCntl.h"
#include "RobonautsLibrary/RGyro.h"

/*******************************************************************************
 *
 * This class contains methods for parsing XML elements to create objects
 * for use by the robot.  This is intended to help keep the XML interface
 * consistent across many classes and to reduce the amount of duplicate 
 * code.
 * 
 ******************************************************************************/
class XmlRobotUtil
{
	public:
		static SpeedController *createSpeedController(tinyxml2::XMLElement* xml);
		static Solenoid *createSolenoid(tinyxml2::XMLElement* xml);
		static Encoder *createEncoder(tinyxml2::XMLElement *xml);
		static Compressor *createCompressor(tinyxml2::XMLElement *xml);
		
		static RPot *createPot(tinyxml2::XMLElement* xml);
		static RGyro *createGyro(tinyxml2::XMLElement* xml);
		static RCounter *createCounter(tinyxml2::XMLElement* xml);
		static SimplePID *createPID(tinyxml2::XMLElement* xml);
		static SimpleTrapCntl *createTrapCntl(tinyxml2::XMLElement* xml);
		static TrapezoidalProfile *createTrapezoid(tinyxml2::XMLElement* xml);
		static WashoutCommand *createWashout(tinyxml2::XMLElement* xml);
		static Relay *createRelay(tinyxml2::XMLElement* xml);
		static Servo *createServo(tinyxml2::XMLElement* xml);
		static DigitalInput *createDigitalInput(tinyxml2::XMLElement* xml);

		static double getPeriod(tinyxml2::XMLElement *xml);
		static gsi::Thread::ThreadPriority getPriority(tinyxml2::XMLElement *xml);
};
