/*******************************************************************************
 *
 * File: OICypress.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#if defined (FRC_CRIO)
#include "WPILib.h"

#include "RobonautsLibrary/OIObserver.h"
#include "RobonautsLibrary/OIDevice.h"

/*******************************************************************************
 *
 * This OI Device creates an event dispatcher for monitoring the buttons and
 * dials connected to a Cypress board.
 *
 ******************************************************************************/
class OICypress : public OIDevice
{
	public:
		OICypress(std::string name, DriverStation *ds);
		~OICypress(void);

		void update(void);
		
		void updateAnalog(int idx, float val);

	private:
		DriverStation *ds;
		DriverStationEnhancedIO *enhanced_ds;
};

#endif
