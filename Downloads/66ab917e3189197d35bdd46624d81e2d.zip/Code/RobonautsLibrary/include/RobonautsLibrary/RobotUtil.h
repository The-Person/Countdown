/*******************************************************************************
 *
 * File: RobotUtil.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

#include <string>
#include <vector>

#include <PowerDistributionPanel.h>  // WPI

/*******************************************************************************
 *
 * This class is used to hold utility type methods that as of yet don't fit 
 * anywhere else.
 *
 ******************************************************************************/
class RobotUtil
{
	public:
		static const float DEGREE_PER_RADIAN;

		static void split(std::vector<std::string> *tokens,
		    const std::string text, char sep, bool include_empty);

		static float limit(float min, float max, float val);

		static float directionalLimit(float min_pos, float max_pos, float pos,
		    float min_pwr, float max_pwr, float pwr);

		static float rateLimit(float max, float val, float last);
		static float sign(float val);
		static float lowPass(float newValue, float *lastValue,
		    float filterCoeff);

		static float highPass(float newValue, float *lastInput,
		    float *lastOutput, float filterCoeff);

		static float deadbandJoy(float input, float db, float max);
		
		static std::string toUpper(std::string log_name);
		
		static bool increasingInMagnitude(float input, float last_input);
		static bool steady(float input, float last_input);
		
		static double getCurrent(uint8_t channel);

	private:
		static PowerDistributionPanel *util_power_panel;

};

class WashoutCommand
{
public:
	WashoutCommand();
	WashoutCommand(float coefficient, float decay_percent);
	~WashoutCommand();
	float setDecayPercent(float value);
	float setCoefficient(float value);
	float get() { return(value);};
	float update(float input);


private:
	float coeff;
	float decay_percent;
	float last_input;
	float last_decay;
	float value;

	bool initialized;
};


class TrapezoidalProfile
{
public:
	TrapezoidalProfile();
	TrapezoidalProfile(float max_vel, float perc_acc, float delta_t);
	~TrapezoidalProfile();
	float setMaxVelocity(float value);
	float setPercentAcc(float value);
	float setDeltaTime(float value);
	float getPos();
	float getVel();
	float getAcc();
	bool update();
	bool initialize(float current, float end);


private:
	float max_velocity;
	float percent_acc;
	float dt;
	float target_pos;
	float target_time;
	float time_1;
	float time_2;
	float running_time;
	bool initialized;

	float acc, last_acc;
	float vel, last_vel;
	float pos, last_pos;
	float max_acc;
};
