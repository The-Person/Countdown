/*******************************************************************************
 *
 * File: OIObserver.h
 * 
 * Written by:
 * 	The Robonauts
 * 	FRC Team 118
 * 	NASA, Johnson Space Center
 * 	Clear Creek Independent School District
 *
 ******************************************************************************/
#pragma once

/*******************************************************************************
 *
 * This OI Observer is a virtual class that acts as an interface for
 * any class that needs to be notified when the one or more of the inputs
 * from the Operator Interface changes.
 *
 * All methods have no-op default implementations
 *
 ******************************************************************************/
class OIObserver
{
	public:
		OIObserver();
		virtual ~OIObserver();
		virtual void setDigital(int id, bool val);
		virtual void setInt(int id, int val);
		virtual void setAnalog(int id, float val);
};
